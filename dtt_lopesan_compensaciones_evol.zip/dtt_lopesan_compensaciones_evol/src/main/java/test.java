import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.imageio.ImageIO;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.deloitte.jidoka.lopesan.cartapago.Casuistica;
import com.deloitte.jidoka.lopesan.cartapago.Constantes;
import com.deloitte.jidoka.lopesan.config.CeldasUtils;

import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import net.sourceforge.tess4j.util.ImageHelper;

public class test {

		public static void main(String[] args) throws IOException, ParseException{
			String i = "-2736.64";
			double otros = 0.0d;
			otros = Math.round(Double.valueOf(i) * 100) / 100d;
			System.out.println(otros);	
//			Path paths = Paths.get("G:\\lopesan\\pruebas");
//			
//			try(Stream<Path> streamFilesExcel = Files.list(paths);){						
//				List<Path> listFile = streamFilesExcel.sorted().collect(Collectors.toList());
//				for (Path path : listFile) {
//					System.out.println("--------------FICHERO   " + path.toString() + "----------------");
//					try(FileInputStream excelFile = new FileInputStream(path.toString());				
//							XSSFWorkbook workbook = new XSSFWorkbook(excelFile);){
//							for(int i= 0; i<workbook.getNumberOfSheets();i++) {
//								XSSFSheet sheet = workbook.getSheetAt(i);
//								System.out.println("--------------PESTAÑA  " + sheet.getSheetName() + "----------------");
//								for(int j = 0; j < sheet.getLastRowNum(); j++) {
//									if(sheet.getRow(j) != null) {
//										XSSFRow row = sheet.getRow(j);
//										System.out.println("--------------FILA  " + row.getRowNum() + "----------------");
//										for(int k = 0; k < row.getLastCellNum(); k ++) {
//											XSSFCell cell = row.getCell(k);
//											System.out.println("--------------COLUMNA  " + k + "----------------");
//											CeldasUtils celdasUtils = new CeldasUtils();
//											//DataFormatter fmt = new DataFormatter();
//											//String valueAsSeenInExcel = fmt.formatCellValue(cell);
//											if(j==3 && k==1) {
//												String www = celdasUtils.valorCelda(cell);
//												if (www.matches("\\d{2}\\.\\d{2}\\.(\\d{4}|\\d{2})")) {
//													System.out.println("Hola");
//												}
//											        System.out.println(www);
//												
//											}
//											else {
//												System.out.println(celdasUtils.valorCelda(cell));
//											}
//											//System.out.println(valueAsSeenInExcel);
//										}
//									}
//								}	
//							}		
//						}
//					}
//				} 
			
			
		}
}
