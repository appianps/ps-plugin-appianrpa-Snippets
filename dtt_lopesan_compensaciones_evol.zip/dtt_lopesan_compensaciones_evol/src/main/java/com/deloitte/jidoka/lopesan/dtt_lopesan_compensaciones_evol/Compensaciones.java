package com.deloitte.jidoka.lopesan.dtt_lopesan_compensaciones_evol;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import javax.mail.MessagingException;

import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.util.IOUtils;

import com.deloitte.jidoka.lopesan.config.CoordinatesUtil;
import com.deloitte.jidoka.lopesan.cartapago.CartaPago;
import com.deloitte.jidoka.lopesan.cartapago.Casuistica;
import com.deloitte.jidoka.lopesan.cartapago.Constantes;
import com.deloitte.jidoka.lopesan.cartapago.Factura;
import com.deloitte.jidoka.lopesan.config.CeldasUtils;
import com.deloitte.jidoka.lopesan.config.RobotParameters;
import com.deloitte.jidoka.lopesan.exceldrive.ExcelDrive;
import com.deloitte.jidoka.lopesan.exceptions.BusinessException;
import com.deloitte.jidoka.lopesan.exceptions.SystemException;
import com.deloitte.jidoka.lopesan.gmail.LopesanMail;
import com.deloitte.jidoka.lopesan.transaccion.SAP.SapBasicControl;
import com.deloitte.jidoka.ttoo.Apollo;
import com.deloitte.jidoka.ttoo.Generico;
import com.deloitte.jidoka.ttoo.Jet2Holidays;
import com.deloitte.jidoka.ttoo.MeetingPoint;
import com.deloitte.jidoka.ttoo.TUISverige;
import com.deloitte.jidoka.ttoo.ThomasCook;
import com.deloitte.jidoka.ttoo.Touroperador;
import com.deloitte.jidoka.ttoo.TuiNetherland;
import com.deloitte.jidoka.ttoo.TuiUk;
import com.deloitte.jidoka.ttoo.ViajesCanariasEuropa;
import com.deloitte.jidoka.ttoo.ViajesElCorteIngles;
import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.Variant;
import com.novayre.jidoka.client.api.IJidokaServer;
import com.novayre.jidoka.client.api.IRobot;
import com.novayre.jidoka.client.api.IWaitFor;
import com.novayre.jidoka.client.api.JidokaFactory;
import com.novayre.jidoka.client.api.annotations.FieldLink;
import com.novayre.jidoka.client.api.annotations.Robot;
import com.novayre.jidoka.client.api.execution.ExecutionParameter;


import com.novayre.jidoka.sap.api.IGuiApplication;
import com.novayre.jidoka.sap.api.cmp.GuiButton;
import com.novayre.jidoka.sap.api.cmp.GuiCTextField;
import com.novayre.jidoka.sap.api.cmp.GuiRadioButton;
import com.novayre.jidoka.sap.api.cmp.GuiTextField;
import com.novayre.jidoka.sap.api.containers.GuiFrameWindow;
import com.novayre.jidoka.sap.api.containers.GuiMainWindow;
import com.novayre.jidoka.sap.api.containers.GuiModalWindow;
import com.novayre.jidoka.sap.api.containers.GuiShell;
import com.novayre.jidoka.sap.api.containers.GuiTab;
import com.novayre.jidoka.sap.api.window.GuiMenu;
import com.novayre.jidoka.sap.api.window.GuiStatusBar;
import com.novayre.jidoka.sap.api.window.GuiUserArea;

import com.novayre.jidoka.windows.api.IWindows;
import com.sun.jna.platform.win32.WinDef.HWND;

import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import com.deloitte.jidoka.lopesan.transaccion.SAP.SapConstants;
import com.deloitte.jidoka.lopesan.transaccion.SAP.TSap_FB03;
import com.deloitte.jidoka.lopesan.transaccion.SAP.TSap_F_32;


/**
 * 
 * @author sap jgraualbors
 *
 */
@Robot
public class Compensaciones implements IRobot {
	
	private boolean control = false;
	
	private int itemContador = 1;
	
	private int contadorI  = 1;

	private static final long PAUSE = 1000;

	private static final long CHARACTER_PAUSE = 25;

	private static final long TYPING_PAUSE = 25;

	private IJidokaServer<?> server;

	private IWindows windows;

	private RobotParameters robotParameters;

	private LopesanMail mail;
	private HashMap<String, List<Casuistica>> casuisticas;
	private HashMap<String, List<String>> mapaTTOO;

	private List<CartaPago> cartasPago;

	private CartaPago currentCartaPago;
	
	private String currentFactura; // identificador de la factura
	private Factura currentFacturaCompleta;
	private int currentItem;
	private int contadorCartaPago; //
	private int numberOfCartasPago;
	
	// valor de SinAsignar doublePendiente en compensaciones robot anterior.
	Double sinAsignar;
	
	String stringSinAsignar;
	
	private String numeroEjecucion;
	
	private SapBasicControl sapControl;
	
	private String fichero;
	
	/** IWaitFor */
	@FieldLink("::waitFor")
	protected IWaitFor waitFor;
	


	Touroperador touroperador;

	private ExcelDrive excelDrive;

	CoordinatesUtil coordUtil;

	private boolean hayPago;

	List<CartaPago> cartasPagoErroneas;
	List<String> facturasAMarcar;
	List<Factura> facturasACompensar;
	
	int numCorreos;
	
	double otros;
	String mensajeDeError;
	
	private int contadorApertura = 1;
	
	private Map<String, String> environmentVariables;
	private boolean noHayPartidasAbiertas;
	

	/**
	 * Metodo utilizado para la inicializacion de las variables utilizadas por el
	 * Robot
	 * @throws IOException 
	 * @throws GeneralSecurityException 
	 * @throws SystemException 
	 */
	public void inicio() throws SystemException {
		server = JidokaFactory.getServer();
		windows = IWindows.getInstance(this);
		waitFor = windows.waitFor(this);
		
		windows.defaultPause(PAUSE);
		windows.mousePause(PAUSE);
		windows.characterPause(CHARACTER_PAUSE);
		windows.typingPause(TYPING_PAUSE);
		//escribirInfoEjecucion();
		currentItem = 0;
		contadorCartaPago = 0;
		numberOfCartasPago = 0;
		sinAsignar = 0.0;
		stringSinAsignar = "";
		fichero = "";
		
		casuisticas = new HashMap<String, List<Casuistica>>();
		mapaTTOO = new HashMap<String, List<String>>();
		numeroEjecucion = String.valueOf(server.getExecution(0).getCurrentExecution().getExecutionNumber());
		server.info("El numero de ejecucion es >> " + numeroEjecucion);
		robotParameters = new RobotParameters(server);
		server.info("Parametros del robot");
		server.info(robotParameters.getPathBase());
		
		//sap
		sapControl = new SapBasicControl(this, windows, server, waitFor);
		sapControl.setSapCredentials(robotParameters.getSapCredentials());
		environmentVariables = server.getEnvironmentVariables();


		mail = new LopesanMail(server);

		coordUtil = CoordinatesUtil.getInstance();
		cartasPago = new ArrayList<CartaPago>();
		cartasPagoErroneas = new ArrayList<CartaPago>();
		facturasAMarcar = new ArrayList<String>();
		facturasACompensar = new ArrayList<Factura>();

		excelDrive = new ExcelDrive(server);

		cargaTTOO();
		cargaCasuisticas();
/*		
 * Pruebas para rangos
 * 
 * server.debug("RANGOS-------------------------");
 * excelDrive.getRangos();
 * server.debug("fin rangos ---------------------------");
*/
		
		mensajeDeError="";
		noHayPartidasAbiertas = false;
	}

	public void lecturaCartasPago() throws SystemException, BusinessException {
		// Lo primero que vamos a hacer es conectarnos al correo electronico e ir
		// descargando los pdfs por TTOO y compañia

		server.info("Inicio lectura Cartas de pago");
		// Descargamos la lista de TTOO de excel
		List<String> listaTTOO = excelDrive.listaTTOO();
		// Primero se pasan todos los TTOO
		for (String nombreTTOO : listaTTOO) {
			mail.leerCorreo(robotParameters, nombreTTOO);
		}

		// Segundo se pasa el INBOX por si la regla no ha podido mover alguno de los
		// robots, el parametro INBOX los metera para el tratamiento generico
		server.info("Inicio lectura Cartas de pago en INBOX");
		mail.leerCorreo(robotParameters, Constantes.INBOX);
		server.info("Hay " + mail.getNumCorreos() + " numero de Correos pendientesS");
		
		
		// vamos a tener tantas cartas de pago como ficheros en los correos // Antes: tantos items como ficheros
		numberOfCartasPago = mail.getRutaYCuerpo().size() + mail.getGenerico().size();
//		server.setNumberOfItems(mail.getRutaYCuerpo().size() + mail.getGenerico().size());
		server.info("Numero de cartas de pago: " + numberOfCartasPago);

//		CartaPago x1 = null; // PARA QUE NO DE NULLPOINTER AL NO LEER BIEN EL PDF POR EJEMPLO 
		CartaPago x1 = new CartaPago();
		currentCartaPago = x1; // PARA QUE NO PETE POR NULLPOINTER AL NO HABER LEIDO LA CARTA CORRECTAMENTE 
		String touroperador = "";

		if (!mail.getRutaYCuerpo().isEmpty()) {
			server.info("Hay correos");

			@SuppressWarnings("rawtypes")
			//Iteramos por el hasmap tomando como clave el fichero a procesar y como valor el nombre del TTOO
			Iterator it = mail.getRutaYCuerpo().entrySet().iterator();
			while (it.hasNext()) {
				@SuppressWarnings("rawtypes")
				Map.Entry pair = (Map.Entry) it.next();

				String clave = (String) pair.getKey();
				String value = (String) pair.getValue();

				// Aqui vamos a buscar si tiene TTOO el correo leido
				// Para ello buscamos en el hashmap el valor que coincida con la calve del
				// nombre de fichero
				String touroperadorCorreo = mail.getCartasDePago().get(clave);
				server.info("Segun el Correo el TTOO es:" + touroperadorCorreo);

//				String fichero = clave;
				fichero = clave;
				if (fichero.toLowerCase().contains(".pdf")) {
					server.info("Hay fichero y es un PDF");
					if (touroperadorCorreo.equalsIgnoreCase(Constantes.INBOX)) {
						server.info(Constantes.LACARPETAERAINBOX);
						touroperador = busquedaTTOOOCR(fichero);
						server.info(Constantes.ELNUEVOTTOOBUSCADO + touroperador);
					} else {
						server.info(Constantes.LACARPETANOERAINBOX);
						touroperador = touroperadorCorreo;
					}
					x1 = tratamientoPDF(clave, touroperador);

				} else if (fichero.toLowerCase().contains(".xls")) {
					server.info("Hay fichero y es un Excel");
					if (touroperadorCorreo.equalsIgnoreCase(Constantes.INBOX)) {
						server.info(Constantes.LACARPETAERAINBOX);
						touroperador = busquedaTTOOExcel(fichero);
						server.info(Constantes.ELNUEVOTTOOBUSCADO + touroperador);
					} else {
						server.info(Constantes.LACARPETANOERAINBOX);
						touroperador = touroperadorCorreo;
					}
					x1 = tratamientoExcel(clave, touroperador);

				} else if (fichero.toLowerCase().contains(".doc")) {
					server.info("Hay fichero y es Word");
					if (touroperadorCorreo.equalsIgnoreCase(Constantes.INBOX)) {
						server.info(Constantes.LACARPETAERAINBOX);
						touroperador = busquedaTTOOWord(fichero);
						server.info(Constantes.ELNUEVOTTOOBUSCADO + touroperador);
					} else {
						server.info(Constantes.LACARPETANOERAINBOX);
						touroperador = touroperadorCorreo;
					}

					x1 = tratamientoWord(clave, touroperador);

				}
				// esta casuistica es para cuando no hay ninguna clase de fichero adjunto y
				// buscamos los casos que van en el cuerpo
				// Los casos son TUI SVERIGE y VIAJES EL CORTE INGLES
				else if (value.contains("TUI Sverige") || value.contains("Tui Sverige") || value.contains("TUI SVERIGE")
						|| clave.contains(Constantes.TUISVERIGE)) {
					server.info(Constantes.TTOOES  + Constantes.TUISVERIGE);
					server.info(value);
					x1 = tratamientoTextoPlano(value, fichero, Constantes.TUISVERIGE);
				} else if (value.contains("VIAJES EL CORTE INGLES") || value.contains("CORTE INGLES")
						|| value.contains("Corte Ingles")) {
					server.info(Constantes.TTOOES  + touroperador);
					x1 = tratamientoTextoPlano(value, fichero, Constantes.VIAJESELCORTEINGLES);

				}
				else if(fichero.toLowerCase().contains(".png")) { // caso nullpointer por png
					server.debug("No deberia entrar, deberia haberse gestionado en leermail");
					server.warn("FICHERO ERRONEO PNG");
//					x1 igual a null // evitamos null 
					throw new BusinessException("Error png", "", false);
				}
				else {
					server.warn("Fichero: " + fichero);
					server.error("Fichero adjunto irreconocible, seguramente CSV cuando deberia ser pdf (tui uk? suelen enviar una copia en csv)");
					throw new BusinessException("Error tipo de fichero no contemplado", "", false);
				}

				if(x1 != null) { // modificacion porque petaba por nullpointer y no estaba controlado para algunos ttoo 
					otros = x1.getOtros();
					server.info("otros es " + otros);
					if (otros > 0 && x1.getSaldosDeposito().size()==0) {
						Factura fact1 = new Factura("Pagado de Mas", Constantes.MINUSOTROS, Double.toString(otros).replace(".", ","),
								Constantes.REVISARLINEANOIDENTIFICADA);
						x1.addFactura(fact1);
					} else if (otros < 0 && x1.getSaldosDeposito().size()==0) {
						Factura fact1 = new Factura("Pagado de Menos", Constantes.MINUSOTROS, Double.toString(otros).replace(".", ","),
								Constantes.REVISARLINEANOIDENTIFICADA);
						x1.addFactura(fact1);
					}
	
					List<Factura> listafact = x1.getFacturas();
	
					for (Factura fact : listafact) {
						server.info("El tipo de la factura es: " + fact.getTipo() + " con id: " + fact.getIdentificador()
								+ Constantes.CONIMPORTE + fact.getImporte());
					}
	
					if (!x1.getSociedad().equalsIgnoreCase("") && !x1.getTtooAcreedor().equalsIgnoreCase("")) {
						cartasPago.add(x1);
					} else {
						try {
							server.info("La sociedad o el TTOO no han sido reconocidos correctamente");
							server.info(Constantes.CONST_CONT_CARTASP + contadorCartaPago + "nombreDoc: " + x1.getNombreDocumento());
							x1.setCorrecto(false);
							cartasPago.add(x1);
							cartasPagoErroneas.add(x1);
							throw new BusinessException("No se ha obtenido TTOO o sociedad, carta de pago erronea", "fin", false);
						} catch (Exception e) {
							throw new SystemException("Ha habido un error al anyadir cartadepago/cartadepagoerronea", e, "fin", false);
						}
					}
				}
				else {
					server.warn("------ Carta de pago null, no hemos podido obtener valor de OTROS");
				}
			}
		} else {
			server.info("No hay correos en las carpetas random");

		}

		if (!mail.getGenerico().isEmpty()) {
			@SuppressWarnings("rawtypes")
			Iterator it = mail.getGenerico().entrySet().iterator();
			while (it.hasNext()) {
				@SuppressWarnings("rawtypes")
				Map.Entry pair = (Map.Entry) it.next();

				String clave = (String) pair.getKey();
				String fichero = clave;
				if (fichero.toLowerCase().contains(".xlsx")) {
					server.info("Se reconoce TTOO generico y se comienza a tratar");
					x1 = tratamientoGenerico(clave, Constantes.GENERICO);
					server.info("Informacion carta Pago generica");
					server.info(x1.getNombreDocumento());
					server.info(x1.getSociedad());
					server.info(x1.getImporte());

					otros = x1.getOtros();
					server.info(Constantes.MINUSOTROS + " es " + otros);
					if (otros > 0 && x1.getSaldosDeposito().size()==0) {
						Factura fact1 = new Factura("Pagado de Mas", "otros", Double.toString(otros).replace(".", ","),
								Constantes.REVISARLINEANOIDENTIFICADA);
						x1.addFactura(fact1);
					} else if (otros < 0 && x1.getSaldosDeposito().size()==0) {
						Factura fact1 = new Factura("Pagado de Menos", "otros",
								Double.toString(otros).replace(".", ","), Constantes.REVISARLINEANOIDENTIFICADA);
						x1.addFactura(fact1);
					}
				} else {
					server.info("El fichero no es excel, no será tratado como generico");
					server.info(Constantes.CONST_CONT_CARTASP + contadorCartaPago + "Fichero No Reconocido Como Excel para generico");
// se han cambiado los items 					
					x1.setCorrecto(false);
					cartasPago.add(x1);
					cartasPagoErroneas.add(x1);
				}
				//Aqui no se controla el acreedor porque no suele venir en las cartas genericas
				if (!x1.getSociedad().equalsIgnoreCase("")) {
					server.info("Se añade la carta de pago");
					cartasPago.add(x1);
				} else {
					try {
						server.info("La sociedad o el TTOO no han sido reconocidos correctamente");
						server.info(Constantes.CONST_CONT_CARTASP + contadorCartaPago + "nombreDoc: " + x1.getNombreDocumento());
						x1.setCorrecto(false);;
						cartasPago.add(x1);
						cartasPagoErroneas.add(x1);

					} catch (Exception e) {
						server.error("ERROR", e);
						throw new SystemException("Ha habido un error al anyadir cartadepago/cartadepagoerronea 2", e, "fin", false);
					}
				}
			}
		} else {
			server.info("No hay correos en el INBOX para genérico");
		}

	}


	public String quedanCartasPorProcesar() {
		server.info("Carta pago actual: " + contadorCartaPago); 
		server.info("Numero de cartas de pago: " + cartasPago.size());
		int k = 0;
		for(CartaPago carta : cartasPago) {
			server.info("El documento " + k +" es: " + carta.getNombreDocumento());
			k++;
		}
		if(contadorCartaPago < cartasPago.size()) { 
			currentCartaPago = cartasPago.get(contadorCartaPago); 
			while(!currentCartaPago.isCorrecto() && contadorCartaPago < cartasPago.size()) {	
				String[] x = currentCartaPago.getNombreDocumento().split("\\\\");
				String nombreFichero = x[x.length - 1];
				server.info("ContadorCartasDePago: " + contadorCartaPago + ", nombreFichero: " + nombreFichero);
				contadorCartaPago++; 
				currentCartaPago.setCorrecto(false);
				if(contadorCartaPago < cartasPago.size()) { 
					cartasPagoErroneas.add(currentCartaPago);
					currentCartaPago = cartasPago.get(contadorCartaPago); 
				}
				else {
					server.info("No quedan cartas de pago");
				}
				
			}
			String[] x = currentCartaPago.getNombreDocumento().split("\\\\");

			String nombreFichero = x[x.length - 1];

			server.info("ContadorCartasDePago: " + contadorCartaPago + ", nombreFichero: " + nombreFichero);
			hayPago = false;
			contadorCartaPago++; //currentItem++;

			return "Si";
		} else {
			return "No";
		}
	}


	/**
	 * Metodo de inicio de la aplicacion SAP
	 * 
	 * @throws SystemException
	 */
	public void iniciarSAP() throws SystemException {
		server.info("Abriendo SAP...");
		try {
			sapControl.sapOpen(robotParameters.getSapConnection());	
			windows.pause(2000);
			// hace clic en login button 
			sapControl.sapLogin("ES", robotParameters.getMandante());
			windows.pause(2000);
			
		} catch (Exception e) {
			server.setCurrentItemResultToWarn("No se ha podido abrir SAP");
			mensajeDeError = "Error al iniciar SAP";
			throw new SystemException("Error al iniciar SAP.", e, "iniciarSAP", true);
		}
	}
	
	
	public void sapAbrirTransaccionF32() throws SystemException  {
		server.debug("Abriendo Transaccion F32...");
		try {
			// abre la transaccion y comprueba que la siguiente ventana sea la correcta
			sapControl.sapOpenTransaction(TSap_F_32.TRANSACTION_NAME, TSap_F_32.windowCompensarDeudorDatosCabecera.NAME);
		}
		catch (Exception e) {
			throw new SystemException("Error al ejecutar la transaccion F-32", e, "sapAbrirTransaccionF32", false);
		}
	}
	
	public void sapF32CompensarDeudorDatosCabecera() throws BusinessException {
		// Ahora hay que incluir la información de la cuenta(TTOO), la fecha y la sociedad
		// Al poder haber varios codigods de deudor, siempre al entrar a f-32 vamos a meter el primero
		
		server.debug("Escribir datos en compensar deudor: datos cabecera ...");
		IGuiApplication sap = sapControl.getSap();
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		
		GuiCTextField cuenta = userArea.findById(TSap_F_32.windowCompensarDeudorDatosCabecera.CTEXT_CUENTA);
		GuiCTextField fecha = userArea.findById(TSap_F_32.windowCompensarDeudorDatosCabecera.CTEXT_FECHA);
		GuiCTextField sociedad = userArea.findById(TSap_F_32.windowCompensarDeudorDatosCabecera.CTEXT_SOCIEDAD);
		GuiCTextField cme = userArea.findById(TSap_F_32.windowCompensarDeudorDatosCabecera.CTEXT_INDICADOR_CME);
				
		cuenta.setText(currentCartaPago.getTtooDeudor().get(0));
		fecha.setText(currentCartaPago.getFecha());
		
		if (currentCartaPago.getSociedad().length() == 1) {
			sociedad.setText("0" + currentCartaPago.getSociedad());
		} else {
			sociedad.setText(currentCartaPago.getSociedad());
		}
		cme.setText(environmentVariables.get("CME")); // CONSOLA, VARIABLE DE ENTORNO, valor-> "am"

		GuiButton buttonContinuar= activeWindow.findById(TSap_F_32.windowCompensarDeudorDatosCabecera.BUTTON_CONTINUAR);
		buttonContinuar.press();
		
		server.debug("Datos Cabecera Seleccionados ...");
		sapf32popUpImpuestos();		// puede aparecer popUp impuestos 
		
		// Wait until the search is done x segundos
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S);
		// chequeo de errores de SAP
		String continuar = "";
		for(int i = 0; i < 2; i++) {
			continuar = checkStatusBarFail(sap.getCurrentSession().getMainWindow());
			server.debug("String checkStatus: " + continuar);
			if(continuar.equals(Constantes.CONTINUAR)) {
				buttonContinuar.press();
				// Wait until the search is done x segundos
				sap.getCurrentSession().waitIdle(Constantes.RETRY_S);
			}
		}
		
		
	}
	

	// Este metodo es el correspondiente a buscarPago
	
	public void sapF32CompensarDeudorProcesarPartidasAbiertas() throws BusinessException, SystemException {
		
		// tendremos que cargar partidas de deudores tantas veces como haya y luego la de xrisk siempre.
		// o sea, hacer lo de shift f2 y f6 tantas veces como 
		if(!noHayPartidasAbiertas) {// si hay partidas abiertas las cargamos, si no xrisk del tiron -> else
			server.debug("compensar deudor procesar partidas abiertas ...");
			server.info("GetTtooDeudor: " + currentCartaPago.getTtooDeudor());
			if (currentCartaPago.getTtooDeudor().size() > 0) { // si es mayor que 0 cargamos partidas 
				// El primero ya esta cargado siempre al buscar en la f-32 por lo tanto empezamos en la 1. esto es por si hubiera varios
				server.info(currentCartaPago.getTtooDeudor());
				for (int i = 1; i < currentCartaPago.getTtooDeudor().size(); i++) {
					server.info("Entramos en cargar partidas deudor para el codigo: " + currentCartaPago.getTtooDeudor().get(i));
					// aqui hacer lo correspondiente a lo de shiftf2 y f6, rellenar todo
					sapf32ProcesarPartidasAbiertas();
						//llamada a la funcion que haga f6
					sapf32CompensarDeudorVisualizarResumen();
						//llamada a la funcion que haga el relleno de datos
					server.debug("Vamos a seleccionar partidas abiertas");
					sapf32CompensarDeudorSeleccionarPartidasAbiertas("cambiarSiNecesario", currentCartaPago.getTtooDeudor().get(i), "d", "a");
					server.info("probadas partidas abiertas antes de xRisk");
				}
			}
		
			sapf32CompensarXrisk(); // xrisk cme vacio
		}else {// si no hay partidas abiertas, directamente cargar xRISK
			sapf32CompensarDeudorSeleccionarPartidasAbiertas("cambiarSiNecesario", "43009999", "s", "");
		}
		
		sapf32popUpImpuestos();		
		
		// ahora continuamos en misma pantalla
		sapf32SeleccionarPartidasRest();
	}
	
	private void sapf32popUpImpuestos() {
			// SI APARECE EL POP UP DARLE O ENTER O AL V VERDE, SI NO PUES NO HACER NADA
		server.debug("metodo POP-UP de impuestos");
		IGuiApplication sap = sapControl.getSap();
		GuiModalWindow modalWindow = sap.getCurrentSession().getModalWindow();
		// devuelve null si no existe, si no es nulo pues clic en el boton
		if(sap.getCurrentSession().getModalWindow() != null) {
			server.info("Ha aparecido POP-UP de impuestos, habra que darle a continuar");
			GuiButton buttonContinuar = modalWindow.findById(TSap_F_32.popUpImpuestos.BUTTON_CONTINUAR);
			buttonContinuar.press(); 
			sap.getCurrentSession().waitIdle(Constantes.RETRY_XS);
			// BARRA STATUSBAR? no sabemos si al hacer click en el boton verde/enter aparecera algo en statusbar
		}
		else {
			server.debug("No ha aparecido popUp de impuestos");
		}
	}
	
		
	private void sapf32CompensarDeudorVisualizarResumen() throws BusinessException {
		// f6 para siguiente ventana.
		IGuiApplication sap = sapControl.getSap();
//		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
			// f6, boton cancelar del menu tratar
		GuiMenu menu2 = activeWindow.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.BUTTON_CANCELAR_TRATAR);
		menu2.select();
			// Wait until the search is done
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		try {
			checkStatusBarFail(sap.getCurrentSession().getMainWindow());
		}catch(BusinessException e) {
			throw new BusinessException("No se ha podido hacer click en f6 button_cancelar_tratar", null, true);
		}
		
	}
	
	private void sapf32CompensarDeudorSeleccionarPartidasAbiertas(String soc, String cue, String clcu, String cme) throws BusinessException {
		// campo cuenta, clase de cuenta(d/s)  
		// f6 para siguiente ventana.
		server.debug("Cambiando datos en seleccionar Partidas abiertas");
		IGuiApplication sap = sapControl.getSap();
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		
//		GuiCTextField sociedad = userArea.findById(TSap_F_32.windowCompensarDeudorSeleccionarPartidasAbiertas.CTEXT_SOCIEDAD);
		GuiCTextField cuenta = userArea.findById(TSap_F_32.windowCompensarDeudorSeleccionarPartidasAbiertas.CTEXT_CUENTA);
		GuiCTextField claseCuenta = userArea.findById(TSap_F_32.windowCompensarDeudorSeleccionarPartidasAbiertas.CTEXT_CLASE_CUENTA);
		GuiCTextField ctext_cme = userArea.findById(TSap_F_32.windowCompensarDeudorSeleccionarPartidasAbiertas.CTEXT_CME);
		GuiButton buttonContinuar = activeWindow.findById(TSap_F_32.windowCompensarDeudorSeleccionarPartidasAbiertas.BUTTON_CONTINUAR);
		
		cuenta.setText(cue);
		claseCuenta.setText(clcu);
		ctext_cme.setText(cme);
		
		buttonContinuar.press();
		server.debug("datos cambiados ...");
		
			// Wait until the search is done
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		try {
			checkStatusBarFail(sap.getCurrentSession().getMainWindow());
		}catch(BusinessException e) {
			throw new BusinessException("Fallo al rellenar campos de cuenta, claseCuenta y cme seleccionando partidas abiertas", null, true);
		}
	}
	
	private void sapf32CompensarXrisk() throws BusinessException{
		server.debug("Seleccionando xRisk");
		sapf32ProcesarPartidasAbiertas();
			//llamada a la funcion que haga f6
		sapf32CompensarDeudorVisualizarResumen();
		//llamada a la funcion que haga el relleno de datos, pondremos s y -- duda existencial am para xrisk a para normal?
		sapf32CompensarDeudorSeleccionarPartidasAbiertas("cambiarSiNecesario", "43009999", "s", "");		
	}
	
	private void sapf32ProcesarPartidasAbiertas() throws BusinessException {
		IGuiApplication sap = sapControl.getSap();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
			// shift f2, boton cancelar del menu tratar
		GuiMenu menu = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_CANCELAR);
		menu.select();
			// Wait until the search is done
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		try {
			checkStatusBarFail(sap.getCurrentSession().getMainWindow());
		}catch(BusinessException e) {
			throw new BusinessException("No se ha podido hacer click en shiftf2 button_cancelar", null, true);
		}
	}
	
	private void sapf32SeleccionarPartidasRest() throws SystemException, BusinessException {
		server.info("Entramos en seleccionar partidas rest");
		windows.pause(1000); // pausa por si acaso
		IGuiApplication sap = sapControl.getSap();
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		server.debug("No ha petado en userArea");
			// primero se hace clic en desactivar partidas
		try {
			GuiButton desactivarPartidas = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_DESACTIVAR_PARTIDAS);	
			server.debug("No ha petado en desmarcar");
			// despues se cambia a ventana partRest
			desactivarPartidas.press();
		}catch(Exception e) {
			server.debug("Identificador de boton erroneo, probamos con 03");
			GuiButton desactivarPartidas = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_DESACTIVAR_PARTIDAS2);
			server.debug("No ha petado en desmarcar2");
			// despues se cambia a ventana partRest
			desactivarPartidas.press();
		}
		server.debug("Desactivadas las partidas");
		sap.getCurrentSession().waitIdle(Constantes.RETRY_XS * 1000);
		// se hace de esta manera ya que el guitab nos estaba dando problemas, no obtenia el elemento 
//		ActiveXComponent Obj = new ActiveXComponent(sap.getComponent().invoke("findById", "ses[0]/wnd[0]/usr/tabsTS/tabpREST").toDispatch());
//		Obj.invoke("select");
		server.debug(sap.getCurrentSession().getActiveWindow().getUserArea().findById("tabsTS/tabpREST"));
		GuiTab partRest = sap.getCurrentSession().getActiveWindow().getUserArea().findById("tabsTS/tabpREST");
		partRest.select();
		server.debug("Ha hecho click en partRest");
		
		sap.getCurrentSession().waitIdle(Constantes.RETRY_XS * 1000);
		server.debug("Estamos en ventana partRest y no partMAIN");
		
		// OJO EL CASO DEL ANTICIPO
		server.info("El numero de saldos depositos es: " + currentCartaPago.getSaldosDeposito().size());
		if (currentCartaPago.getSaldosDeposito().size()>0) {
			sapf32TratarSaldoDeposito();
		}
		else {
			sapf32TratarPago();
		}
	}
	
			
	private void sapf32TratarSaldoDeposito() throws BusinessException {
		server.info("Empieza a tratar Saldo Deposito");
		String importe = "";
		int countOfDepositos = 1;
		IGuiApplication sap = sapControl.getSap();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		String id = TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.popUpBuscarImporte.BUTTON_CERRAR;
		for(String saldoDeposito : currentCartaPago.getSaldosDeposito()) {
			sapf32AplicarFiltroPorImporte(); // seleccionamos el filtro
			sapf32AnyadirLimites(saldoDeposito);// elegimos los valores para el filtro
			if(sapf32AparecePopUpNoEncuentraElPago(id) == true) {// si no encuentra el pago, cierra popups 
				server.info(Constantes.NOENCUENTRAELPAGO);
			}
			else {
				server.debug("He encontrado el deposito: " + countOfDepositos +" de " + currentCartaPago.getSaldosDeposito().size());
				importe = sap32ObtenerImporte();
				if(importe.contains("-")) {
					hayPago = true;
					server.info("El importe contiene - , hay pago");
					//En vez de doble click, habra que setfocus en el valor que queremos y luego activar partidas
					sapf32marcarPartidaComoHacerDobleClick();
				}
				else {
					server.info("Importe no contiene - , no hay pago");
					hayPago = false;
				}
				
				//Hay que comprobar si el deposito actual es el ultimo o no
				//si es el primero, se compensa enteramente, si es el ultimo se hace una partida por el resto en caso de ser negativo
				if(countOfDepositos >= currentCartaPago.getSaldosDeposito().size() && Double.toString(otros).contains("-")) {					
					sapf32AnyadirSaldoDepositos();
				}
				if(countOfDepositos >= currentCartaPago.getSaldosDeposito().size() && !Double.toString(otros).contains("-")) {
					//Aqui tendriamos que crear un pago por la cantidad restante, un 06 como si fuera normal y pendiente de compensar
					sapf32AsientoPorImporte(String.valueOf(otros));// una vez llamamos a este metodo, estaremos en compensar deudor, crear partidas por resto
				}
				// JGRAU, este atras es para volver a poder aplicar filtro y encontrar otro deposito si hay mas de 1
				GuiButton cancelar = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_BACK);
				cancelar.press();
				server.debug("He vuelto a la pantalla donde estan todas las partidas");
				sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
				checkStatusBarFail(sap.getCurrentSession().getMainWindow());
				try {
					checkStatusBarFail(sap.getCurrentSession().getMainWindow());
				}catch(BusinessException e) {
					throw new BusinessException("Fallo al volver atras para encontrar mas depositos", null, true);
				}
				countOfDepositos++;
			}
		}
	}
	
	private void sapf32AplicarFiltroPorImporte() {
		IGuiApplication sap = sapControl.getSap();
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		server.debug("Aplicando filtro por importe");
		GuiButton botonFiltro = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_BUSCAR_BARRATAREAS);
		botonFiltro.press();
		// Wait until the search is done
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		// como aparece popup tendremos que volver a calcular la pestanya en la que estemos		
		activeWindow = sap.getCurrentSession().getActiveWindow();
		userArea = sap.getCurrentSession().getModalWindow().getUserArea();
		
		GuiRadioButton filtrarPorImporte = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.RBUTTON_IMPORTE);
		filtrarPorImporte.setFocus();
		filtrarPorImporte.select(); 
		
		GuiButton botonAceptarFiltro = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.BUTTON_OK);
		botonAceptarFiltro.press();			
		// Wait until the search is done
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		server.debug("Se ha aplicado el filtro por importe");
	}
	
	private void sapf32AnyadirLimites(String saldoDeposito) {
		IGuiApplication sap = sapControl.getSap();
		saldoDeposito = saldoDeposito.replace("-", "");
		server.info("El saldo deposito inicial es: " + saldoDeposito);
		double limiteInferior = importeToDouble(saldoDeposito) - 2;
		double limiteSuperior = importeToDouble(saldoDeposito) + 2;
		
		ActiveXComponent Obj = new ActiveXComponent(sap.getComponent().invoke(Constantes.FINDBY, "ses[0]/wnd[2]/usr/sub:SAPDF05X:0730/txtRF05A-VONWT[0,0]").toDispatch());
		Obj.setProperty("Text", String.valueOf(limiteInferior).replace(".", ","));
		ActiveXComponent Obj2 = new ActiveXComponent(sap.getComponent().invoke(Constantes.FINDBY, "ses[0]/wnd[2]/usr/sub:SAPDF05X:0730/txtRF05A-BISWT[0,20]").toDispatch());
		Obj2.setProperty("Text", String.valueOf(limiteSuperior).replace(".", ","));
		ActiveXComponent Obj3 = new ActiveXComponent(sap.getComponent().invoke(Constantes.FINDBY, Constantes.TBAR0_BTN0).toDispatch());
		server.debug("limites de tratar saldo deposito anyadidos");
		Obj3.invoke(Constantes.PRESS);
		server.debug("boton filtro aplicado clicado");
			// Wait until the search is done
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
	}
	
	private ArrayList<String> sapf32AnyadirLimitesTratarPago(String importe) {
		server.debug("Anyadiendo limites tratar pago");
		ArrayList<String> array = new ArrayList<>();
		double limiteInferior = 0.0;
		double limiteSuperior = 0.0;
		
		IGuiApplication sap = sapControl.getSap();
		if(Double.valueOf(importe) > 2) {
			limiteInferior = Double.valueOf(importe) - 2;
			limiteInferior = Math.round(limiteInferior * 100) / 100d;
		}
		limiteSuperior = Double.valueOf(importe) + 2;
		limiteSuperior = Math.round(limiteSuperior * 100) / 100d;
			
		server.info("Limite inferior: " + limiteInferior);
		server.info("Limite superior: " + limiteSuperior);
		// ESTAMOS TENIENDO PROBLEMAS CON LA ACTIVE WINDOW, quiza haya qye usar modal window
//		GuiTextField limInferior = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.popUpBuscarImporte.TEXT_DESDE);
//		GuiTextField limSuperior = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.popUpBuscarImporte.TEXT_HASTA);
//		GuiButton botonAplicarFiltro = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.popUpBuscarImporte.BUTTON_OK);
		
//		limInferior.setText("");
		ActiveXComponent Obj = new ActiveXComponent(sap.getComponent().invoke(Constantes.FINDBY, "ses[0]/wnd[2]/usr/sub:SAPDF05X:0730/txtRF05A-VONWT[0,0]").toDispatch());
		Obj.setProperty("Text", String.valueOf(limiteInferior).replace(".", ","));
		ActiveXComponent Obj2 = new ActiveXComponent(sap.getComponent().invoke(Constantes.FINDBY, "ses[0]/wnd[2]/usr/sub:SAPDF05X:0730/txtRF05A-BISWT[0,20]").toDispatch());
		Obj2.setProperty("Text", String.valueOf(limiteSuperior).replace(".", ","));
		ActiveXComponent Obj3 = new ActiveXComponent(sap.getComponent().invoke(Constantes.FINDBY, Constantes.TBAR0_BTN0).toDispatch());
		

		
		
		
		
//		limInferior.setText(String.valueOf(limiteInferior).replace(".", ","));
//		limSuperior.setText(String.valueOf(limiteSuperior).replace(".", ","));
		server.debug("limites de tratar pago anyadidos");
		Obj3.invoke(Constantes.PRESS);
//		botonAplicarFiltro.press();
		server.debug("boton filtro aplicado clicado");
			// Wait until the search is done
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		
		array.add(String.valueOf(limiteInferior));
		array.add(String.valueOf(limiteSuperior));
		
		
		
		return array;
		
	}
	
	
	private boolean sapf32ComprobarUnaPartida() {
		boolean unaPartida = false;
		String partida = "";
	
		IGuiApplication sap = sapControl.getSap();
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
//		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		
		GuiTextField partidas = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.TEXT_PARTIDAS);
		partida = partidas.getText();
		
		if(partida.equals("1")) {
			unaPartida = true;
		}

		return unaPartida;
	}
	
	/*
	 * Funcion que comprueba si aparece o no el popup de no encuentra el pago, si aparece el popup click en okay.
	 */
	private boolean sapf32AparecePopUpNoEncuentraElPago(String id) {
		boolean aparece = false;
			// SI APARECE EL POP UP DARLE O ENTER O AL V VERDE, SI NO PUES NO HACER NADA
		server.debug("comprobando si aparece o no popup de no encuentra el pago");
		IGuiApplication sap = sapControl.getSap();
//		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiModalWindow modalWindow = sap.getCurrentSession().getModalWindow();
		// devuelve null si no existe, si no es nulo pues clic en el boton
		if(sap.getCurrentSession().getModalWindow() != null) {
			server.sendScreen("No encuentra el pago");
			GuiButton buttonContinuar = modalWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.popUpNoEncuentraPago.BUTTON_CONTINUAR);
			buttonContinuar.press(); 
			sap.getCurrentSession().waitIdle(Constantes.RETRY_XS);
			// cerrar los dos popups para volver a la ventana de partidas abiertas, pestanya partrest.
			// TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.popUpBuscarImporte.BUTTON_CERRAR);
			// TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.popUpBuscarReferencia.BUTTON_CERRAR);
			modalWindow = sap.getCurrentSession().getModalWindow();
			GuiButton cerrarPopUp1 = modalWindow.findById(id);
			cerrarPopUp1.press();
			sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
			server.debug("popUp cerrado");
			modalWindow = sap.getCurrentSession().getModalWindow();
			GuiButton cerrarPopUp2 = modalWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.BUTTON_CERRAR);
			cerrarPopUp2.press();
			sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
			server.debug("popup2 cerrado");
			aparece = true;
		}
		return aparece;
		
	}
	
	private void sapf32AnyadirSaldoDepositos() throws BusinessException{
		server.debug("anyadir saldo depositos");
		windows.pause(1000);
		IGuiApplication sap = sapControl.getSap();
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		GuiTextField saldoDepositos = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.TEXT_SALDO);
		GuiButton buttonContinuar = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_CONTINUAR);
		
		// Hay que quitar el simbolo del euro si viene, quitar los espacios y cambiar el punto por coma
		//a la hora de escribir el resto que queda
		
		String aEscribir = Double.toString(otros).replaceAll("€", "").trim().replace(".", ",");
		server.debug("Lo que se va a escribir en SAP es: " + aEscribir);
		
		saldoDepositos.setText(aEscribir);
		buttonContinuar.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		try {
			checkStatusBarFail(sap.getCurrentSession().getMainWindow());
		}catch(BusinessException e) {
			throw new BusinessException("Fallo al hacer click en continuar al escribir origen de diferencias", null, true);
		}
//		server.sendScreen("try catch?eso que es? pero manda emails? entonces no funciona");
		
	}
	
	private void sapf32AsientoPorImporte(String importe) throws BusinessException {
		server.debug("Entramos en asiento por el pago para el importe: " + importe);
		IGuiApplication sap = sapControl.getSap();// Estaremos en la pantalla donde se encuentra todo marcado
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		
		GuiMenu buttonCancelar = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_CANCELAR);
		buttonCancelar.select();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		
		userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		
		GuiCTextField claveCt = userArea.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.CTEXT_CLVCT);
		claveCt.setText("06");// Siempre va a ser asi si no encontramos el pago
		
		GuiCTextField cuenta = userArea.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.CTEXT_CUENTA);
		// Si no hay pago el asiento siempre se hace por el primer deudor que seria el principal
		cuenta.setText(currentCartaPago.getTtooDeudor().get(0));
		
		GuiButton buttonContinuar = activeWindow.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.BUTTON_CONTINUAR);
		buttonContinuar.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
//		checkStatusBarFail(sap.getCurrentSession().getMainWindow());
		try {
			checkStatusBarFail(sap.getCurrentSession().getMainWindow());
		}catch(BusinessException e) {
			throw new BusinessException("Fallo al rellenar los campos para crear apunte contable", null, true);
		}
		
		userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		activeWindow = sap.getCurrentSession().getActiveWindow();
		
		GuiTextField txtImporte = userArea.findById(TSap_F_32.windowCompensarDeudorAnadirPosicionDeDeudor.TEXT_IMPORTE);
		txtImporte.setText(importe.replace(".", ","));
		
		// asignacion
		GuiTextField asignacion = userArea.findById(TSap_F_32.windowCompensarDeudorAnadirPosicionDeDeudor.TEXT_ASIGNACION);
		//Puede petar porque quiza sea text y no ctext
		GuiCTextField texto = userArea.findById(TSap_F_32.windowCompensarDeudorAnadirPosicionDeDeudor.CTEXT_TEXTO);
		asignacion.setText("PDT Compensar");
		texto.setText("PDT Compensar");
//		server.sendScreen("Rellenados campos, vamos a continuar");
		GuiButton buttonCont = activeWindow.findById(TSap_F_32.windowCompensarDeudorAnadirPosicionDeDeudor.BUTTON_CONTINUAR);
		buttonCont.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
//		checkStatusBarFail(sap.getCurrentSession().getMainWindow());
		try {
			checkStatusBarFail(sap.getCurrentSession().getMainWindow());
		}catch(BusinessException e) {
			throw new BusinessException("Fallo al rellenar los campos una vez se ha creado el apunte contable", null, true);
		}
		
		activeWindow = sap.getCurrentSession().getActiveWindow();
		
		// boton tratar PAs
		GuiButton buttonTratarPAs = activeWindow.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.BUTTON_TRATAR_PASS);
		buttonTratarPAs.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		checkStatusBarFail(sap.getCurrentSession().getMainWindow());
		
	}
	
	
	private String sap32ObtenerImporte() {
		server.debug("metodo obtener importe");
		String importe = "";
		
		IGuiApplication sap = sapControl.getSap();// Estaremos en la pantalla donde se encuentra todo marcado
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
//		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		
		GuiMainWindow window = sap.getCurrentSession().getMainWindow();
		server.debug("Window: " +window.getId());
		//primera posicion importeNeto.
		GuiTextField importeNeto = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.TEXT_IMPORTE_NETO);
		importeNeto.setFocus(); // marcamos el focus para poder clasificar ascendentemente
		server.debug("Focus en importe neto");
		GuiButton clasifAscendente = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_CLASIF_ASC);
		clasifAscendente.press(); // clasificamos ascendentemente y una vez clasificado obtener valor importe.
		server.debug("clasificacion ascendente seleccionada");
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		
		// hay que volver a establecer el elemento, si no falla
		importeNeto = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.TEXT_IMPORTE_NETO);
		importe = importeNeto.getText();
		server.debug("Importe seleccionado: " + importe);
		
		return importe;
		
	}
	
	private void sapf32marcarPartidaComoHacerDobleClick(){
		server.debug("marcando partidas (hacer doble click)");
		IGuiApplication sap = sapControl.getSap();// Estaremos en la pantalla donde se encuentra todo marcado
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
//		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		
		GuiTextField importeNeto = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.TEXT_IMPORTE_NETO);
		importeNeto.setFocus(); // marcamos el focus para poder marcarPartidas
		
		GuiButton marcarPartidas = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_PARTIDA);
		marcarPartidas.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
//		server.sendScreen("Partida marcada");
		
	}
	
	private String sapf32ObtenerImporteSinAsignar() {
		server.debug("obteniendo importe sin asignar");
		String importe = "";
		IGuiApplication sap = sapControl.getSap();// Estaremos en la pantalla donde se encuentra todo marcado
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
//		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		
		GuiTextField sinAsignar = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.TEXT_SIN_ASIGNAR);
		
		importe = sinAsignar.getText();
		server.debug("Importe sin asignar obtenido: " + importe);
		
		return importe;
	}
		
	
	
	private void sapf32TratarPago() throws SystemException, BusinessException {
		server.debug("Empieza a tratar Pago");
		String importe = "";
		sapf32AplicarFiltroPorImporte();
		
		ArrayList<String> arra = sapf32AnyadirLimitesTratarPago(currentCartaPago.getImporte());// elegimos los valores para el filtro
		String limiteInferior = arra.get(0);
		String limiteSuperior = arra.get(1);
		
		String id = TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.popUpBuscarImporte.BUTTON_CERRAR;
		// Aqui hay que buscar la imagen de fallo del rango, es una imagen que se levanta si el pago no existe entre
		// el rango especificado
		if(sapf32AparecePopUpNoEncuentraElPago(id) == true) {// si no encuentra el pago, cierra popups 
			server.info(Constantes.NOENCUENTRAELPAGO);
		}
		else {
			if(sapf32ComprobarUnaPartida() == true) {
				server.info("Imagen de una partida encontrada, solo hay un pago"); //seleccionaremos el importe neto de la fila unica
				server.sendScreen("Pago localizado tras filtro");
			}
			else {
				server.sendScreen("Hay mas de una partida, comprobar");
				server.warn("Hay mas de una partida"); // seleccionaremos el importe neto de la primera fila
				mensajeDeError = "Sin error: Se ha encontrado mas de 1 partida al buscar pago, comprobar compensacion correcta";
			}
			importe = sap32ObtenerImporte();
			if(importe.contains("-")) {
				server.debug("El importe contiene - , hay pago");
				hayPago = true;									
				//pincharEnImporte("dosVeces");//En vez de doble click, habra que setfocus en el valor que queremos y luego activar partidas
				sapf32marcarPartidaComoHacerDobleClick();
				
				// obtener importe sin asignar
				String importeSinAsingar = sapf32ObtenerImporteSinAsignar();
				
				if(importeSinAsingar.contains("-") || importeToDouble(importeSinAsingar)>=importeToDouble(limiteSuperior) || importeToDouble(importeSinAsingar)<=importeToDouble(limiteInferior)) {
					server.info("No es posible detectar el importe total de la carta de pago");
					// el null de la system nos generara un targetinvocationerror de causa. en lugar de system
					throw new SystemException("No es posible detectar el importe total de la carta de pago", null , "fin", true);
					//throw new AWTException("No es posible detectar el importe total de la carta de pago");
				}
				
				IGuiApplication sap = sapControl.getSap();// Estaremos en la pantalla donde se encuentra todo marcado
//				GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
				GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
				GuiButton back = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_BACK);
				
				back.press();
				server.debug("Volviendo atras al encontrar pagos, se efectuo el retroceso a la lista basica");
				sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
//				checkStatusBarFail(sap.getCurrentSession().getMainWindow());
				try {
					checkStatusBarFail(sap.getCurrentSession().getMainWindow());
				}catch(BusinessException e) {
					throw new BusinessException("Fallo al volver atras al encontrar pago en tratarpago", null, true);
				}
				
			}
			else {
				server.info("No existe el pago");
				hayPago = false;
			}
		}
	}
			
	private void sapf32OrdenarPartidasPorReferencia() {
		server.debug("Metodo ordenar partidas por referencia");
		
		IGuiApplication sap = sapControl.getSap();// Estaremos en la pantalla donde se encuentra todo marcado
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		
		//primera posicion referencia.
		GuiTextField referencia = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.TEXT_REFERENCIA);
		referencia.setFocus(); // marcamos el focus para poder clasificar descendentemente
		server.debug("setFocus en referencia");
		GuiButton clasifDesc = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_CLASIF_DES);
		clasifDesc.press(); // clasificamos descendentemente 
		server.debug("clasificado descendentemente");
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
	}
	
	private void sap32SetFocusImporte() {
		server.debug("Metodo setfocus en importe");
		
		IGuiApplication sap = sapControl.getSap();// Estaremos en la pantalla donde se encuentra todo marcado
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		
		//primera posicion importeNeto.
		GuiTextField importeNeto = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.TEXT_IMPORTE_NETO);
		importeNeto.setFocus(); // marcamos el focus para poder clasificar ascendentemente
		
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		
	}
		
		
		

	public String estaPago() {
		if (hayPago) {
			return "Si";
		} else {
			return "No";
		}
	}
	
	public void asientoPorElPago() throws BusinessException {
		sapf32AsientoPorImporte(currentCartaPago.getImporte());

	}
	
	
	public void rellenarArrayFacturas() {
//		listaDiferenciasEnFacturas = new ArrayList<String>();
		for (Factura fact : currentCartaPago.getFacturas()) {
			if (fact.getTipo().equalsIgnoreCase(Constantes.FACTURA)
					|| fact.getTipo().equalsIgnoreCase(Constantes.ABONODESCONTADO)) {
				facturasAMarcar.add(fact.getIdentificador());
				
				server.setCurrentItem(itemContador, "Items de facturas a marcar");
				itemContador++;
			}
			else { // si no son facturas o abonos descontados habra que compensarlas
//				facturasACompensar.add(fact.getIdentificador());
				facturasACompensar.add(fact);
				server.setCurrentItem(itemContador, "Items de facturas a compensar");
				itemContador++;
				
			}
		}
		server.setNumberOfItems(facturasAMarcar.size() + facturasACompensar.size());//server.setNumberOfItems(currentCartaPago.getFacturas().size());
		if(facturasAMarcar.isEmpty()) {
			server.info("La lista de diferencias es 0, no hay pagos de mas");
		}
		else if(facturasACompensar.isEmpty()) {
			server.info("No hay facturas que no sean de tipo factura o abono descontado");
		}
		
	}
	
	public String quedanFacturasPorProcesar() {
		server.info("Numero de Factura Actual(Item actual): " + currentItem); //currentItem);
		server.info("Numero facturas de tipo factura o abono descontado: " + facturasAMarcar.size());
		if (currentItem < facturasAMarcar.size()) {
			currentFactura = facturasAMarcar.get(currentItem);
			currentItem++;
			// listafacturas a amarcar
			return "Si";
		
		} else {
			return "No";
		}
	}
	
	

	
	private void sapf32filtrarFacturasPorReferencia() {
		server.debug("Metodo filtrar facturas por referencia");
		// filtro por referencia 
		IGuiApplication sap = sapControl.getSap();// Estaremos en la pantalla donde se encuentra todo marcado
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
//		server.sendScreen("prueba");
		GuiButton filtro = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_BUSCAR_BARRATAREAS);
		filtro.press();
		server.debug("boton de filtro clicado");
//		server.sendScreen("prueba2 antes de wait");
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
//		server.sendScreen("despues de waitidl");
		GuiModalWindow modal = sap.getCurrentSession().getModalWindow();
		server.debug("ModalWindow popup filtro ref " + modal.getId());
		// creo que va a haber que hacerlo como los popups anteriores, porque no coge bien la window
		userArea = sap.getCurrentSession().getModalWindow().getUserArea();
		GuiMainWindow window = sap.getCurrentSession().getMainWindow();
		GuiModalWindow modalwindow = sap.getCurrentSession().getModalWindow();
		
		server.debug("window: " + window.getId());
		server.debug("windowModal: " + modalwindow.getId());
		server.debug("userarea: " + userArea.getId());
		
		GuiRadioButton referencia = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.RBUTTON_REFERENCIA);
		
		referencia.setFocus();
		referencia.select();
		server.debug("radiobuton de referencia seleccionada,");
		
		GuiButton ok = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.BUTTON_OK);
		
		ok.press();
		server.debug("ok seleccionado");
		
		// Wait until the search is done
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
//				checkStatusBarFail(sap.getCurrentSession().getMainWindow());
		sap = sapControl.getSap();// Estaremos en la pantalla donde se encuentra todo marcado
		userArea = sap.getCurrentSession().getModalWindow().getUserArea();
		activeWindow = sap.getCurrentSession().getActiveWindow();
		
		GuiModalWindow modalWindow2 = sap.getCurrentSession().getModalWindow();
		server.debug("ModalWindow2 popupReferencia de.. " + modalWindow2.getId()); // nos esta dando la window1, no la 2
		
		ActiveXComponent textDe = new ActiveXComponent(sap.getComponent().invoke(Constantes.FINDBY, "ses[0]/wnd[2]/usr/sub:SAPDF05X:0731/txtRF05A-SEL01[0,0]").toDispatch());
		ActiveXComponent checkBoxString = new ActiveXComponent(sap.getComponent().invoke(Constantes.FINDBY, "ses[0]/wnd[2]/usr/sub:SAPDF05X:0731/chkRF05A-XSTRN[0,62]").toDispatch());
		ActiveXComponent buttonokReferencia = new ActiveXComponent(sap.getComponent().invoke(Constantes.FINDBY, Constantes.TBAR0_BTN0).toDispatch());
		
//		GuiTextField de = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.popUpBuscarReferencia.TEXT_DE);
//		GuiCheckBox string = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.popUpBuscarReferencia.CHECK_BOX_STRING);
//		GuiButton okReferencia = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.popUpBuscarReferencia.BUTTON_OK);
//		de.setText(currentFactura);
		textDe.setProperty("Text", currentFactura);
//		server.sendScreen("Referencia de escrita");
		
		
		if(!currentFactura.contains("F") && !currentFactura.contains("A") && !touroperador.getTouroperadorName().equalsIgnoreCase(Constantes.GENERICO)) {
			checkBoxString.setProperty("selected", 0); // si queremos marcarla valor 0, si desmarcar creo que -1, aunque recorder indica setfocus
//			string.setSelected(true);
			server.debug("checkbox Marcado");
		}
//		okReferencia.press();
		buttonokReferencia.invoke(Constantes.PRESS);
		server.debug("Ok seleccionado");
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000); // Wait until the search is done
	}
	private void sapf32filtrarFacturasPorAsignacion() {
		// filtro por asignacion 
		IGuiApplication sap = sapControl.getSap();
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		
		GuiButton filtro = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_BUSCAR_BARRATAREAS);
		filtro.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		windows.getKeyboard().pageDown().pause(); //haremos esto para que aparezca asignacion, no hay otra
		server.debug("Se ha hecho el scrol hacia abajo");
		userArea = sap.getCurrentSession().getModalWindow().getUserArea();
		GuiRadioButton asignacion = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.RBUTTON_ASIGNACION);
		asignacion.setFocus();
		asignacion.select();
		
		GuiButton ok = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.BUTTON_OK);
		
		ok.press();
		// Wait until the search is done
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		sap = sapControl.getSap();// Estaremos en la pantalla donde se encuentra todo marcado
		userArea = sap.getCurrentSession().getModalWindow().getUserArea();
		activeWindow = sap.getCurrentSession().getActiveWindow();
		
		// ESTAMOS TENIENDO PROBLEMAS CON LA modal WINDOW 2
		ActiveXComponent de = new ActiveXComponent(sap.getComponent().invoke(Constantes.FINDBY, "ses[0]/wnd[2]/usr/sub:SAPDF05X:0731/txtRF05A-SEL01[0,0]").toDispatch());
		de.setProperty("text", currentFactura);
		ActiveXComponent string = new ActiveXComponent(sap.getComponent().invoke(Constantes.FINDBY, "ses[0]/wnd[2]/usr/sub:SAPDF05X:0731/chkRF05A-XSTRN[0,62]").toDispatch());
		ActiveXComponent okAsignacion = new ActiveXComponent(sap.getComponent().invoke(Constantes.FINDBY, Constantes.TBAR0_BTN0).toDispatch());
	
		
		if(!touroperador.getTouroperadorName().equalsIgnoreCase(Constantes.GENERICO) || !currentFactura.contains("(")) {
			server.debug("Marcando el checkbox string, ttoo no generico o factura sin (");
			string.setProperty("selected", -1); // con -1 deberia activar, con 0 desactivar
		}
			
		okAsignacion.invoke(Constantes.PRESS);
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000); // Wait until the search is done
	}
	
	private void sapf32CompensarPorElTotal(Double doubleDiferencia, String diferencia) throws BusinessException {
		server.debug("Compensar por el total");
		IGuiApplication sap = sapControl.getSap();
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		String check = "";
		GuiMainWindow win = sap.getCurrentSession().getMainWindow();
		server.debug("Win: " + win. getId());
		GuiTextField partRest = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.TEXT_PARTIDA_REST);
		
		if (doubleDiferencia != 0) {
			if(currentFacturaCompleta.getTipo().equalsIgnoreCase(Constantes.ABONODESCONTADO)) {
				server.setCurrentItemResultToWarn("Factura no marcada, partRest!=0 siendo abono, no se puede continuar: " + currentItem);
				throw new BusinessException("No es posible realizar apunte por el resto sobre un abono.", "fin", true);
			}else {
				server.info("No se compensa por el total");
				partRest.setText(diferencia);
				server.setCurrentItemResultToOK("Factura marcada, partRest!=0: " + currentItem);
			}
/*
			//: hago un enter(continuar) para que se vaya el popup amarillo LO HE HECHO Y FALLA IGUALMENTE, NO SE DEBERA PODER HACER
			activeWindow = sap.getCurrentSession().getActiveWindow();
			GuiButton continuar = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_CONTINUAR);
			continuar.press();
			server.debug("hacemos click en continuar para evitar warning amarillo"); // si no cambiar y hacer un checkstatusbar...
*/
		}
		else {
			server.info("Se compensa por el total");
			server.setCurrentItemResultToOK("Factura marcada: " + currentItem);
		}
		// si es distinto como si no, estaremos en la pantalla filtrada, habra que desfiltrar con f3 para ver a todas las partidas
		GuiButton atras = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_BACK);
		atras.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);		
		// chequeo de errores de SAP
		check = checkStatusBarFail(sap.getCurrentSession().getMainWindow());
		if(check.equals(Constantes.CONTINUAR)) {
			server.debug("Signo negativo, compruebe signo, damos a continuar");
			GuiButton continuar = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_CONTINUAR);
			continuar.press();
			sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);	
			checkStatusBarFail(sap.getCurrentSession().getMainWindow());
		}

	}
	
	private void sapf32marcarPartidaPorResto() throws BusinessException { // hay que hacer un setfocus a importe y clicar en marcar partidas (doble click es igual).
		server.debug("Marcar Partidas por resto, setfocus en importe y marcar partidas");
		IGuiApplication sap = sapControl.getSap();
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiTextField importeNeto = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.TEXT_IMPORTE_NETO);
		GuiButton activarPart = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_PARTIDA);
		importeNeto.setFocus();
		server.debug("focus en importe");
		activarPart.press();
		server.debug("marcadas partidas");
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		importeNeto = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.TEXT_IMPORTE_NETO);
		String precioSap = importeNeto.getText(); // para obtenerlo tenemos que volver a declararlo, no sabemos por que, esto en empark no pasaba
		precioSap = precioSap.replace(" ", "").replace("-", "");
		server.info("El precio leido de sap es " + precioSap);
		String precioFact = "";
		
		for (Factura fact : currentCartaPago.getFacturas()) {
			if (fact.getIdentificador().equalsIgnoreCase(currentFactura)) {
//				partRest.setText(fact.getImporte()); esto en el codigo anterior no hacia nada, esta mal! partRest se modifica con la diferencia
//				server.info("Introducido el importe: " + fact.getImporte() + "para la factura " + fact.getIdentificador());
				precioFact = fact.getImporte();
				currentFacturaCompleta = fact;
				break;
			}					
		}
		precioFact = precioFact.replace("(", "").replace("-", "").replace(")", "");
		Double doubleSap = importeToDouble(precioSap);
		Double doubleFact = importeToDouble(precioFact);
		server.info("Importe en sap: " + doubleSap);
		server.info("Importe en fact: " + doubleFact);

		Double doubleDiferencia = doubleSap - doubleFact;
		doubleDiferencia = Math.round(doubleDiferencia * 100) / 100d;

		String diferencia = String.valueOf(doubleDiferencia);
		diferencia = diferencia.replace(".", ",");
		server.info("El importe restante es " + diferencia);
		
		// si es factura marcar por el resto, si es abono no puede marcar el resto. business y escribir en excel
		sapf32CompensarPorElTotal(doubleDiferencia, diferencia);
	}
	
	
	
	public void sapF32IntroducirImportesFacturas() throws BusinessException {
		// antes de empezar, ordenaremos por referencia y dejaremos el focus en importe neto
		sapf32OrdenarPartidasPorReferencia();
		//setfocus en importe
		sap32SetFocusImporte();

		sapf32filtrarFacturasPorReferencia();
		// si no existe la factura, aparece pop up de no se encontraron partidas con las indicaciones seleccionadas
		// hay que hacer otro filtro. 
		String id = TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.popUpBuscarReferencia.BUTTON_CERRAR;
		String idAsig = TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.popUpSelectCriteriosBusqueda.popUpBuscarAsignacion.BUTTON_CERRAR;
		if(sapf32AparecePopUpNoEncuentraElPago(id) == true) {// si no encuentra referencia, cierra popups 
			server.info("NO ENCUENTRA EL IDENTIFICADOR por referencia: " + currentFactura);
			server.sendScreen("No ha encontrado el identificador");
			sapf32filtrarFacturasPorAsignacion();// filtramos por asignacion
			if(sapf32AparecePopUpNoEncuentraElPago(idAsig) == true) {// si no encuentra referencia, cierra popups 
				server.info("NO ENCUENTRA EL IDENTIFICADOR por asignacion: " + currentFactura);
				mensajeDeError = "NO ENCUENTRA EL IDENTIFICADOR ni por referencia ni por asignacion: " + currentFactura;
				throw new BusinessException("No ha encontrado el identificador ni por referencia ni por asignacion", null, true);
			}
		}
		// si se ha encontrado por referencia o asignacion
		server.info("Se ha encontrado identificador");
//		server.sendScreen("id encontrado");
		//Una vez se tenga una única línea correspondiente con la factura,
		//se obtiene el importe que aparece en el campo “Importe neto”, y se selecciona la línea,
		// para después introducir en el campo “Partida rest.”
		
		// hay que hacer un setfocus a importe y clicar en marcar partidas (doble click es igual) e insertar importe
		sapf32marcarPartidaPorResto();
		
	}
	

	// hay 2 bucles que rellenan los items. primero para marcarfacturas y luego para compensar. Son items distintos 
	// por lo que para obtener el item correspondiente a la factura actual del segundo bucle, se hace la resta 
	public String quedanFacturasPorCompensar() {
		server.info("Numero de Factura Actual(Item actual): " + currentItem); //currentItem);
		server.info("Numero facturas que no son ni facturas ni abono descontado: " + facturasACompensar.size());
		if (currentItem < facturasAMarcar.size() + facturasACompensar.size()) {
//			currentFactura
			currentFacturaCompleta = facturasACompensar.get(currentItem-facturasAMarcar.size());
			currentItem++;
			// listafacturas a amarcar
			return "Si";
			
		} else {
			return "No";
		}
	}
	
	public void sapf32IrAVisualizarResumenYCompensar() throws BusinessException {
		server.debug("Compensar Casuisticas");
		server.debug("Introducir Casuisticas");
		IGuiApplication sap = sapControl.getSap();
//		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		GuiButton resumenDoc = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_VISUALIZAR_DOC);
		resumenDoc.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		
		String codigoClvct = "";
		String tipoCasu = "";
		String cuenta = "";
		String cme = "";
		
		//TODO: Pendiente de pruebas, si no existen casuisticas y se meten datos vacios pasa algo?
		
		for (Casuistica casu : casuisticas.get(currentCartaPago.getNombreTuroperador())) {
			if (casu.getTipo().equalsIgnoreCase(currentFacturaCompleta.getTipo())) {
				codigoClvct = casu.getCodigoClvct();
				tipoCasu = casu.getTipo();
				cuenta = casu.getCuenta();
				cme = casu.getCme();
				server.info("Casuistica: " + tipoCasu + "  Codgio Clvct: " + casu.getCodigoClvct()
						+ " En la cuenta: " + cuenta + " Con el cme: " + cme);
			}
		}
		if (!codigoClvct.equalsIgnoreCase("-")) {
			sapf32AnyadirClvCt(codigoClvct);
		}
		
		sapf32AnyadirCuenta(cuenta);
		sapf32AnyadirCME(cme);
		
		// PROBAR!, creo que sera aqui donde tengamos que indicar que si es prepago haga la otra pantalla
		if (currentFacturaCompleta.getTipo().equalsIgnoreCase(Constantes.PREPAGO)) {
			server.debug("Es prepago, clvct19, cme A");
			sapf32ContabilizarAnyadirImportePrePagos();
		}
		else {
			sapf32ContabilizarAnyadirImporte();
		}
		server.setCurrentItemResultToOK("Factura compensada: " + currentItem);

		
		
	}
	
	public void volverAPantallaPrincipal() {
		server.debug("Volviendo a pantalla principal");
		// Para volver a la pantalla principal (shift + f4) Tratar PAs
		IGuiApplication sap = sapControl.getSap();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		GuiButton tratarPAs = activeWindow.findById(TSap_F_32.windowCompensarDeudorAnadirPosicionDeDeudor.BUTTON_TRATAR_PAS);
		
		tratarPAs.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);		
	}

	
	
	public String leerCampoSinAsignar() {
		String campoSinAsignar = "";
		
		
		server.debug("Entramos en lectura de campo sin asignar");

		stringSinAsignar = quedaPediente();
		

		server.info("Queda sin asignar: " + stringSinAsignar);
		if(stringSinAsignar.contains("-")) {
			stringSinAsignar = stringSinAsignar.replace("-", "");
			sinAsignar = importeToDouble(stringSinAsignar);
			sinAsignar *= -1;
			server.debug("sin Asignar negativo: " + sinAsignar);
		}
		else{
			sinAsignar = importeToDouble(stringSinAsignar);
		}


		if (sinAsignar == 0) {
			campoSinAsignar = "contabilizadoCorrecto";
		}
		else if (sinAsignar > 0) {
			campoSinAsignar = "pendienteAsignar";
		}
		else if (sinAsignar < 0 && sinAsignar >= -1) {
			campoSinAsignar = "comisionBancaria";
		}
		else if(sinAsignar < -1) {
			campoSinAsignar = "apunteContable";
		}
		server.info("Campo sin asignar - casuistica: " + campoSinAsignar);

			
		return campoSinAsignar;
	}
	
	// si es > 0
	public void pendienteAAsignar() throws BusinessException {
		server.debug("Entramos en metodo pendiente a asignar, valor > 0");
		IGuiApplication sap = sapControl.getSap();
//		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		GuiButton eliminarDiferencias = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_ELIMINAR_DIFERENCIAS);
		eliminarDiferencias.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		
		rellenarVentanaVisualizarResumenSinAsginar(Constantes.CLAVE_16, currentCartaPago.getTtooDeudor().get(0), "");
		rellenarImporteYTexto();
	}
	
	public void comisionesBancarias() throws BusinessException {
		server.debug("Entramos en metodo comisiones bancarias, valor < 0 y mayor que -1");
		IGuiApplication sap = sapControl.getSap();
//		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		GuiButton eliminarDiferencias = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_ELIMINAR_DIFERENCIAS);
		eliminarDiferencias.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		
		rellenarVentanaVisualizarResumenSinAsginar(Constantes.CLAVE_40, Constantes.CUENTA_COMISIONES_BANC, "");
		rellenarImporteYTexto();
	}
	
	public void apunteContable() throws BusinessException {
		server.debug("Entramos en metodo apunte contable, valor entre -1 y -infinito");
		IGuiApplication sap = sapControl.getSap();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		GuiButton eliminarDiferencias = activeWindow.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.BUTTON_ELIMINAR_DIFERENCIAS);
		eliminarDiferencias.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		
		rellenarVentanaVisualizarResumenSinAsginar(Constantes.CLAVE_06, currentCartaPago.getTtooDeudor().get(0), "");
		rellenarImporteYTexto();
	}
	
	// en este metodo postimputaremos si es necesario y finalmente guardaremos la contabilizacion
	public void postImputar() throws BusinessException {
		server.debug("Entrando a metodo Postimputar");
		boolean control = true; // control del boton de continuar 
		String mensaje = "";
		String funcion = "";
		IGuiApplication sap = sapControl.getSap();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		GuiButton guardarContab = activeWindow.findById(TSap_F_32.windowCompensarDeudorAnadirPosicionDeDeudor.BUTTON_CONTABILIZAR);
		guardarContab.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		mensaje = checkStatusBarFail(sap.getCurrentSession().getMainWindow());
		if(mensaje.equals("corregir posiciones")) {
			server.debug("Estamos en visualizar resumen, corregir posiciones marcadas");
			server.sendScreen("hay posiciones a corregir?");
			//do {
			while(control) {
					GuiButton postimp = activeWindow.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.BUTTON_POSTIMPUTAR);
					if(postimp != null) {
						server.debug("boton: " + postimp.getId());
						server.debug("boton: " + postimp.getText());
						funcion = pantallasPostImputar();
						if(funcion.equals("no")) { // si la funcion devuelve no, el btoon de postimputar no ha aparecido pero hace click en algo raro
							server.debug("No he vuelto a hacer el postimputar");
							control = false;
						}
					}
			}
			server.debug("Ya se han postimputado todas las partidas marcadas en azul");
			guardarContab.press();
			sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
			server.info("contabilizacion realizada");
		}
		else {
			server.info("Contabilizacion correcta");
		}
		// aqui obtenemos el numero de documento. al haberle dado a guardar 
		// Extracción del numero de documento contable
		String estausBarText = sap.getCurrentSession().getMainWindow().getStatusBar().getText();
		String numeroDocumento = getMatch("Doc\\.\\d+",estausBarText).replaceAll("Doc\\.", "");
		if (numeroDocumento != null) {
			server.info("Documento contable: " + numeroDocumento);
			currentCartaPago.setNumeroDocumento(numeroDocumento);
		}
		else {
			server.warn("No se ha contabilizado correctamente porque no ha aparecido la barra con el numero de doc");
		}
	}
	
	private String pantallasPostImputar() throws BusinessException {
		server.debug("Entrando en pantallas post-imputar, ha aparecido boton");
		String cont = "";
		
//		server.sendScreen("prueba");  ELIMNIAR
		IGuiApplication sap = sapControl.getSap();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		server.debug("Ventana activewindow: " + activeWindow.getId());
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiButton postimp = activeWindow.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.BUTTON_POSTIMPUTAR);
		server.debug("Vamos a hacer click en postimputar");
		postimp.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		String varControl = checkStatusBarFail(sap.getCurrentSession().getMainWindow());
		if(varControl.equals("no hay que postimputar mas")) {
			cont = "no";
			return cont;
		}
		server.debug("Estamos en la ventana donde copiar campos");
		// ahora cogeremos el campo asignacion y lo copiaremos en texto
		userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiTextField asig = userArea.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.windowCompensarDeudorCorregirPosicionDeDeudor.TEXT_ASIGNACION);
		GuiCTextField text = userArea.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.windowCompensarDeudorCorregirPosicionDeDeudor.CTEXT_TEXTO);
		String texto = asig.getText();
		server.debug("he cogido campo de asignar");
		text.setText(texto);
		server.debug("escribimos texto de asignar en texto");
		GuiButton continuar = activeWindow.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.windowCompensarDeudorCorregirPosicionDeDeudor.BUTTON_CONTINUAR);
		continuar.press();
		server.debug("continuar clicado");
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		activeWindow = sap.getCurrentSession().getActiveWindow();
		GuiButton visualizarRes = activeWindow.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.windowCompensarDeudorCorregirPosicionDeDeudor.BUTTON_VISUALIZAR_RES);
		server.debug("Vamos a pulsar vis resumen");
		visualizarRes.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		server.info("Corregida la partida por el resto para la factura de codigo: " + texto);
		return cont;
	}
	
	public void contabilizar() throws SystemException { // anexar documento
//		server.sendScreen("contabilizar");
		windows.pause(10000);
		server.debug("Contabilizar");
		// habra que anexar documento y 
			IGuiApplication sap = sapControl.getSap();
			GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		try {
			server.sendScreen("Antes de clicar en menu visualizar");
			GuiMenu menu = activeWindow.findById(TSap_F_32.windowCompensarDeudorDatosCabecera.BUTTON_DOCUMENTO);
			menu.select(); // es un menu, no un boton. // hacemos click en documento, visualizar para aparecer en la ventana correspondiente
			sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
			server.debug("Menu documento, visualizar seleccionado");
			activeWindow = sap.getCurrentSession().getActiveWindow();
			server.sendScreen("Clicado visualizar");
			GuiShell titlShellcontShell = activeWindow.findById(TSap_FB03.shell.TITL_SHELLCONT_SHELL);
			titlShellcontShell.getComponent().invoke(TSap_FB03.shell.acction.pressButton, new Variant(TSap_F_32.windowCompensarDeudorDatosCabecera.shell.BUTTON_SERVICIOS_OBJETO));
			server.sendScreen("press shell servicios");
			activeWindow = sap.getCurrentSession().getActiveWindow();
			GuiShell shellcontShell =  activeWindow.findById(TSap_FB03.shell.SHELLCONT_SHELL);
			shellcontShell.getComponent().invoke(TSap_FB03.shell.acction.pressContextButton, new Variant(TSap_F_32.windowCompensarDeudorDatosCabecera.shell.SHELL_BUTTON_CREAR));
			windows.pause(1000);
			shellcontShell.getComponent().invoke(TSap_FB03.shell.acction.selectContextMenuItem, new Variant(TSap_F_32.windowCompensarDeudorDatosCabecera.shell.SHELL_BUTTON_CREAR_ADJUNTO));
			windows.pause(1000);
			server.info("Guardamos el documento: " + currentCartaPago.getNombreDocumento());
			server.sendScreen("documento guardado");
	//		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
			windows.pause(1000);
		}
		catch(Exception e) {
			mensajeDeError = "No se ha podido anexar el documento";
			escribirExcel("NO");
			server.setCurrentItem(itemContador, "Carta de pago");
			server.setCurrentItemResultToOK("Numero documento: " + currentCartaPago.getNombreDocumento() + " - Numero de facturas a marcar: " + facturasAMarcar.size() + " - Numero facturas a compensar: " + facturasACompensar.size()); 
			throw new SystemException("No se ha podido anexar el documento", null, "", true);
		}
		
		
		//TODO: si currentCartaPago.getNombredoc, contiene ya la ruta, habra que hacer un split o directamente con el file parent y getname 
		File file = new File("C:\\Lopesan\\temporal\\" + currentCartaPago.getNombreDocumento());
		popUpImportarFichero(file.getParent(), file.getName());
		
		// cambio por si hay 2 partidas a la hora de buscar el filtro:
		if(mensajeDeError.isEmpty()) {
			escribirExcel("SI");
		}
		else {
			escribirExcel("NO"); // para el caso de mas de una partida abierta al encontrar el pago
		}
		
		GuiMenu finalizar = activeWindow.findById(TSap_F_32.windowCompensarDeudorDatosCabecera.popUpImportarFichero.BUTTON_FINALIZAR);
		finalizar.select();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		activeWindow = sap.getCurrentSession().getActiveWindow();
		GuiMenu finalizar2 = activeWindow.findById(TSap_F_32.windowCompensarDeudorDatosCabecera.BUTTON_FINALIZAR2);
		finalizar2.select();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		
		server.info("Procesamiento completado");
//		server.sendScreen("Termina la contablizacion");
		server.debug("Deberia hacer el ok");
		server.setCurrentItem(itemContador, "Carta de pago");
		server.setCurrentItemResultToOK("Numero documento: " + currentCartaPago.getNombreDocumento() + " - Numero de facturas a marcar: " + facturasAMarcar.size() + " - Numero facturas a compensar: " + facturasACompensar.size()); 
		server.info("Cerramos sap");
		sapControl.sapClose();
	}
	
	/**
	 * Gestión de los pop up para importar el documento en SAP
	 * 
	 * @param path
	 * @param name
	 * @throws SystemException 
	 * @throws BusinessException 
	 */
	private void popUpImportarFichero(String path, String name) throws SystemException {
		server.debug("popup Importar fichero");
		/*
		 * NO ESTA APARECIENDO LA VENTANA DE SAP SINO LA MANUAL, deberia aparecer la de scripting pero como sale la manual se hara con
		 * comandos windows
		 * 
		 * IGuiApplication sap = sapControl.getSap();
		GuiModalWindow modalWindow = sap.getCurrentSession().getModalWindow();
		GuiUserArea userArea = sap.getCurrentSession().getModalWindow().getUserArea();
//		GuiUserArea userArea = modalWindow.getUserArea();
		server.debug("Obtenida user area vamos a rellenar los campos directorio y documento");
		
		// Obtencion de elementos de SAP
		GuiTextField directorio = userArea.findById(TSap_F_32.windowCompensarDeudorDatosCabecera.popUpImportarFichero.CTEXT_DIRECTORIO);
		GuiCTextField documento = userArea.findById(TSap_F_32.windowCompensarDeudorDatosCabecera.popUpImportarFichero.CTEXT_NOMBRE_FICHERO);

		server.debug("escritura de campos directorio y documento...");
		// Escritura de campos en el pop up
		directorio.setText(path);
		documento.setText(name);
		
		// Presionar boton verde (enter)
		GuiButton buttonContinuar = modalWindow.findById(TSap_F_32.windowCompensarDeudorDatosCabecera.popUpImportarFichero.BUTTON_CONTINUAR);
		buttonContinuar.press();
		*/
		try {
			windows.clipboardSet(currentCartaPago.getNombreDocumento());
		} catch (Exception e) {
			throw new SystemException("No se ha podido copiarrrr el nombre del documento en el clipboard", null, "", true);
		}
		windows.pause(1000);
		windows.getKeyboard().pause().enter().pause().control("v").pause();
//		server.sendScreen("Se ha podido hacer control+v");
		windows.pause(3000);
		windows.getKeyboard().enter();
		
		
		String windowName = SapConstants.Titles.SAP_GUI_WINDOW;
		server.debug("Hacemos una pausa para esperar ventana");
		windows.pause(2000);
//		server.sendScreen("Deberia haber aparecido");
		try {
			windows.waitCondition(Constantes.INT_RETRY_S, 1000, "Waiting pop up Seguridad SAP GUI", null, false, (i,context) -> windows.getControl(windows.getWindow(windowName).gethWnd(),1018) != null);
			windows.pause(1000);
			HWND controlPermitir = windows.getControl(windows.getWindow(windowName).gethWnd(),1018);
			windows.clickButton(controlPermitir);
			
		} catch (Exception e) {
			server.warn("Ventana Seguridad SAP GUI no ha sido detectada.");
		}
		windows.pause(2000);
/*
		try {
			windows.waitCondition(Constantes.RETRY_S, 1000, "Waiting pop up Seguridad SAP GUI", null, false, (i,context) -> windows.getControl(windows.getWindow(windowName).gethWnd(),1018) != null);
			windows.pause(1000);
			HWND controlPermitir = windows.getControl(windows.getWindow(windowName).gethWnd(),1018);
			windows.clickButton(controlPermitir);
			
		} catch (Exception e) {
			server.warn("Ventana Seguridad SAP GUI no ha sido detectada.intento2");
		}
*/
		IGuiApplication sap = sapControl.getSap();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		String subidoCorrecto = sap.getCurrentSession().getMainWindow().getStatusBar().getText();
		if(subidoCorrecto.contains("El archivo se ha creado con")) {
			server.info("Se ha anexado correctamente el fichero");
			if(!Paths.get(currentCartaPago.getNombreDocumento()).toFile().delete()) {
				server.warn("No se ha eliminado el documento" + currentCartaPago.getNombreDocumento());
			}
		}
		else {
			server.sendScreen("statusbar no se ha creado el anexo");
			server.info("No se ha anexado correctamente el fichero");
			throw new SystemException("No se ha anexado correctamente", null, "fin", true);
		}
			
	}
	
	
	private void rellenarImporteYTexto() throws BusinessException {
		server.debug("Introduciendo campos importe y texto");
		IGuiApplication sap = sapControl.getSap();
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		GuiTextField importe = userArea.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.windowCompensarDeudorCorregirPosicionDeDeudor.TEXT_IMPORTE);
		GuiCTextField texto = userArea.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.windowCompensarDeudorCorregirPosicionDeDeudor.CTEXT_TEXTO);
		GuiButton continuar = activeWindow.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.windowCompensarDeudorCorregirPosicionDeDeudor.BUTTON_CONTINUAR);
		GuiButton tratarPAs = activeWindow.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.windowCompensarDeudorCorregirPosicionDeDeudor.BUTTON_TRATARPAS);
		
		importe.setText(stringSinAsignar.replace("-",""));
		texto.setText(Constantes.PENDIENTE_ASIGNAR);
		
		continuar.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		checkStatusBarFail(sap.getCurrentSession().getMainWindow());
		tratarPAs.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
	}
	
	// parametro cuen sin usar, por si hubiese que usarlo
	private void rellenarVentanaVisualizarResumenSinAsginar(String claveCt, String cuen, String cme) throws BusinessException {
		server.debug("Rellenando posiciones, visualizar resumen");
		IGuiApplication sap = sapControl.getSap();
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		GuiButton continuar = activeWindow.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.BUTTON_CONTINUAR);
		GuiCTextField clvCT = userArea.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.CTEXT_CLVCT);
		GuiCTextField cuenta = userArea.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.CTEXT_CUENTA);
		GuiCTextField cmectext = userArea.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.CTEXT_CME);

		clvCT.setText(claveCt);
		// seria el 0? o cual?
		server.debug("Cliente, deudor: " + currentCartaPago.getTtooDeudor().get(0));
		cuenta.setText(currentCartaPago.getTtooDeudor().get(0)); 
		cmectext.setText(cme);
		continuar.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		checkStatusBarFail(sap.getCurrentSession().getMainWindow());
		
	}
	
	
	@SuppressWarnings("null")
	public void enviarInformeUsuario() {
		server.info("Enviar InformeUsuario");

		try {
			for (CartaPago carta : cartasPagoErroneas) {
//	No deberia ser null nunca	if (carta != null || !carta.getNombreDocumento().equalsIgnoreCase("")) {
				if (!carta.getNombreDocumento().equalsIgnoreCase("")) {
					String nombre = excelDrive.buscarTTOOEnReclamaciones(carta.getTtooDeudor().get(0));
					server.info("El nombre de prueba seria: " + nombre);
					String destinatario = excelDrive.destinatarioCorreo(carta.getTtooDeudor().get(0));
					server.info("El destinatario es: " + destinatario);
					// El nombre del TTOO será el asunto
					// El cuertp hay que ver que hacemos
					//PARA MIKE, aqui quita tu correo y pon el de destinatarios para enviarlo a los gestores
					//REVISA QUE LA COLUMNA DE DONDE SE TOMA EL VALOR DEL DESTINATARIO ESTA BIEN
					String cuerpo = "Se ha producido un error en la tramitacion de la carta de pago que se adjunta correspondiente a la ejecución " + numeroEjecucion + ".<p>"
							+ "Por favor revisenlo";
					// en variables de entorno poner los correos tal que asi: ,jgraualbors@s2g.deloitte.es,hlluncor@s2g.deloitte.es
					// con ; falla hay que poner ,
					mail.enviarCorreo(robotParameters, destinatario + environmentVariables.get("EMAILS"), nombre, cuerpo,
							carta.getNombreDocumento());
//					FUNCIONA BIEN CON , NO CON ; PONER VARIABLE ENTORNO CON COMAS
					if(Paths.get(carta.getNombreDocumento()).toFile().delete() ) {
						server.info("Fichero borrado");
					}
					else {
						server.info("Fichero no borrado");
					}
				}
			}
		} catch (Exception e) {
			server.error("ERROR " + e);
		}
	}

	/**
	 * Metodo utilizado para la liberacion de ficheros y programas utilizados por el
	 * Robot
	 * @throws IOException 
	 * @throws MessagingException 
	 */
	public void fin() throws IOException, MessagingException {
		sapControl.sapClose();
		
		if(control) {
			control = false;
			relaunchRobot();
		}
		else{
			if(mail.getNumCorreos()>1) {
				relaunchRobot();
			}
		}
	}

	
	

	// FUNCIONES PRIVADAS

	private String casoExcepctionVueltaAlBucle(String text) {
		server.info("Entra en Caso Exception vuelta bucle por el case: " + text);
		windows.getKeyboard().pressShift().function(3).releaseShift().pause();

		windows.getKeyboard().tab().pause().enter().pause();
		sapControl.sapClose();
		cartasPagoErroneas.add(currentCartaPago);
		
		return "quedanCartasPorProcesar";
	}

	/**
	 * Metodo que escribe en el log, informacion relativa a la propia ejecucion
	 * @throws IOException 
	 * 
	 * @throws Exception
	 */
	private void escribirInfoEjecucion() throws IOException {

		OutputStream writer = new ByteArrayOutputStream(1024);
		IOUtils.copy(this.getClass().getResourceAsStream("/ROBOT-VERSION"), writer);
		server.info("ROBOT-VERSION-: " + writer.toString());

	}

	private CartaPago tratamientoPDF(String string, String touroperadorOCR) throws BusinessException {
		server.info("Comienza lectura de PDF");
		server.debug("String string: " + string);
		server.debug("String touroperadorOCR: " + touroperadorOCR);
//		 cartaPago igual a null
		CartaPago cartaPago = new CartaPago();
		String text = "";
		try (PDDocument document = PDDocument.load(Paths.get(string).toFile())) {
			server.debug("document: " + document);
			PDFTextStripper stripper = new PDFTextStripper();
			text = stripper.getText(document);
			server.debug("text: "+ text);
			
			String aux = text;
			aux = aux.replaceAll("\r", "").replaceAll("\n", "");
			server.debug("auux: " + aux);
			if(aux.equals("") || aux == null || aux.isEmpty()) {
				server.debug("Es un pdf erroneo");
				server.debug("Aux: " + aux);
				throw new Exception();
			}
			
		}catch(Exception e) {
			throw new BusinessException("El pdf de la carta de pago no se puede leer, es imagen o protegido", "fin", false);
		}
		try {
				server.info(text);
				
				// Revisar muy mucho esta inicializacion
				String sociedad = excelDrive.buscarCodigoSociedad(text);
				server.info(Constantes.LASOCIEDADES + sociedad);
				
				// en la posicion 0 de la lista esta el codigo deudor y en la 1 el acreedor
				List<String> codigosDeudor = excelDrive.buscarCodigoDeudorTTOO(touroperadorOCR);
				
				String codigoAcreedor = excelDrive.buscarCodigoAcreedorTTOO(touroperadorOCR);
				
				
				server.info("Hay " + codigosDeudor.size() + Constantes.CODIGOS_DEU);
				for (String ww : codigosDeudor) {
					server.info(Constantes.ELCODIGOSAPDEUDORES + ww);
				}
				
				server.info(Constantes.ELCODIGOSAPACREEDORESES + codigoAcreedor);
				server.info(Constantes.ELVALORDELTTOONAME + touroperadorOCR);
				if (touroperadorOCR.equalsIgnoreCase("DER Touristik Nordic AB")) {
					touroperadorOCR = Constantes.DERTOURISTIKNORDICAB;
				}
				HashMap<String, Double> sumatorio = new HashMap<String, Double>();
				switch (touroperadorOCR) {
				case Constantes.DERTOURISTIKNORDICAB:
					server.info(Constantes.TTOOES  + Constantes.DERTOURISTIKNORDICAB);
					
					for (Casuistica casu : casuisticas.get(Constantes.DERTOURISTIKNORDICAB)) {
						sumatorio.put(casu.getTipo(), 0.0d);
					}
					touroperador = new Apollo(server, sociedad, codigosDeudor, codigoAcreedor, touroperadorOCR, string,
							sumatorio);
					cartaPago = touroperador.procesarCartaPagoPDF(text, casuisticas.get(Constantes.DERTOURISTIKNORDICAB));
					break;
					
				case Constantes.TUI_UK:
					server.info(Constantes.TTOOES  + Constantes.TUI_UK);
					
					for (Casuistica casu : casuisticas.get(Constantes.TUI_UK)) {
						sumatorio.put(casu.getTipo(), 0.0d);
					}
					touroperador = new TuiUk(server, sociedad, codigosDeudor, codigoAcreedor, touroperadorOCR, string,
							sumatorio);
					cartaPago = touroperador.procesarCartaPagoPDF(text, casuisticas.get(Constantes.TUI_UK));
					break;
					
				case Constantes.JET2HOLIDAYS:
					for (Casuistica casu : casuisticas.get(Constantes.JET2HOLIDAYS)) {
						sumatorio.put(casu.getTipo(), 0.0d);
					}
					server.info(Constantes.TTOOES + Constantes.JET2HOLIDAYS);
					touroperador = new Jet2Holidays(server, sociedad, codigosDeudor, codigoAcreedor, touroperadorOCR,
							string, sumatorio);
					cartaPago = touroperador.procesarCartaPagoPDF(text, casuisticas.get(Constantes.JET2HOLIDAYS));
					break;
					
				case Constantes.THOMAS_COOK:
					for (Casuistica casu : casuisticas.get(Constantes.THOMAS_COOK)) {
						sumatorio.put(casu.getTipo(), 0.0d);
					}
					server.info(Constantes.TTOOES  + Constantes.THOMAS_COOK);
					touroperador = new ThomasCook(server, sociedad, codigosDeudor, codigoAcreedor, touroperadorOCR, string,
							sumatorio);
					cartaPago = touroperador.procesarCartaPagoPDF(text, casuisticas.get(Constantes.THOMAS_COOK));
					break;
				case Constantes.TUINETHERLAND:
					for (Casuistica casu : casuisticas.get(Constantes.TUINETHERLAND)) {
						sumatorio.put(casu.getTipo(), 0.0d);
					}
					server.info(Constantes.TTOOES  + Constantes.TUINETHERLAND);
					touroperador = new TuiNetherland(server, sociedad, codigosDeudor, codigoAcreedor, touroperadorOCR,
							string, sumatorio);
					cartaPago = touroperador.procesarCartaPagoPDF(text, casuisticas.get(Constantes.TUINETHERLAND));
					break;
					
				case Constantes.MEETINGPOINT:
					for (Casuistica casu : casuisticas.get(Constantes.MEETINGPOINT)) {
						sumatorio.put(casu.getTipo(), 0.0d);
					}
					server.info(Constantes.TTOOES  + Constantes.MEETINGPOINT);
					touroperador = new MeetingPoint(server, sociedad, codigosDeudor, codigoAcreedor, touroperadorOCR,
							string, sumatorio);
					cartaPago = touroperador.procesarCartaPagoPDF(text, casuisticas.get(Constantes.MEETINGPOINT));
					break;
					
				default:
					server.warn("No identifica el TTOO");
					throw new SystemException("No se identifica el TTOO", null, "", false);
				}
				
//				if (cartaPago == null) {
//					server.warn("la carta de pago es null");
//				}
//				No deberia ser null ya que creamos la carta de pago vacia
				if (cartaPago.getFacturas().isEmpty()) {
					mensajeDeError ="No se reconoce ninguna linea en la carta de pago";
					server.warn("No se reconocen lineas en la carta de pago");
					throw new SystemException("No se reconocen lineas en la carta de pago", null, "", false);
				}
				
				for (Factura factura : cartaPago.getFacturas()) {
					server.info("La factura con identificador " + factura.getIdentificador() + " tiene de importe "
							+ factura.getImporte());
				}
				server.info("El importe total es " + cartaPago.getImporte());
				return cartaPago;
		} catch (SystemException e) {
			server.error("Falla en la lectura ", e);
		} catch (IndexOutOfBoundsException io){
			throw new BusinessException("Excepcion fallo en la lectura: No se reconoce error en la carta de pago", "",false);
		}
		
		return cartaPago;
	}

	private CartaPago tratamientoExcel(String string, String touroperadorOCR) throws SystemException {

		CartaPago cartaPago;
		server.info("Entramos en Lectura Excel");
		String textFile = "";
		try (FileInputStream excelXML = new FileInputStream(new File(string));
				Workbook wb = WorkbookFactory.create(excelXML);) {

			if (wb != null) {
				Sheet hoja = wb.getSheetAt(0);

				String k = hoja.toString();
				String nombrehoja = hoja.getSheetName();
				server.info(k);
				server.info("El nombre de la hoja es: " + nombrehoja);

				Iterator<Row> rowIterator = hoja.iterator();

				while (rowIterator.hasNext()) {

					Row row = rowIterator.next();

					Iterator<Cell> cellIterator = row.cellIterator();
					while (cellIterator.hasNext()) {
						Cell cell = cellIterator.next();
						CeldasUtils celdasUtils = new CeldasUtils();
						textFile = textFile + "\r" + celdasUtils.valorCelda(cell);
					}
				}
				wb.close();
			}
		} catch (IOException | EncryptedDocumentException e) {
			server.error(e);
		} 
		// En textFile vamos a tener el excel completo en un solo String
		String sociedad = excelDrive.buscarCodigoSociedad(textFile);
		server.info(Constantes.LASOCIEDADES + sociedad);

		// en la posicion 0 de la lista esta el codigo deudor y en la 1 el acreedor
		List<String> codigosDeudor = excelDrive.buscarCodigoDeudorTTOO(touroperadorOCR);

		String codigoAcreedor = excelDrive.buscarCodigoAcreedorTTOO(touroperadorOCR);

		server.info("Hay " + codigosDeudor.size() + Constantes.CODIGOS_DEU);
		for (String ww : codigosDeudor) {
			server.info(Constantes.ELCODIGOSAPDEUDORES + ww);
		}

		server.info(Constantes.ELCODIGOSAPACREEDORESES + codigoAcreedor);
		server.info(Constantes.ELVALORDELTTOONAME + touroperadorOCR);
		HashMap<String, Double> sumatorio = new HashMap<String, Double>();

		// Para excel vamos a tener VIAJES CANARIAS EUROPA
		server.info(Constantes.TTOOES  + Constantes.VIAJESCANARIASEUROPA);

		for (Casuistica casu : casuisticas.get(Constantes.VIAJESCANARIASEUROPA)) {
			sumatorio.put(casu.getTipo(), 0.0d);
		}
		touroperador = new ViajesCanariasEuropa(server, sociedad, codigosDeudor, codigoAcreedor, touroperadorOCR,
				string, sumatorio);
		server.info("Antes de la llamada de la funcion: " + string);
		cartaPago = touroperador.procesarCartaPagoExcel(string, casuisticas.get(Constantes.VIAJESCANARIASEUROPA));

		return cartaPago;

	}

	private CartaPago tratamientoTextoPlano(String string, String fileName, String ttoo) throws SystemException {

		server.info("Entramos en Tratamiento Texto Plano");
		CartaPago cartaPago = null;
		// Revisar muy mucho esta inicializacion
		String sociedad = excelDrive.buscarCodigoSociedad(string);
		server.info(Constantes.LASOCIEDADES + sociedad);

		// en la posicion 0 de la lista esta el codigo deudor y en la 1 el acreedor
		List<String> codigosDeudor = excelDrive.buscarCodigoDeudorTTOO(ttoo);

		String codigoAcreedor = excelDrive.buscarCodigoAcreedorTTOO(ttoo);

		server.info("Hay " + codigosDeudor.size() + Constantes.CODIGOS_DEU);
		for (String ww : codigosDeudor) {
			server.info(Constantes.ELCODIGOSAPDEUDORES + ww);
		}

		server.info(Constantes.ELCODIGOSAPACREEDORESES + codigoAcreedor);
		server.info(Constantes.ELVALORDELTTOONAME + ttoo);
		HashMap<String, Double> sumatorio = new HashMap<String, Double>();

		// Solo debería ser TUI SVerige, si cambia, pues se jodió
		List<Casuistica> listaAuxiliar = casuisticas.get(ttoo);
		if (listaAuxiliar == null) {
			server.info("La lista auxiliar es null");
		}
		else {
			server.info("El numero de casuisiticas en la lista auxiliar es : " + listaAuxiliar.size());
		}

		for (Casuistica casu : listaAuxiliar) {
			sumatorio.put(casu.getTipo(), 0.0d);
		}
		if (ttoo.equalsIgnoreCase(Constantes.TUISVERIGE)) {
			touroperador = new TUISverige(server, sociedad, codigosDeudor, codigoAcreedor, ttoo, fileName, sumatorio);
			cartaPago = touroperador.procesarCartaPagoPDF(string, casuisticas.get(Constantes.TUISVERIGE));
		} else if (ttoo.equalsIgnoreCase(Constantes.VIAJESELCORTEINGLES)) {
			touroperador = new ViajesElCorteIngles(server, sociedad, codigosDeudor, codigoAcreedor, ttoo,fileName,
					sumatorio);
			cartaPago = touroperador.procesarCartaPagoPDF(string, casuisticas.get(Constantes.VIAJESELCORTEINGLES));
		}

		return cartaPago;
	}

	private CartaPago tratamientoWord(String ruta, String touroperadorOCR) throws SystemException {
		CartaPago cartaPago = null;
		// Guardar la ruta y recuerden que se debe poner doble barra \\

		String textaco = "";
		String cadena;

		String lineaDeSociedad = "";
		try (BufferedReader b = new BufferedReader(new InputStreamReader(new FileInputStream(ruta), "ISO-8859-1"));){

			

			while ((cadena = b.readLine()) != null) {
				textaco = textaco.concat(cadena);
				textaco = textaco.concat("\r");

				String buscarSociedad = getMatch("\\d+[\\/][A-z]{3}\\d+", cadena);
				if(!buscarSociedad.equalsIgnoreCase("") ) {
					lineaDeSociedad = getMatch("\\d+[\\/][A-z]{3}\\d+", cadena);
				}				
			}


			b.close();

			// Revisar muy mucho esta inicializacion

			//
			String sociedad = excelDrive.buscarCodigoSociedad(lineaDeSociedad);
			server.info(Constantes.LASOCIEDADES + lineaDeSociedad);

			List<String> codigosDeudor = excelDrive.buscarCodigoDeudorTTOO(touroperadorOCR);

			String codigoAcreedor = excelDrive.buscarCodigoAcreedorTTOO(touroperadorOCR);

			server.info("Hay " + codigosDeudor.size() + Constantes.CODIGOS_DEU);
			for (String ww : codigosDeudor) {
				server.info(Constantes.ELCODIGOSAPDEUDORES + ww);
			}

			server.info(Constantes.ELCODIGOSAPACREEDORESES + codigoAcreedor);

			HashMap<String, Double> sumatorio = new HashMap<String, Double>();
			switch (touroperadorOCR) {
			case Constantes.JET2HOLIDAYS:
				for (Casuistica casu : casuisticas.get(Constantes.JET2HOLIDAYS)) {
					sumatorio.put(casu.getTipo(), 0.0d);
				}
				server.info(Constantes.TTOOES  + Constantes.JET2HOLIDAYS);
				touroperador = new Jet2Holidays(server, sociedad, codigosDeudor, codigoAcreedor, touroperadorOCR, ruta,
						sumatorio);
				cartaPago = touroperador.procesarCartaPagoWord(textaco, casuisticas.get(Constantes.JET2HOLIDAYS));

				break;
			default:
				break;

			}

		} catch (IOException e) {
			server.error(e);
		}

		return cartaPago;
	}

	private CartaPago tratamientoGenerico(String string, String touroperadorOCR) {
		CartaPago cartaPago;
		HashMap<String, Double> sumatorio = new HashMap<String, Double>();
		List<String> codigosDeudor = new ArrayList<String>();
		for (Casuistica casu : casuisticas.get(Constantes.GENERICO)) {
			sumatorio.put(casu.getTipo(), 0.0d);
		}
		touroperador = new Generico(server, "", codigosDeudor, "", touroperadorOCR, string, sumatorio);
		cartaPago = touroperador.procesarCartaPagoGenerica(string, casuisticas.get(touroperadorOCR));

		return cartaPago;
	}

	private void cargaCasuisticas() throws SystemException {
		// Se utiliza la clase del excelDrive, se abrirá el excel maestro de
		// compensaciones y se cargaran las casuisticas
		server.info("Entramos en Carga de casuisticas");

		casuisticas = excelDrive.getCasuisticas();

		if (casuisticas == null) {
			server.warn("Las casuisticas son null");
			throw new SystemException("las casuisticas son null, habra que relanzar", null, "fin", false);
		} else {
			server.info("El tamañod el hash map de casuisticas es: " + casuisticas.size());
		}
	}

	private void cargaTTOO() throws SystemException {

		server.info("Entramos en Carga de TTOO");

		mapaTTOO = excelDrive.getTTOO();
		// Este hashmap contiene como clave la primera columna de la tabla de TTOO, es
		// decir los que deberian coincidir con las constantes.
		// Como valor contiene, una lista con la propia clave, la columna 2 y un split
		// por ; de la columna 3 para tener todas las opciones
	}

	private void sapf32AnyadirClvCt(String codigoClvct) {
		server.debug("Anyadir clave contable");
		IGuiApplication sap = sapControl.getSap();// Estaremos en la pantalla donde se encuentra todo marcado
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiCTextField clvCT = userArea.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.CTEXT_CLVCT);
		
		if (codigoClvct.length() == 1) {
			clvCT.setText("0" + codigoClvct);
		} else {
			clvCT.setText(codigoClvct);
		}
		server.info("El codigo ClvCT es " + codigoClvct);
		
	}
	
	private void sapf32AnyadirCuenta(String cuenta) {
		server.debug("anyadir cuenta");
		IGuiApplication sap = sapControl.getSap();// Estaremos en la pantalla donde se encuentra todo marcado
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiCTextField cuentaCTextField = userArea.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.CTEXT_CUENTA);
		
		if (cuenta.equalsIgnoreCase("Deudor")) {
			server.info("La cuenta es deudor, usando el codigo: " + currentCartaPago.getTtooDeudor().get(0));
			// En principio para las casuisticas siempre iran al primer TTOO
			cuentaCTextField.setText(currentCartaPago.getTtooDeudor().get(0));
		} else {
			server.info("La cuenta es Acreedor usando la cuenta: " + currentCartaPago.getTtooAcreedor());
			cuentaCTextField.setText(currentCartaPago.getTtooAcreedor());
		}
	}
		
	private void sapf32AnyadirCME(String cme) throws BusinessException {
		server.debug("anyadir cme");
		IGuiApplication sap = sapControl.getSap();// Estaremos en la pantalla donde se encuentra todo marcado
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		GuiCTextField cmeCtext = userArea.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.CTEXT_CME);
		GuiButton continuar = activeWindow.findById(TSap_F_32.windowCompensarDeudorVisualizarResumen.BUTTON_CONTINUAR);
		
		if (!cme.equalsIgnoreCase("-")) {
			cmeCtext.setText(cme);
		}
		// pasamos a la pantalla siguiente
		continuar.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		server.debug("Introducidos campos de ClvCT, Cuenta y CME");
		checkStatusBarFail(sap.getCurrentSession().getMainWindow());
	}
	
	
	
	private void sapf32ContabilizarAnyadirImportePrePagos() throws BusinessException {
		server.debug("contabilizar y anyadir importe ");
		IGuiApplication sap = sapControl.getSap();
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		
		GuiTextField importextField = userArea.findById(TSap_F_32.windowCompensarDeudorAnadirPosicionDeDeudor.TEXT_IMPORTE); // comun
//		GuiTextField impuesto = userArea.findById(TSap_F_32.windowCompensarDeudorAnadirPosicionDeDeudor.TEXT_IMPUESTO);
		GuiCTextField indicadorImpuesto = userArea.findById(TSap_F_32.windowCompensarDeudorAnadirPosicionDeDeudor.CTEXT_IND_IMPUESTO);
//		GuiCheckBox checkCalcImpuestos = userArea.findById(TSap_F_32.windowCompensarDeudorAnadirPosicionDeDeudor.CHECKBOX_CALCULAR_IMPUESTOS);
		//GuiTextField asignacion = userArea.findById(TSap_F_32.windowCompensarDeudorAnadirPosicionDeDeudor.TEXT_ASIGNACION);
		GuiCTextField texto = userArea.findById(TSap_F_32.windowCompensarDeudorAnadirPosicionDeDeudor.CTEXT_TEXTO);
		GuiButton continuar = activeWindow.findById(TSap_F_32.windowCompensarDeudorAnadirPosicionDeDeudor.BUTTON_CONTINUAR);
		
		String importe = currentFacturaCompleta.getImporte().replace("-", "");
		importe = importeToDouble(importe).toString().replace(".", ",");
		server.info(Constantes.IMPORTE_INTRO + importe);
		importextField.setText(importe);
		indicadorImpuesto.setText("NS");
		texto.setText(currentFacturaCompleta.getDescripciom());
		continuar.press();
		sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
		server.debug("Introducidos importe, indicadorImpuestos y texto");
		checkStatusBarFail(sap.getCurrentSession().getMainWindow());
	}
	
	
	private void sapf32ContabilizarAnyadirImporte() throws BusinessException {
		server.debug("contabilizar y anyadir importe");
		IGuiApplication sap = sapControl.getSap();
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiFrameWindow activeWindow = sap.getCurrentSession().getActiveWindow();
		GuiTextField importextField = userArea.findById(TSap_F_32.windowCompensarDeudorAnadirPosicionDeDeudor.TEXT_IMPORTE); // comun
		GuiCTextField fechaCTxt = userArea.findById(TSap_F_32.windowCompensarDeudorAnadirPosicionDeDeudor.CTEXT_FECHA);
		//GuiTextField asignacion = userArea.findById(TSap_F_32.windowCompensarDeudorAnadirPosicionDeDeudor.TEXT_ASIGNACION);
		GuiCTextField texto = userArea.findById(TSap_F_32.windowCompensarDeudorAnadirPosicionDeDeudor.CTEXT_TEXTO);
		GuiButton continuar = activeWindow.findById(TSap_F_32.windowCompensarDeudorAnadirPosicionDeDeudor.BUTTON_CONTINUAR);
		
		if (currentFacturaCompleta.getTipo().equalsIgnoreCase(Constantes.DEDUCCION)) {
			//Se debe formatear el importe con separador de decimales = ","
			String importe = currentFacturaCompleta.getImporte().replace("-", "").replace("(","").replace(")","");
			importe = importeToDouble(importe).toString().replace(".", ",");
			server.info(Constantes.IMPORTE_INTRO + importe);
			importextField.setText(importe);
			
			Date ahora = new Date();
			final SimpleDateFormat dateFormatDd = new SimpleDateFormat("dd");
			final SimpleDateFormat dateFormatMm = new SimpleDateFormat("MM");
			final SimpleDateFormat dateFormatYy = new SimpleDateFormat("yyyy");
			String dia = dateFormatDd.format(ahora);
			String mes = dateFormatMm.format(ahora);
			String anyo = dateFormatYy.format(ahora);
			String fecha = dia + "." + mes + "." + anyo;
			fechaCTxt.setText(fecha);
			server.info("La descripcion es "+ currentFacturaCompleta.getDescripciom());
			// TAMPOCO FUNCIONA ASIGNACION COMO EN EL DE ABAJO
			//asignacion.setText(currentFacturaCompleta.getDescripciom()); // este quiza pete tb por lo que ha pasado abajo
			texto.setText(currentFacturaCompleta.getDescripciom());
			continuar.press();
			sap.getCurrentSession().waitIdle(Constantes.RETRY_S * 1000);
			server.debug("Introducidos importe, fecha vencimiento, asignacion y texto");
			checkStatusBarFail(sap.getCurrentSession().getMainWindow());
			
		}
		else {
			//Se debe formatear el importe con separador de decimales = ","
			String importe = currentFacturaCompleta.getImporte().replace("-", "");
			importe = importeToDouble(importe).toString().replace(".", ",");
			server.info(Constantes.IMPORTE_INTRO + importe);
			importextField.setText(importe);
/*
* 
			// NO FUNCIONA ASIGNACION
			server.debug("asignacion: " + asignacion.getId());
			asignacion.setText(currentFacturaCompleta.getDescripciom()); no se por qué no funciona con settext si obtengo el id bien
			ActiveXComponent asign = new ActiveXComponent(sap.getComponent().invoke("findById", "ses[0]/wnd[0]/usr/txtBSEG-ZUONR").toDispatch());
			asign.setProperty("text", currentFacturaCompleta.getDescripciom());
			asign.setProperty("caretPosition", currentFacturaCompleta.getDescripciom().length());
			server.debug("asignacion seteada");
			asignacion.setText(currentFacturaCompleta.getDescripciom());
*/
			texto.setText(currentFacturaCompleta.getDescripciom());
//			server.sendScreen("asignacion y texto anyadidos");
			// Esto se hace asi pq el caso de que sea un 06 es decir, un pago de menos,
			// tiene que ponerse un 001 en la siguiente pantalla que sale
			// En el resto de casos no sale la pantalla extra por lo que no lo metemos
			// Correo del dia 14/12/2018 en el que cristina nos dice que no es necesario //AALCARAZ
			
		}
					
	}
	

	private void escribirExcel(String descargado) {
		// Instanciar el servicio de Drive
		excelDrive.escribirExcel(currentCartaPago, casuisticas, descargado, numeroEjecucion, mensajeDeError, otros, fichero, mail);

	}

	private String busquedaTTOOOCR(String path) {
		String touroperadorEncontrado = "";
		server.info("Entra en Busqueda TTOO");
		try (PDDocument document = PDDocument.load(Paths.get(path).toFile())) {

			PDFRenderer renderer = new PDFRenderer(document);
			BufferedImage image = renderer.renderImageWithDPI(0, 576f);
			String pathImagen = path.replace(".pdf", ".jpg");
			pathImagen = pathImagen.replace(".PDF", ".jpg");
			File fichero = new File(pathImagen);

			ImageIO.write(image, "JPEG", fichero);

			ITesseract instance = new Tesseract();
			server.info("Tras crear el teseracto");

			instance.setDatapath(robotParameters.getTesseract());
			server.info("tras setear el datapath del teseracto con valor: " + robotParameters.getTesseract());
			String imgText = instance.doOCR(fichero);
			server.info("Tras sacar la image en texto");
			if (imgText == null) {
				server.info("era null");
			}

			touroperadorEncontrado = busquedaTTOOPorLinea(imgText);
			server.info(Constantes.TTOOES  + touroperadorEncontrado);

		} catch (TesseractException | IOException e) {
			server.error("Catch de la busqueda del TTOO con OCR ", e);
		}

		return touroperadorEncontrado;
	}

	private String busquedaTTOOWord(String path) {
		String salida = "";
		String cadena;

		try(FileReader f =  new FileReader(path); BufferedReader b = new BufferedReader(new InputStreamReader(new FileInputStream(path), "ISO-8859-1"));) {

			while ((cadena = b.readLine()) != null) {
				String caso = busquedaTTOOPorLinea(cadena);
				if (!caso.equalsIgnoreCase("")) {
					salida = caso;
				}
			}
		} catch (IOException e) {
			server.error("Error en la busqueda de TTOO en word", e);
			return salida;
		}

		return salida;
	}

	private String busquedaTTOOExcel(String string) {

		String salida = "";
		try (FileInputStream excelXML = new FileInputStream(new File(string));Workbook wb = WorkbookFactory.create(excelXML);) {
			if (wb != null) {
				Sheet hoja = wb.getSheetAt(0);

				String k = hoja.toString();
				String nombrehoja = hoja.getSheetName();
				server.info(k);
				server.info("El nombre de la hoja es: " + nombrehoja);

				Iterator<Row> rowIterator = hoja.iterator();

				while (rowIterator.hasNext()) {

					Row row = rowIterator.next();
					server.info("La linea toString es " + row.toString());

					Iterator<Cell> cellIterator = row.cellIterator();
					while (cellIterator.hasNext()) {
						Cell cell = cellIterator.next();
						CeldasUtils celdasUtils = new CeldasUtils();
						String caso = busquedaTTOOPorLinea(celdasUtils.valorCelda(cell));
						if (!caso.equalsIgnoreCase("")) {
							salida = caso;
						}
					}
				}
				wb.close();
			}
		} catch (IOException | EncryptedDocumentException e) {
			server.error(e);
			return salida;
		}

		return salida;
	}

	private String busquedaTTOOPorLinea(String linea) {
		String salida = "";

		@SuppressWarnings("rawtypes")
		Iterator it = mapaTTOO.entrySet().iterator();
		while (it.hasNext()) {
			@SuppressWarnings("rawtypes")
			Map.Entry pair = (Map.Entry) it.next();

			String clave = (String) pair.getKey();
			@SuppressWarnings("unchecked")
			List<String> value = (List<String>) pair.getValue();

			if (linea.contains(clave)) {
				salida = clave;
			} else {
				for (String caso : value) {
					if (linea.contains(caso)) {
						salida = clave;
					}
				}
			}
		}

		return salida;
	}

	private static String getMatch(String regex, String inputText) {
		String match = "";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(inputText);
		if (matcher.find()) {
			match = matcher.group();
		}
		return match;
	}

	private Double importeToDouble(String importe) {



		String k = importe.trim();
		String regexMilComa = "\\d{1,3}(\\,\\d{3})*(\\.\\d+)";
		String regexMilPunto = "\\d{1,3}(\\.\\d{3})*(\\,\\d+)";
		String regexComa = "\\d+(\\,\\d+)";
		if (k.matches(regexMilComa)) {
			k = k.replace(",", "");
		} else if (k.matches(regexMilPunto)) {
			k = k.replace(".", "");
			k = k.replace(",", ".");
		} else if (k.matches(regexComa)) {
			k = k.replace(",", ".");
		} else {
			server.info("Solo tiene punto sin mas");
		}

		server.info("El importe es: " + k);

		double numero = Double.valueOf(k);
		numero = Math.round(numero * 100) / 100d;

		return numero;

	}

	private String quedaPediente() {

		server.info("Entramos en Queda Pendiente");

		// Vamos a buscar el valor 0.0 en el sin asignar
		String importeSinAsingar = "";
		IGuiApplication sap = sapControl.getSap();
		GuiUserArea userArea = sap.getCurrentSession().getMainWindow().getUserArea();
		GuiTextField vTSinAsignar = userArea.findById(TSap_F_32.windowCompensarDeudorProcesarPartidasAbiertas.TEXT_SIN_ASIGNAR);
		
		importeSinAsingar = vTSinAsignar.getText();
		server.info("Importe sin asignar, queda pendiente " + importeSinAsingar);
		
		return importeSinAsingar;
	}

	
    /**
    * RrelaunchRobot Netodo pare realnzar el robot en caso de fallo o de alcanzar el número máximo de items por ejecución
    * @throws IOException 
    * 
    */   
    private void relaunchRobot() throws IOException {
        String robotName = server.getExecution(0).getRobotName();
        server.info(String.format("Trying to launch robot \"%s\"...", robotName));
        
        List<ExecutionParameter> parameters = new ArrayList<>();

        Map<String, String> currentParameters = server.getParameters();
              
        for (Map.Entry<String, String> param : currentParameters.entrySet()) {
                     
              ExecutionParameter currentParam = new ExecutionParameter();
              currentParam.setName(param.getKey());
              currentParam.setValue(param.getValue());
              parameters.add(currentParam);
        }
              
        for (ExecutionParameter param : parameters) {
              server.info(String.format("Parameter [%s] - Value [%s]", param.getName(), param.getValue()));
        }
        
        server.getExecution(0).launchRobot(robotName, true, "", parameters);
 }
    
	/**
	 * 
	 * Metodo que checkea si ha habido algun error en la barra de status de SAP
	 * 
	 * @param guiMainWindow
	 * @throws SystemException
	 * @throws BusinessException 
	 */
	private String checkStatusBarFail(GuiMainWindow guiMainWindow) throws BusinessException {
		String string = "no";
		GuiStatusBar statusBar = guiMainWindow.getStatusBar();
		// Checks the status bar
		if(statusBar.getMessageType().equals("E")) {
			server.sendScreen("Ha fallado Status Bar");
			throw new BusinessException(statusBar.getText(), "fin" , true);
		}
		// quiza haya que cambiar estos ifs y meterlos en W
		else if(statusBar.getText().contains("La diferencia es demasiado grande para una compensaci")) {
			string = "yes";
		}
		else if(statusBar.getText().contains("Por favor, corrija las posiciones marcadas")) {
			string = "corregir posiciones";
		}
		else if(statusBar.getText().contains("El archivo se ha creado con")) {
			string = "correcto";
		}
		else if(statusBar.getMessageType().equals("W")) {
			server.warn("MESSAGE TYPE '" + statusBar.getMessageType() + "' IN SAP >> " + statusBar.getText());
			if(statusBar.getText().contains("se adapta a fecha contab")) {
				string = Constantes.CONTINUAR;// click
			}
			else if(statusBar.getText().contains("Se contabiliza en ejercicio del pasado")) {
				string = Constantes.CONTINUAR;//click again a continuar 
			}
			else if(statusBar.getText().contains("Por favor, compruebe el signo de la diferencia")) {
				string = Constantes.CONTINUAR;
			}
			else if(statusBar.getText().contains("ninguna partida abierta")) {
				server.debug("No hay partidas abiertas, habra que cargar xrisk");
				string = Constantes.CONTINUAR;
				noHayPartidasAbiertas = true;
			}
		}
		else if(statusBar.getText().contains("Imposible seleccionar este c")) { // Es correcto 
			string = "no hay que postimputar mas";
		}
		else{// si es verde, server. debug
			server.debug("checkStatus correcto: '" + statusBar.getMessageType() + "' " + statusBar.getText());
		}
		return string;
	}	
    
    
    @Override
	public String[] cleanUp() throws Exception {
		
    	sapControl.sapClose();
		FileUtils.deleteDirectory(new File(server.getCurrentDir()));
		
		return new String[] {};

	}

	/**
	 * Manage Exception method
	 */
    @Override
	public String manageException(String action, Exception exception) throws Exception {

		
		Throwable throwable = exception;
		Throwable cause=throwable.getCause();
		String message = cause.getMessage();		
		
		// Show all Exception detail if Robot is testing
//		if (currentExecutionDetail.isTesting()) {			
//			server.error(exception);
//		}
		
		
		while(throwable != null && cause != null) {
			throwable=cause;
			cause=throwable.getCause();
			if (cause instanceof BusinessException) {
				message = ((BusinessException) cause).getMessage();
				server.warn(message);
				String mensaje = exception.getMessage();
				server.debug("exeception.getmensaje = : " + mensaje);
				server.debug("cause.getmensaje = : " + message);
				switch (action) {
					case "lecturaCartasPago":
						if(message.equals("El pdf de la carta de pago no se puede leer, es imagen o protegido")){
							server.error("Error en lectura pdf, carta de pago sin formato correcto");
							// no puedo escribir en el excel porque no estan los datos rellenos
							//TODO: intentar enviar correo indicando que ttoo y carta de pago es, con los datos que se tengan para
							// que negocio pueda tener el error
							//Cuando se imprima el error, cogera la next action, ira a fin y si hay correos se relanza
							
						}
						else if(message.equals("Excepcion fallo en la lectura: No se reconoce error en la carta de pago")) {
							server.error("Fallo en la lectura: Carta de pago erronea, campos no identificados");
//							cartasPagoErroneas.add(currentCartaPago);
							mensajeDeError = "Fallo en lectura: estructura de la carta de pago no reconocida";
							server.setCurrentItem(currentItem, mail.getCartasDePago().get(fichero) + ": " + fichero);
							server.setCurrentItemResultToWarn(mensajeDeError);
							escribirExcel("NO");
							return "quedanCartasPorProcesar";
						}
						else if(message.equals("No se ha obtenido TTOO o sociedad, carta de pago erronea")) {
							server.error("No se ha obtenido TTOO o sociedad, carta de pago erronea");
							mensajeDeError = "No se ha obtenido TTOO o sociedad, carta de pago erronea";
							escribirExcel("NO");
						}
						else if(message.equals("Error tipo de fichero no contemplado")) {
							mensajeDeError = "Esta carta de pago es de tipo .csv, no aplica";
							escribirExcel("NO");
							return "fin";
						}
						
						break;
					
					case "asientoPorElPago":
						server.error("No se ha podido hacer el asiento por el pago, campos claveCT o cuenta erroneos/no deja introducir importe");
						escribirExcel("NO");
						return casoExcepctionVueltaAlBucle(Constantes.MENSAJE_WARNING_ASIENTO_POR_EL_PAGO);
					case "sapF32CompensarDeudorDatosCabecera":
						server.error("Los datos en la pantalla datos cabecera son erroneos, no se puede avanzar");
						escribirExcel("NO");
						return casoExcepctionVueltaAlBucle(Constantes.MENSAJE_WARNING_COMPENSAR_DEUDOR_DATOS_CABECERA);
					case "sapF32CompensarDeudorProcesarPartidasAbiertas":
						switch (message) {
							case "No se ha podido hacer click en shiftf2 button_cancelar":
								server.error("Ha fallado en metodo privado sapf32ProcesarPartidasAbiertas");
								break;
							case "No se ha podido hacer click en f6 button_cancelar_tratar":
								server.error("Ha fallado en metodo privado sapf32CompensarDeudorVisualizarResumen");
								break;
							case "Fallo al rellenar campos de cuenta, claseCuenta y cme seleccionando partidas abiertas":
								server.error("Ha fallado en metodo privado sapf32CompensarDeudorSeleccionarPartidasAbiertas");
								break;
							case "Fallo al volver atras al encontrar pago":
								server.error("Ha fallado en metodo privado sapf32TratarSaldoDeposito");
								break;
							case "Fallo al hacer click en continuar al escribir origen de diferencias":
								server.error("Ha fallado en metodo privado sapf32AnyadirOrigenDiferencias");
								break;
							case "Fallo al volver atras al anyadir origen diferencias":
								server.error("Ha fallado en metodo privado sapf32AnyadirOrigenDiferencias");
								break;
							case "Fallo al rellenar los campos para crear apunte contable":
								server.error("Ha fallado en metodo privado sapf32AsientoPorImporte");
								break;
							case "Fallo al rellenar los campos una vez se ha creado el apunte contable":
								server.error("Ha fallado en metodo privado sapf32AsientoPorImporte");
								break;
							case "Fallo al volver atras al encontrar pago en tratarpago":
								server.error("Ha fallado en metodo privado sapf32TratarPago");
								break;
							default:
								server.error("Ha fallado en sapF32CompensarDeudorProcesarPartidasAbiertas pero no se sabe donde");
						}
						escribirExcel("NO");
						return casoExcepctionVueltaAlBucle(Constantes.MENSAJE_WARNING_COMPENSAR_DEUDOR_PROC_PAR_ABIERTAS);
					case "sapF32IntroducirImportesFacturas":
						
						switch (message) {
							case "No ha encontrado el identificador ni por referencia ni por asignacion":
								server.error("Ha fallado en metodo publico sapF32IntroducirImportesFacturas");
								break;
							case "No es posible realizar apunte por el resto sobre un abono.":
								mensajeDeError = "No es posible realizar apunte por el resto sobre un abono.";
								// me iria a fin
								break;
								
						default: 
							server.error("Ha fallado marcando las facturas (sapF32IntroducirImportesFacturas)");
							break;
						}
						cartasPagoErroneas.add(currentCartaPago);
						server.setCurrentItemResultToWarn(mensajeDeError);
						escribirExcel("NO");
						return casoExcepctionVueltaAlBucle(Constantes.MENSAJE_WARNING_INTRODUCIR_IMPORTE_FACTURAS);
					case "sapf32IrAVisualizarResumenYCompensar":
						mensajeDeError = message;
						server.setCurrentItemResultToWarn(mensajeDeError);
						server.error("Los campos de ClvCT, Cuenta y CME son erroneos, no se puede avanzar");
						
						cartasPagoErroneas.add(currentCartaPago);
						escribirExcel("NO");
						return casoExcepctionVueltaAlBucle(Constantes.MENSAJE_WARNING_VIS_RES_COMPENSAR);
					case "pendienteAAsignar":
						cartasPagoErroneas.add(currentCartaPago);
						escribirExcel("NO");
						return casoExcepctionVueltaAlBucle(Constantes.MENSAJE_WARNING_PENDIENTE_ASIGNAR);
					case "comisionesBancarias":
						cartasPagoErroneas.add(currentCartaPago);
						escribirExcel("NO");
						return casoExcepctionVueltaAlBucle(Constantes.MENSAJE_WARNING_COMISIONES_BANCARIAS);
					case "apunteContable":
						cartasPagoErroneas.add(currentCartaPago);
						escribirExcel("NO");
						return casoExcepctionVueltaAlBucle(Constantes.MENSAJE_WARNING_APUNTE_CONTABLE);
					case "postImputar":
						cartasPagoErroneas.add(currentCartaPago);
						escribirExcel("NO");
						return casoExcepctionVueltaAlBucle(Constantes.MENSAJE_WARNING_POST_IMPUTAR);
						
						
					default:
						server.error("BusinessException not contemplated in the action '" + action + Constantes.MAYORMAYOR + exception.getMessage());
						throw exception;
				}
				return ((BusinessException) cause).getNextAction();
					
			} else if (cause instanceof SystemException) {
				message = ((SystemException) cause).getMessage();
				server.error(message);
				switch (action) {
					case "inicio":
						server.error(((SystemException) cause).getMessage());
						switch (message) {
							case "No se ha obtenido valor de ttoo gen secur":
								server.error("Error en acceso a excel drive");
								break;
							default: 
								relaunchRobot();
								break;
						}
						
						// si peta en inicio, relanzar robot para volver a intentar google sheets etc
//						relaunchRobot();
						break;
					case "iniciarSAP":
						if(contadorApertura <= 3) {
							contadorApertura++;
							server.debug("contador: " + contadorApertura);
							sapControl.sapClose();
							return ((SystemException) cause).getNextAction();
						}
						else {
							cartasPagoErroneas.add(currentCartaPago);
							sapControl.sapClose();
							escribirExcel("NO");
							return "enviarInformeUsuario";
						}

					case "sapAbrirTransaccionF32":
						// intentamos realizar la transaccion 2 veces, si no nos vamos a fin
						if(contadorI <= 2) {
							contadorI++;
							return ((SystemException) cause).getNextAction();
						}
						else {
							cartasPagoErroneas.add(currentCartaPago);
							sapControl.sapClose();
							escribirExcel("NO");
							return "enviarInformeUsuario";
						}
					case "lecturaCartasPago":
						if(message.equals("Esta carta de pago contiene imagen, no se puede continuar")){
							server.error("PNG cuando deberia haber venido otro tipo de archivo en el email");
						}
						else if(message.equals("Error png")) {
							server.error("Error png ");
						}
						else if(message.equals("No se ha podido conectar")) {
							//relaunchRobot
							control = true;
							return "fin";
						}
						else if(message.equals("Error en getInfo, no se devuelve array")) {
							return "fin";
						}
						else {// si no es alguna de las anteriores debe ser problema de excel drive 
							server.error("Problema excel drive, escribiremos excel, habra que marcar como no leida");
							mensajeDeError = "Problema excel drive, habra que marcar la carta de pago como no leida";
							escribirExcel("NO");
						}
						return "quedanCartasPorProcesar";	
					case "sapF32CompensarDeudorProcesarPartidasAbiertas":
						server.error("No es posible detectar el importe total de la carta de pago");
						return casoExcepctionVueltaAlBucle(Constantes.MENSAJE_WARNING_COMPENSAR_DEUDOR_DATOS_CABECERA2);
					case "contabilizar":
						server.error("No anexado, no ha aparecido ventana de visualizar documento");
//						return casoExcepctionVueltaAlBucle(Constantes.MENSAJE_WARNING_NO_ANEXADO);
						return "quedanCartasPorProcesar";
					default:
						server.error("SystemException not contemplated in the action '" + action + Constantes.MAYORMAYOR + exception.getMessage());
						throw exception;
				}
				return ((SystemException) cause).getNextAction(); 
			}
		}
		server.error("Exception not contemplated in the action '" + action + Constantes.MAYORMAYOR + exception.getMessage());
		throw exception;
	}
    
    
}
