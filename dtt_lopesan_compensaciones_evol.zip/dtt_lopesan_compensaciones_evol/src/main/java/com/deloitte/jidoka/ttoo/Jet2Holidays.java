package com.deloitte.jidoka.ttoo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.deloitte.jidoka.lopesan.cartapago.CartaPago;
import com.deloitte.jidoka.lopesan.cartapago.Casuistica;
import com.deloitte.jidoka.lopesan.cartapago.Constantes;
import com.deloitte.jidoka.lopesan.cartapago.Factura;
import com.novayre.jidoka.client.api.IJidokaServer;

public class Jet2Holidays extends Touroperador {

	
	
	public Jet2Holidays(IJidokaServer<?> server,String sociedad, List<String> codigosDeudor, String ttooCuentaAcreedor, String ttooName, String nombreFichero,
			HashMap<String, Double> sumatorios)  {
		super(server, sociedad, codigosDeudor, ttooCuentaAcreedor, ttooName, nombreFichero, sumatorios);
	}

	
	public CartaPago procesarCartaPagoPDF(String text, List<Casuistica> listaCasuisticas) {
		server.info("Entra en Procesar Carta Pago PDF de " + Constantes.JET2HOLIDAYS);
		CartaPago cartaJet2Holidays= new CartaPago();
		String [] ings = text.split("\r");
		String importeTotal="";
		String fecha="";
		boolean casoEncontrado=false;
        server.info("Numero de lineas del pdf: " +ings.length);	
        for (String linea: ings) {
        	linea = linea.replaceAll("\n", "");
        	String[] split = linea.split(" ");
        	String identificador="";
        	String concepto="";
        	String importe="";
        	String definicion="";
        	String fechaConcepto="";
        	boolean contieneFecha=false;
        	boolean contieneImporte=false;
        	
    		for(String part:split) {
    			if (part.trim().matches(Constantes.ERFECHACONBARRAS)) {
    				fechaConcepto=part.trim();
    				contieneFecha=true;
    			}else if(part.trim().matches("(\\(|)\\d{1,3}(\\,\\d{3})*(\\.\\d{2})(\\)|)?")) {
    				importe=part.trim();
    				contieneImporte=true;
    			}
    		}
        	casoEncontrado = false;
        	if (contieneFecha && contieneImporte) {
        		if (split.length>4) {
        			concepto=linea.replaceAll(fechaConcepto, "").replaceAll(importe, "").replaceAll("\\(", "").replaceAll("\\)", "").trim();
        			identificador=getMatch("\\d+\\/\\w{3}\\d{2}", concepto);
        			if (identificador.equals("")) {
        				identificador=concepto;
        			}
        			definicion=identificador;
        		}else {
        			for (int i=0; i<split.length; i++) {
        				if (!split[i].isEmpty() && i>0) {
        					identificador=split[i].trim();
        					definicion=identificador;
        					break;
        				}
        			}
        		}
	        	for(Casuistica casuistica : listaCasuisticas) {	
	        		String tipo = casuistica.getTipo();
	        		
	        		List<String> casos = casuistica.getValores();
	        		for(String caso : casos) {
	        			if(linea.contains(caso) && split.length >3 && !caso.equalsIgnoreCase("-") ) {
	        				boolean facturaExiste=false;
        					if (tipo.equalsIgnoreCase(Constantes.FACTURA)){
        						Double resultado = null;
    							for (Factura factura:cartaJet2Holidays.getFacturas()) {
	    							if (identificador.equals(factura.getIdentificador())){
	    								aumentarSaldoFacturas(tipo,importe);
	    								resultado=Double.sum(stringToNumber(factura.getImporte()),stringToNumber(importe));
	    								factura.setImporte(String.format("%.2f",resultado));
	    								server.info("Actualizada la factura del tipo " + tipo + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + factura.getImporte());
	    								facturaExiste=true;
	    								break;
	    							}
	    						}
        					}
        					if(!facturaExiste){	        						
        						aumentarSaldoFacturas(tipo,importe);
        						Factura factura = new Factura(tipo,identificador,importe,definicion);
        						cartaJet2Holidays.addFactura(factura);       
        						server.info(Constantes.ANADIDAFACTURATIPO + tipo + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + importe);
        					}
	    					casoEncontrado = true;
	        			}
	        		}
	        	}
	        	if(!casoEncontrado && split.length>=2) {
	        		if (importe.contains("(") && importe.contains(")")) {	        			
	        			aumentarSaldoFacturas(Constantes.PAGODEMENOS, importe);
	        			Factura factura = new Factura(Constantes.PAGODEMENOS,identificador,importe.replace("(", "").replace(")", ""),definicion);
	        			server.info(Constantes.ANADIDAFACTURATIPO + Constantes.PAGODEMENOS + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + importe );
	        			cartaJet2Holidays.addFactura(factura);
	        		}else {
	        			aumentarSaldoFacturas(Constantes.PAGODEMAS, importe);
	        			Factura factura = new Factura(Constantes.PAGODEMAS,identificador,importe,definicion);
	        			server.info(Constantes.ANADIDAFACTURATIPO + Constantes.PAGODEMAS + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + importe );
	        			cartaJet2Holidays.addFactura(factura);
	        		}
				}
        	}
        	if(linea.contains("Total") && linea.contains("Payment") && !linea.contains("Continued") ) {
        		importeTotal=split[split.length-1];
        		server.info("Importe Total: "+importeTotal);
        		cartaJet2Holidays.setImporte(importeTotal);
        	}  	
        	
        	if(fecha.equalsIgnoreCase("") && linea.contains("Date")) {
        		fecha=getMatch(Constantes.ERFECHACONBARRAS, linea);     		
        	}
        }
        sumatorios.forEach((k,v) -> server.info("Key: " + k + ": Value: " + v));
        cartaJet2Holidays.setSumatorios(sumatorios);
        cartaJet2Holidays.setSociedad(super.getSociedad());
        cartaJet2Holidays.setTtooDeudor(super.getTtooCuentaDeudor());
        cartaJet2Holidays.setTtooAcreedor(super.getTtooCuentaAcreedor());
        cartaJet2Holidays.setNombreTuroperador(super.getTouroperadorName());
        cartaJet2Holidays.setNombreDocumento(super.getNombreFichero());
        if(!fecha.equalsIgnoreCase("")) {
        	fecha = fecha.replaceAll("/", ".");
        	fecha = fecha.replaceAll("-", ".");
        	cartaJet2Holidays.setFecha(fecha);
        }
        else {
        	cartaJet2Holidays.setFecha(super.getFecha());
        }
        server.info("La fecha es: "+cartaJet2Holidays.getFecha());
        cartaJet2Holidays.setOtros(calcularOtros(Constantes.JET2HOLIDAYS,cartaJet2Holidays.getImporte(), listaCasuisticas, cartaJet2Holidays.getSaldosDeposito()));
        return cartaJet2Holidays;
	}


	@Override
	public CartaPago procesarCartaPagoWord(String text, List<Casuistica> listaCasuisticas) {
		server.info("Entra en Procesar Carta Pago Word de " + Constantes.JET2HOLIDAYS);
		CartaPago cartaJet2Holidays= new CartaPago();
		String [] ings = text.split("\r");
		String importeTotal="";
		boolean casoEncontrado=false;
        server.info("Numero de lineas del pdf: " +ings.length);	
        for (String linea: ings) {
        	linea = linea.replaceAll("\n", "");
        	String[] split = linea.split("\t");
        	String identificador="";
        	String importe="";
        	String definicion="";
        	boolean contieneFecha=false;
        	boolean contieneImporte=false;
        	
    		for(String part:split) {
    			if (part.trim().matches(Constantes.ERFECHACONBARRAS)) {
    				contieneFecha=true;
    			}else if(part.trim().matches("(\\(|)\\d{1,3}(\\,\\d{3})*(\\.\\d{2})(\\)|)?")) {
    				importe=part.trim();
    				contieneImporte=true;
    			}
    		}
        	casoEncontrado = false;
        	if (contieneFecha && contieneImporte) {
        		for (int i=0; i<split.length; i++) {
        			if (!split[i].isEmpty() && i>0 && split[i].trim().matches("\\d+\\/\\w{3}\\d{2}")){
        				identificador=split[i].trim();
        				definicion=identificador;
        				break;
        			}
        		}
        		if(identificador.equalsIgnoreCase("")) {
        			server.info("Lee la fecha pero no reconoce el identificador");
        			identificador = split[2];
        			server.info("El nuevo identificador es: " + identificador);
        			definicion = identificador;
        		}
	        	for(Casuistica casuistica : listaCasuisticas) {	
	        		String tipo = casuistica.getTipo();
	        		
	        		List<String> casos = casuistica.getValores();
	        		for(String caso : casos) {
	        			if(linea.contains(caso) && split.length >4 && !caso.equalsIgnoreCase("-") ) {
	        				boolean facturaExiste=false;
        					if (tipo.equalsIgnoreCase(Constantes.FACTURA)){
        						Double resultado = null;
    							for (Factura factura:cartaJet2Holidays.getFacturas()) {
	    							if (identificador.equals(factura.getIdentificador())){
	    								aumentarSaldoFacturas(tipo,importe);
	    								resultado=Double.sum(stringToNumber(factura.getImporte()),stringToNumber(importe));
	    								factura.setImporte(String.format("%.2f",resultado));
	    								server.info("Actualizada la factura del tipo " + tipo + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + factura.getImporte());
	    								facturaExiste=true;
	    								break;
	    							}
	    						}
        					}
        					if(!facturaExiste){	        						
        						aumentarSaldoFacturas(tipo,importe);
        						importe = importe.replaceAll("(\\(|\\))","");
        	        			server.info("El importe modificado es: " + importe);
        						Factura factura = new Factura(tipo,identificador,importe,definicion);
        						cartaJet2Holidays.addFactura(factura); 
        						
        						server.info(Constantes.ANADIDAFACTURATIPO + tipo + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + importe);
        					}
	    					casoEncontrado = true;
	        			}
	        		}
	        	}
	        	if(!casoEncontrado && split.length>=2) {
	        		if (importe.contains("(") && importe.contains(")")) {	        			
	        			aumentarSaldoFacturas(Constantes.PAGODEMENOS, importe);
	        			importe = importe.replaceAll("(\\(|\\))","");
	        			server.info("El importe modificado es: " + importe);
	        			//importe = importe.replaceAll("\\)","");
	        			Factura factura = new Factura(Constantes.PAGODEMENOS,identificador,importe.replace("(", "").replace(")", ""),definicion);
	        			server.info(Constantes.ANADIDAFACTURATIPO + Constantes.PAGODEMENOS + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + importe );
	        			cartaJet2Holidays.addFactura(factura);
	        		}else {
	        			aumentarSaldoFacturas(Constantes.PAGODEMAS, importe);
	        			Factura factura = new Factura(Constantes.PAGODEMAS,identificador,importe,definicion);
	        			server.info(Constantes.ANADIDAFACTURATIPO + Constantes.PAGODEMAS + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + importe );
	        			cartaJet2Holidays.addFactura(factura);
	        		}
				}
        	}
        	if(linea.contains("Total") && linea.contains("Payment") && !linea.contains("Continued") ) {
        		importeTotal=split[split.length-1];
        		server.info("Importe Total: "+importeTotal);
        		cartaJet2Holidays.setImporte(importeTotal);
        	}  	
        }
        sumatorios.forEach((k,v) -> server.info("Key: " + k + ": Value: " + v));
        cartaJet2Holidays.setSumatorios(sumatorios);
        cartaJet2Holidays.setSociedad(super.getSociedad());
        cartaJet2Holidays.setTtooDeudor(super.getTtooCuentaDeudor());
        cartaJet2Holidays.setTtooAcreedor(super.getTtooCuentaAcreedor());
        cartaJet2Holidays.setNombreTuroperador(super.getTouroperadorName());
        cartaJet2Holidays.setNombreDocumento(super.getNombreFichero());
        cartaJet2Holidays.setFecha(super.getFecha());
        return cartaJet2Holidays;
	}


	@Override
	public CartaPago procesarCartaPagoExcel(String text, List<Casuistica> listaCasuisticas) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public CartaPago procesarCartaPagoGenerica(String rutaFichero, List<Casuistica> listaCasuisticas) {
		// TODO Auto-generated method stub
		return null;
	}
	
	private Double stringToNumber(String valor) {
		String regexMilComa = "(\\(|)\\d{1,3}(,\\d{3})*(\\.\\d+)(\\)|)?";
		String regexMilPunto = "(\\(|)\\d{1,3}(.\\d{3})*(\\,\\d+)(\\)|)?";
		String regexComa = "\\d+(\\,\\d+)(-|)?";
		if(valor.matches(regexMilComa)) {
			valor = valor.replace(",","");
		}else if(valor.matches(regexMilPunto)) {
			valor = valor.replace(".", "");
			valor = valor.replace(",", ".");
		}else if(valor.matches(regexComa)) {
			valor = valor.replace(",", ".");
		}
		if(valor.contains("(") && valor.contains(")")) {
			valor = valor.replace("(", "").replace(")", "");
			return Double.valueOf(valor)*(-1);
		}else if(valor.contains("-")) {
			valor = valor.replace("-", "");
			return Double.valueOf(valor)*(-1);
		}else {
			return Double.valueOf(valor);
		}
	}	
}
