package com.deloitte.jidoka.lopesan.transaccion.SAP;

/**
 * The Enum ESapTransaction.
 */
public class TSap_FB03{

	/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
	public static final String BUTTON_CONTINUAR = "tbar[0]/btn[0]";
	/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
	public static final String BUTTON_GUARDAR = "tbar[0]/btn[11]";
	/**
	 * SAP transaction.
	 */
	public static final String TRANSACTION_NAME = "FB03";


	public static final class windowAcceso{
		
		public static final String NAME = "Visualizar documento: Acceso";
		
		public static final String TEXT_NUMERO_DOCUMENTO = "txtRF05L-BELNR";
		public static final String CTEXT_SOCIEDAD = "ctxtRF05L-BUKRS";
		public static final String TEXT_EJERCICIO = "txtRF05L-GJAHR";
		
	}
	
	public static final class windowcVistaEntrada{
		
		public static final String NAME = "Visualizar documento: Vista de entrada";
				
	}
	
	public static final class shell{
		
		public static final String BUTTON_SERVICIOS_OBJETO= "%GOS_TOOLBOX";
		
		public static final String TITL_SHELLCONT_SHELL= "titl/shellcont/shell";
		public static final String SHELLCONT_SHELL= "shellcont/shell";
		public static final String SHELLCONT= "shellcont";
		
		public static final String SHELL_BUTTON_CREAR= "CREATE_ATTA";
		public static final String SHELL_BUTTON_CREAR_ADJUNTO= "PCATTA_CREA";
		
		public static final class acction{
			public static final String pressButton = "pressButton";
			public static final String pressContextButton = "pressContextButton";
			public static final String selectContextMenuItem = "selectContextMenuItem";	
			public static final String close = "close";	
		}
		
	}
	
	public static final class popUpImportarFichero{
		
		public static final String NAME = "Importar fichero";
		
		public static final String BUTTON_CONTINUAR= "tbar[0]/btn[0]";
		
		public static final String CTEXT_DIRECTORIO= "ctxtDY_PATH";
		public static final String CTEXT_NOMBRE_FICHERO= "ctxtDY_FILENAME";
		
	}
		
}
