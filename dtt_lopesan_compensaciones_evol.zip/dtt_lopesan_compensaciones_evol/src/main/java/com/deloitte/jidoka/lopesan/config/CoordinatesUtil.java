package com.deloitte.jidoka.lopesan.config;

import java.awt.Point;
import java.awt.Rectangle;

import com.novayre.jidoka.client.api.IImageResource;
import com.novayre.jidoka.client.api.exceptions.JidokaFatalException;
import com.novayre.jidoka.windows.api.IWindows;

/**
 * Coordinates Utilities.
 * 
 * @author Javier
 *
 */
public final class CoordinatesUtil {

	public enum EMouseClickType {

		/**
		 * A click with the left button of the mouse.
		 * <p>
		 * This is the default click.
		 */
		LEFT,
		
		/**
		 * A click with the right button of the mouse.
		 */
		RIGHT;
	}

	
	/**
	 * Singleton instance.
	 */
	private static CoordinatesUtil instance;
	
	/**
	 * IWindows.
	 */
	private IWindows windows;
	
	/**
	 * Constructor.
	 */
	private CoordinatesUtil() {
	}
	
	/**
	 * Initializes the modules.
	 * 
	 * @param windows
	 *            {@link IWindows}
	 */
	public void init(IWindows windows) {
		
		this.windows = windows;
	}
	
	/**
	 * Gets the singleton instance.
	 * 
	 * @return the singleton
	 */
	public static CoordinatesUtil getInstance() {
		
		if (instance == null) {
			instance = new CoordinatesUtil();
		}
		
		return instance;
	}

	public void clickUpLeft(Rectangle r) {
		clickUpLeft(r, EMouseClickType.LEFT);
	}

	public void clickUpLeft(Rectangle r, EMouseClickType clickType) {
		
		double x = r.getX();
		double y = r.getY();
		
		Point coordinates = new Point((int)x, (int)y);
		
		mouseClick(clickType, coordinates);
	}
	
	public void clickDownLeft(Rectangle r) {
		clickDownLeft(r, EMouseClickType.LEFT);
	}
	
	public void clickDownLeft(Rectangle r, EMouseClickType clickType) {
		
		double x = r.getX();
		double y = r.getY() + r.height;
		
		Point coordinates = new Point((int)x, (int)y);
		mouseClick(clickType, coordinates);
	}
	
	public void clickUpRight(Rectangle r) {
		clickUpRight(r, EMouseClickType.LEFT);
	}
	
	public void clickUpRight(Rectangle r, EMouseClickType clickType) {
		
		double x = r.getX() + r.width;
		double y = r.getY();
		
		Point coordinates = new Point((int)x, (int)y);
		mouseClick(clickType, coordinates);
	}
	
	
	public void clickDownRight(Rectangle r) {
		clickDownRight(r, EMouseClickType.LEFT);
	}
	
	public void clickDownRight(Rectangle r, EMouseClickType clickType) {
		
		double x = r.getX() + r.width;
		double y = r.getY() + r.height;
		
		Point coordinates = new Point((int)x, (int)y);
		mouseClick(clickType, coordinates);
	}
	
	
	public void doubleClickDownRight(Rectangle r) {
		doubleClickDownRight(r, EMouseClickType.LEFT);
	}
	
	public void doubleClickDownRight(Rectangle r, EMouseClickType clickType) {
		
		double x = r.getX() + r.width;
		double y = r.getY() + r.height;
		
		Point coordinates = new Point((int)x, (int)y);
		mouseDoubleClick(clickType, coordinates);
	}
	
	public void doubleClickDownLeft(Rectangle r) {
		doubleClickDownLeft(r, EMouseClickType.LEFT);
	}
	
	public void doubleClickDownLeft(Rectangle r, EMouseClickType clickType) {
		
		double x = r.getX();
		double y = r.getY() + r.height;
		
		Point coordinates = new Point((int)x, (int)y);
		mouseDoubleClick(clickType, coordinates);
	}
	
	public void clickOffset(IImageResource image, int offsetX, int offsetY) {
		clickOffset(image, offsetX, offsetY, EMouseClickType.LEFT);
	}
	
	public void clickOffset(IImageResource image, int offsetX, int offsetY, EMouseClickType clickType) {
		
		Rectangle r = image.getRectangle();
		Double x = r.getCenterX();
		Double y = r.getCenterY();

		Point p = new Point(x.intValue(),y.intValue());
		
		if (offsetX < 0) { 
			p.x = (int) (r.getX() + offsetX);
		}
		
		if (offsetX > 0) {
			p.x = (int) (r.getX() + r.getWidth() + offsetX);
		}
		
		if (offsetY < 0) {
			p.y = (int) (r.getY() + offsetY);
		}
		
		if (offsetY > 0) {
			p.y = (int) (r.getY() + r.getHeight() + offsetY);
		}
		
		mouseClick(clickType, p);
	}
	
	/**
	 * Internal mouse click with <link>EclickType</link>
	 * @param clickType
	 * @param p
	 */
	private void mouseClick(EMouseClickType clickType, Point p) {
		
		switch (clickType) {
		case LEFT:
			
			windows.mouseLeftClick(p);
			
			break;
		
		case RIGHT:
			
			windows.mouseRightClick(p);
			
			break;
		default:
			
			break;
		}
		
	}
	
	/**
	 * Internal mouse double click with <link>EclickType</link>
	 * @param clickType
	 * @param p
	 */
	private void mouseDoubleClick(EMouseClickType clickType, Point p) {
		
		switch (clickType) {
		case LEFT:
			
			windows.mouseDoubleLeftClick(p);
			
			break;
			
		case RIGHT:
			
			throw new JidokaFatalException("Not implemented Double Right Click");
			
		default:
			
			break;
		}
		
	}
}
