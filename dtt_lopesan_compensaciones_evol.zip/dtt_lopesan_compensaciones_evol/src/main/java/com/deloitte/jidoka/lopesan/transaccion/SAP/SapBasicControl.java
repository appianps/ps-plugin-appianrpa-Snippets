package com.deloitte.jidoka.lopesan.transaccion.SAP;

import com.novayre.jidoka.sap.api.IGuiApplication;
import com.novayre.jidoka.sap.api.IGuiSession;
import com.novayre.jidoka.sap.api.ISap;
import com.novayre.jidoka.sap.api.cmp.GuiButton;
import com.novayre.jidoka.sap.api.cmp.GuiCTextField;
import com.novayre.jidoka.sap.api.cmp.GuiComponent;
import com.novayre.jidoka.sap.api.cmp.GuiPasswordField;
import com.novayre.jidoka.sap.api.cmp.GuiTextField;
import com.novayre.jidoka.sap.api.containers.GuiMainWindow;
import com.novayre.jidoka.sap.api.containers.GuiModalWindow;
import com.novayre.jidoka.sap.api.exception.SapFatalException;
import com.novayre.jidoka.sap.api.window.GuiTitleBar;
import com.novayre.jidoka.windows.api.IWindows;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;


import com.deloitte.jidoka.lopesan.exceptions.SystemException;
import com.deloitte.jidoka.lopesan.transaccion.SAP.SapConstants;
import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.ComThread;
import com.jacob.com.Dispatch;
import com.jacob.com.Variant;
import com.novayre.jidoka.client.api.IEasyCondition;
import com.novayre.jidoka.client.api.IJidokaServer;
import com.novayre.jidoka.client.api.IRobot;
import com.novayre.jidoka.client.api.IWaitFor;
import com.novayre.jidoka.client.api.exceptions.JidokaException;
import com.novayre.jidoka.client.api.exceptions.JidokaUnsatisfiedConditionException;
import com.novayre.jidoka.client.api.execution.IUsernamePassword;



/**
 * The SapBasicControl.
 */
public class SapBasicControl {
	
	/** Windows module.. */
	private IWindows windows;

	/** Server. */
	private IJidokaServer<?> server;

	/** SAP module. */
	protected IGuiApplication sap;

	/** SAP credentials. */
	private IUsernamePassword sapCredentials;
	
	/** IWaitFor . */
	private IWaitFor waitFor;
	
	

	/**
	 * SAP basic control constructor.
	 * 
	 * @param robot principal IRobot object
	 * @param windows principal IWindows object
	 * @param server principal IJidokaServer object
	 * @param waitFor principal IWaitFor object
	 */
	public SapBasicControl(IRobot robot, IWindows windows, IJidokaServer<?> server, IWaitFor waitFor) {
		this.windows = windows;
		this.server = server;
		this.waitFor = waitFor;
		// Initialize SAP module
		sap = ISap.getInstance(robot);
		sapCredentials = null;
	}	

	/**
	 * Select SAP IUsernamePassword credentials
	 * 
	 * @param sapCredentials the sapCredentials to set
	 */
	public void setSapCredentials(IUsernamePassword sapCredentials) {
		this.sapCredentials = sapCredentials;
	}
	
	private void initSAPComponents() {
		
		ActiveXComponent SAPROTWr, GUIApp, jConnection;
		Dispatch ROTEntry;
		Variant ScriptEngine;
		
		ComThread.InitSTA();
		
		SAPROTWr = new ActiveXComponent("SapROTWr.SapROTWrapper");
		
		try {
			
			ROTEntry = SAPROTWr.invoke("GetROTEntry", "SAPGUI").toDispatch();
			ScriptEngine = Dispatch.call(ROTEntry, "GetScriptingEngine");
			GUIApp = new ActiveXComponent(ScriptEngine.toDispatch());

			jConnection = new ActiveXComponent(GUIApp.invoke("Children", 0).toDispatch());
			
			server.debug("Connection Name: " + jConnection.getProperty("name"));

			GuiComponent connection = new GuiComponent();
			
			connection.setComponent(jConnection);
			
			Dispatch connectionChildrens = connection.getComponent().invoke("Children").toDispatch();
			Variant sessionCount = Dispatch.get(connectionChildrens, "Count");
			
			server.debug("SAP sessionCount: " + sessionCount);
			
		} catch (Exception e) {
			throw new SapFatalException("Error inicializando SAP", e);
		}
	}


	/**
	 * Action "SAP open". 
	 * <p>
	 * Open the SAP client.
	 * @throws SystemException If the conditions are not satisfied or if an I/O error occurs
	 */
	public void sapOpen(String sapConnection) throws SystemException  {

		// Gets SAP paths
		Path sapPath = Paths.get(SapConstants.App.SAP_EXECUTABLE_PATH, SapConstants.App.SAP_EXECUTABLE);

		// Open SAP logon window
		ProcessBuilder pb = new ProcessBuilder(sapPath.toString());

		try {

			pb.start();

			// Wait for the initial window title
			waitFor.window(30, true, true, ".*SAP.*"); // SapConstants.Titles.SAP_LOGON_WINDOW_TITLE);
//			windows.waitCondition(30, 1000, "Openning SAP, Activating Window", null, true, (i,context) -> windows.activateWindow(".*SAP.*"));
			windows.pause(3000);
			
			windows.activateWindow(".*SAP.*");
			windows.getKeyboard().escape().pause(1000); // por si acaso
			windows.activateWindow(".*SAP.*");
			windows.pause(1000);
			// por si acaso aparece ventana de windows
			if(windows.getActiveWindowTitle().matches(".*Cortana.*")) {
				windows.getKeyboard().escape().pause(1000);

				windows.activateWindow(".*SAP.*");
				windows.pause(2000);
				server.debug("Clicking on center...");
				windows.clickOnCenter();
				
				server.info("Sap application opened");
			}
			else if(windows.getActiveWindowTitle().matches(".*SAP.*")) {
				
				windows.activateWindow(".*SAP.*");
				windows.pause(2000);
				server.debug("Clicking on center...");
				windows.clickOnCenter();
				
				server.info("Sap application opened");
			}
			else {
				//server.warn("No se ha podido abrir SAP");
				server.debug("si sap no es null abrimos");
				windows.waitCondition(10, 1000, "Open SAP window", null, true, (i,context) -> windows.getWindow(".*SAP.*") != null);
				windows.activateWindow(".*SAP.*");
				windows.pause(1000);
				server.debug("Clicking on center...");
				windows.clickOnCenter();
				server.info("Sap application opened");
			}
			
			
			
			
			windows.pause(2000);
			
			
			server.info("Ventana SAP activa: " + windows.getActiveWindowTitle());

	        // Type the SAP connection name and press the key "Enter". In this example we use 'SAP Demo'
			windows.keyboard().pause(1000).type(sapConnection).pause(1000).enter();

			waitFor.window(SapConstants.Timeouts.DEFAULT_WAIT, true, SapConstants.Titles.SAP_LOGON_WINDOW_TITLE_FIRST);
			
			windows.pause(2000);

			server.info("Connected to: " + sapConnection);
			GuiMainWindow win = null;
			try {				
				//initSAPComponents();
				// Instantiate the SAP module if it wasn't done before
				server.debug("dentro del try");
				if (!sap.isInitialized()) {
					server.debug("dentro del if");
					sap.init();
					server.debug("se ha hecho el init");
				}
				server.info(sap.refreshOpenSessions());
				// SAP Module initialization
				win = (GuiMainWindow) sap.getCurrentSession().getActiveWindow();
			} catch (Exception e) {
				throw new SystemException("SAP scripting may not be activated", null, null, true);
			}

			win.iconify();
			win.maximize();

			windows.pause(2000);

			server.info("Jidoka SAP module initialized");

		} catch (SystemException e) {
				throw e;
		} catch (Exception e) {
			throw new SystemException("SAP could not be opened: " + e.getMessage(), e, null, false);
		}
	}
	
	
	
	/**
	 * Action "SAP login"
	 * <p>
	 * Logged into the SAP app.
	 * @param language
	 * @throws JidokaException
	 * @throws JidokaUnsatisfiedConditionException
	 */
	public void sapLogin(String language, String mandante) throws JidokaException, JidokaUnsatisfiedConditionException {

		sap.refreshOpenSessions();

		// Gets the SAP session
		IGuiSession guiSession = sap.getConnection().getOpenSessions().get(0);
		
		// Gets the main window
		GuiMainWindow activeWindow = (GuiMainWindow) guiSession.getActiveWindow();

		// Check the login page
		if (!activeWindow.getText().matches(SapConstants.Titles.SAP_LOGON_WINDOW_TITLE)) {
			throw new JidokaException(
					"Unsuccessful login. We sould be at page: " + SapConstants.Titles.SAP_LOGON_WINDOW_TITLE);
		}

		// Insert username and password
		GuiTextField user = activeWindow.getUserArea().findById(SapConstants.Controls.LOGIN_USER_TEXTFIELD);

		user.setFocus();
		user.setText(sapCredentials.getUsername());
		
		GuiTextField txtmandante = activeWindow.getUserArea().findById(SapConstants.Controls.MANDANTE);
		txtmandante.setText(mandante);

		GuiPasswordField password = activeWindow.getUserArea().findById(SapConstants.Controls.LOGIN_PASSWORD_TEXTFIELD);

		password.setFocus();
		password.setText(sapCredentials.getPassword());
		
		GuiTextField lang = activeWindow.getUserArea().findById(SapConstants.Controls.LOGIN_LANGUAGE_TEXTFIELD);

		lang.setFocus();
		lang.setText(language);

		// Click the login button
		GuiButton btn = activeWindow.getToolBar().findById("btn[0]");
		btn.press();
		
		guiSession.waitIdle();
		
		// Checks if login failed		
		checkLoginFail(activeWindow);
		
		// Checks if the copyright window is active and the closes it
		checkCopyrightWindow(guiSession);

		// Checks that the user menu window is active
		GuiTitleBar titl = activeWindow.findById("titl");

		windows.waitCondition(3, 300, "User menu", null, true, true, (i, c) -> {

			return titl.getText().matches(SapConstants.Titles.SAP_MAIN_WINDOW_TITLE);

		});

		server.debug(guiSession.getActiveWindow().getText());
	}
	
	/**
	 * Action "SAP open transaction"
	 * <p>
	 * Opens the SAP transaction to search for employees.
	 * @param transaction Transaction name
	 * @param expectedTitle Window title expected
	 * @throws JidokaUnsatisfiedConditionException
	 */
	public void sapOpenTransaction(String transaction, String expectedTitle) throws JidokaUnsatisfiedConditionException {
		
		// Gets the SAP session
		IGuiSession session = sap.getCurrentSession();

		// Open the transaction
		session.sendCommand(transaction);

		String pageTitle = session.getActiveWindow().getText();
		
		// Check that the transaction has been opened
		IEasyCondition condition = () -> pageTitle.matches(expectedTitle);
		
		windows.waitCondition(30, 1000, "Checking  SAP", null, true, true, condition);
		
		server.info("Transaction opened: " + transaction);
		
	}
	
	/**
	 * Close SAP.
	 */
	public void sapClose() {
		closeSapProcesses();
		sap.setInitialized(false);
	}
	
	
	/**
	 * @return the sap
	 */
	public IGuiApplication getSap() {
		return sap;
	}


	/**
	 * @param sap the sap to set
	 */
	public void setSap(IGuiApplication sap) {
		this.sap = sap;
	}



	/**
	 * Close all SAP processes
	 */
	private void closeSapProcesses() {
		try {
			windows.killAllProcesses(SapConstants.App.SAP_EXECUTABLE, 1000);
		} catch (IOException e) {
		}

		windows.pause(1000);
	}

	/**
	 * Checks if login failed and throws the exception LoginFailException
	 * 
	 * @param guiMainWindow Active main window
	 * @throws JidokaException 
	 */
	private void checkLoginFail(GuiMainWindow guiMainWindow) throws JidokaException {
		
		String textStatusBar = guiMainWindow.getStatusBar().getText();
		
		// Checks the status bar
		if(textStatusBar.matches(SapConstants.Login.SAP_LOGIN_FAIL)) {
			throw new JidokaException(String.format("Login failed!. User: %s",sapCredentials.getUsername()));
		}
	}

	/**
	 * Checks if the copyright window is active and the closes it
	 * 
	 * @param guiSession SAP session
	 */
	private void checkCopyrightWindow(IGuiSession guiSession) {
		
		// Gets the modal window
		GuiModalWindow modalWindow = guiSession.getModalWindow();
		
		// If modalWindow is null, the copyright window is not active
		if(modalWindow == null) {
			server.info("Copyright window not active");
			return;
		}
		
		server.info("Copyright window active");
		
		// Close the modal window
		GuiButton btn = modalWindow.getToolBar().findById("btn[0]");
		btn.press();
		
		guiSession.waitIdle();
	}

	
}
