package com.deloitte.jidoka.ttoo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.deloitte.jidoka.lopesan.cartapago.CartaPago;
import com.deloitte.jidoka.lopesan.cartapago.Casuistica;
import com.deloitte.jidoka.lopesan.cartapago.Constantes;
import com.deloitte.jidoka.lopesan.cartapago.Factura;
import com.novayre.jidoka.client.api.IJidokaServer;

public class Apollo extends Touroperador {

	public Apollo(IJidokaServer<?> server, String sociedad, List<String> codigosDeudor, String ttooCuentaAcreedor,
			String ttooName, String nombreFichero, HashMap<String, Double> sumatorios) {
		super(server, sociedad, codigosDeudor, ttooCuentaAcreedor, ttooName, nombreFichero, sumatorios);
	}

	@Override
	public CartaPago procesarCartaPagoPDF(String text, List<Casuistica> listaCasuisticas) {

		try {
			server.info("Entra en Procesar Carta Pago de " + Constantes.DERTOURISTIKNORDICAB);
			CartaPago apollo = new CartaPago();
			String[] ings = text.split("\r");
			server.info("Numero de lineas del pdf: " + ings.length);
			String lastKey = "";
			String lastCase = "";
			String lastTipo = "";
			String fecha = "";
			String descripcion = "";
			String importe = "";
			boolean esperaImporte = false;
			for (String linea : ings) {
				linea = linea.replaceAll("\n", "");
				String[] split = linea.split(" ");
				boolean casoEncontrado = false;
				/*if (linea.contains("Date")) {
					//fecha = split[split.length - 1].replaceAll("­", "/");
					fecha = split[split.length - 1];
					fecha = fecha.replace("-", "/");
					server.info("La fecha es: " + fecha);
					String[] fechaPartida = fecha.split("/");
					String year = fechaPartida[2];
					server.info("El anno es: " + year);
					String month = String.format("%02d", Integer.decode(fechaPartida[0]));
					server.info("El mes es: " + month);
					String day = String.format("%02d", Integer.decode(fechaPartida[1]));
					server.info("El dia es: " + day);
					fecha = day + "." + month + "." + year;
					server.info("La fecha parseada correctamente es: " + fecha);
				}*/
				
				if (linea.contains("Date")) {
					// esto no es un - es un caracter especial SOFT HYPHEN..
					fecha = split[split.length - 1].replaceAll("­", "/"); // TODO: en funcion de unas cartas de pago u otras,
																		  // se hara con los comentarios o de esta manera
					/*
					//fecha = split[split.length - 1];
	    			//fecha = fecha.replace("-", "/");
					server.info("La fecha es: " + fecha);
					String[] fechaPartida = fecha.split("/");
					String year = fechaPartida[0];
					server.info("El anno es: " + year);
					String month = String.format("%02d", Integer.decode(fechaPartida[1]));
					server.info("El mes es: " + month);
					String day = String.format("%02d", Integer.decode(fechaPartida[2]));
					server.info("El dia es: " + day);
					fecha = day + "." + month + "." + year;
					server.info("La fecha parseada correctamente es: " + fecha);*/
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	    		    //Parsing the given String to Date object
	    			 
	    			fecha = fecha.replace("/", "-"); // este es el guion normal, 
//	    			System.out.println("------fecha1---------- " + fecha);
	    		    Date date = formatter.parse(fecha);
	    		    server.debug("Date sin parsear: "+ date);
	    		     
	    			fecha = new SimpleDateFormat("dd.MM.yyyy").format(date);
//	    			System.out.println("Date2: " + fecha);
	    			server.info("La fecha parseada correctamente es: " + fecha);
				}
				
				

				for (Casuistica casuistica : listaCasuisticas) {
					// Aqui tendriamos el tipo de casuistica y la lista de string que hay que buscar
					String tipo = casuistica.getTipo();

					List<String> casos = casuistica.getValores();
					for (String caso : casos) {
						if (split[0].contains(caso) && split.length >= 3 && !caso.equalsIgnoreCase("-")) {
							lastKey = split[0].replace("­", "/");
							// Caracter "-" no es guion, se trata del caracter SOFT HYPHEN.
							// Para obtenerlo, se debe abrir Word y buscarlo por su valor hexadecimal
							// (00AD). Una vez insertardo en página en blanco, copy-paste en codigo
							if (tipo.equalsIgnoreCase(Constantes.FACTURA)
									|| tipo.equalsIgnoreCase(Constantes.ABONODESCONTADO)) {
								lastKey = getMatch("\\d{1,5}(\\/)[A-z]+\\d{1,2}", lastKey);
							}
							lastCase = caso;
							lastTipo = tipo;
							descripcion = split[2];
							esperaImporte = true;
						}
						if (linea.contains("EUR") && (split.length == 4 || split.length >= 7) && lastTipo.equals(tipo)
								&& lastCase.equals(caso) && esperaImporte) {
							String importeFactura = split[split.length - 1].replace(" ", "");
							String newImporte = obtenerImporteSinCaracteresRaros(importeFactura);
//							String newImporte = importeFactura.replaceAll(",", "");
							server.info(Constantes.ELNUEVOIMPORTEES + newImporte);

							boolean facturaExiste = false;
							if (tipo.equalsIgnoreCase(Constantes.FACTURA)) {
								Double resultado = null;
								for (Factura factura : apollo.getFacturas()) {
									if (lastKey.equals(factura.getIdentificador())) {
										aumentarSaldoFacturas(lastTipo, newImporte);
										resultado = Double.sum(stringToNumber(factura.getImporte()),
												stringToNumber(importeFactura));
										factura.setImporte(String.format("%.2f", resultado));
										server.info("Actualizada la factura del tipo " + lastTipo + Constantes.CONCODIGO
												+ lastKey + Constantes.CONIMPORTE + factura.getImporte());
										facturaExiste = true;
										break;
									}
								}
							}
							if (!facturaExiste) {
								aumentarSaldoFacturas(lastTipo, newImporte);
								Factura factura = new Factura(lastTipo, lastKey, newImporte, descripcion);
								esperaImporte = false;
								apollo.addFactura(factura);
								server.info(Constantes.ANADIDAFACTURATIPO + lastTipo + Constantes.CONCODIGO + lastKey
										+ Constantes.CONIMPORTE + newImporte + " Con descripcion " + descripcion);
							}
							casoEncontrado = true;
						}
					}
				}
				if (!casoEncontrado && split.length >= 7) {
					importe = split[split.length - 1];
					String identificador = split[0];
					if (importe.contains("­")) {
						String newImporte = obtenerImporteSinCaracteresRaros(importe);
//						String newImporte = importe.replaceAll(",", "");
						server.info(Constantes.ELNUEVOIMPORTEES+ newImporte);
						aumentarSaldoFacturas(Constantes.PAGODEMENOS, newImporte);
						// Para apollo la descripcion es la misma que el identificador
						Factura factura = new Factura(Constantes.PAGODEMENOS, identificador,
								newImporte.replace("­", ""), identificador);
						server.info(Constantes.ANADIDAFACTURATIPO + Constantes.PAGODEMENOS + Constantes.CONCODIGO
								+ identificador + Constantes.CONIMPORTE + newImporte);
						apollo.addFactura(factura);
					} else {
						String newImporte = obtenerImporteSinCaracteresRaros(importe);
//						String newImporte = importe.replaceAll(",", "");
						server.info(Constantes.ELNUEVOIMPORTEES + newImporte);
						aumentarSaldoFacturas(Constantes.PAGODEMAS, newImporte);
						// Para apollo la descripcion es la misma que el identificador
						Factura factura = new Factura(Constantes.PAGODEMAS, identificador, newImporte, identificador);
						server.info(Constantes.ANADIDAFACTURATIPO + Constantes.PAGODEMAS + Constantes.CONCODIGO
								+ identificador + Constantes.CONIMPORTE + newImporte);
						apollo.addFactura(factura);
					}
				}
				
				if (linea.contains("*") && linea.substring(linea.length() - 1).equals("*")) {
					importe = linea.replace("*", "");
					importe = obtenerImporteSinCaracteresRaros(importe);
//					importe = importe.replaceAll(",", "");
					server.info("El importe es: " + importe);
					apollo.setImporte(importe);
				}
				apollo.setSumatorios(sumatorios);
				apollo.setSociedad(getSociedad());
				apollo.setTtooDeudor(super.getTtooCuentaDeudor());
				apollo.setTtooAcreedor(super.getTtooCuentaAcreedor());
				apollo.setNombreTuroperador(getTouroperadorName());
				apollo.setNombreDocumento(getNombreFichero());
				
				if (!fecha.equalsIgnoreCase("")) {
					apollo.setFecha(fecha);
				} else {
					apollo.setFecha(getFecha());
				}
			}
			apollo.setOtros(calcularOtros(Constantes.DERTOURISTIKNORDICAB, importe, listaCasuisticas,apollo.getSaldosDeposito()));
			return apollo;

		} catch (Exception e) {
			server.error("Falla en la lectura " + e);
			return null;
		}
	}

	@Override
	public CartaPago procesarCartaPagoWord(String text, List<Casuistica> listaCasuisticas) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CartaPago procesarCartaPagoExcel(String text, List<Casuistica> listaCasuisticas) {
		// TODO Auto-generated method stub
		return null;
	}

	private String obtenerImporteSinCaracteresRaros(String importeFactura) {
		String newImporte = "";
		for (int i = 0; i < importeFactura.length(); i++) {
			String punto = "" + importeFactura.charAt(i);
			if (Character.isDigit(importeFactura.charAt(i))) {
				newImporte = newImporte + importeFactura.charAt(i);
			}
			if (punto.equalsIgnoreCase(".") || punto.equalsIgnoreCase(",")) {
				newImporte = newImporte + ".";
			}
		}
		return newImporte;
	}

	private static Double stringToNumber(String valor) {
		String newImporte = "";
		String regexComa = "\\d+(\\,\\d+)(-|)?";
		if (valor.matches(regexComa)) {
			valor = valor.replace(",", ".");
		}
		for (int i = 0; i < valor.length(); i++) {
			String punto = "" + valor.charAt(i);
			if (Character.isDigit(valor.charAt(i)) || valor.charAt(i) == '­') {
				newImporte = newImporte + valor.charAt(i);
			}
			if (punto.equalsIgnoreCase(".") || punto.equalsIgnoreCase(",")) {
				newImporte = newImporte + ".";
			}
		}
		// Segundo guion es el caracter SOFT HYPHEN
		if (newImporte.contains("-") || newImporte.contains("­")) {
			newImporte = newImporte.replace("-", "");
			newImporte = newImporte.replace("­", "");
			return Double.valueOf(newImporte) * (-1);
		} else {
			return Double.valueOf(newImporte);
		}
	}

	@Override
	public CartaPago procesarCartaPagoGenerica(String rutaFichero, List<Casuistica> listaCasuisticas) {
		// TODO Auto-generated method stub
		return null;
	}
}
