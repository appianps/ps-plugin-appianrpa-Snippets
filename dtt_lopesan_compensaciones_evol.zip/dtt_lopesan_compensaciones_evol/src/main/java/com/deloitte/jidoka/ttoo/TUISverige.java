package com.deloitte.jidoka.ttoo;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import com.deloitte.jidoka.lopesan.cartapago.CartaPago;
import com.deloitte.jidoka.lopesan.cartapago.Casuistica;
import com.deloitte.jidoka.lopesan.cartapago.Constantes;
import com.deloitte.jidoka.lopesan.cartapago.Factura;
import com.novayre.jidoka.client.api.IJidokaServer;

public class TUISverige extends Touroperador {

	public TUISverige(IJidokaServer<?> server, String sociedad, List<String> codigosDeudor, String ttooCuentaAcreedor, String ttooName, String nombreFichero,
			HashMap<String, Double> sumatorios)  {
		super(server, sociedad, codigosDeudor, ttooCuentaAcreedor, ttooName, nombreFichero, sumatorios);
	}

	@Override
	public CartaPago procesarCartaPagoPDF(String text, List<Casuistica> listaCasuisticas) {
		server.info("Entra en Procesar Carta Pago TUI Sverige");
		CartaPago tuiSverige = new CartaPago();
		String [] ings = text.replaceAll("\n", "").replaceAll("\r", "").toUpperCase().split("</TR>");
		String fecha="";
		boolean contieneImporte;
		boolean comienzoFacturas=false;
		server.info("Numero de lineas del correo: " +ings.length);
		for (String linea: ings) {
			linea=linea.replaceAll("<[^>]+>", " ").trim();
			String[] split = linea.split(" ");
			String identificador="";
			String descripcion="";
			String importe="";
			contieneImporte=false;
			
			if (linea.contains("INVOICE") && linea.contains("NUMBER") && linea.contains("AMOUNT") && linea.contains("PAID")) {
				comienzoFacturas=true;
			}
			for(String part:split) {
        		if(part.matches("(-|)\\d+(\\.\\d{2})(-|)?")) {
        			importe=part;
        			contieneImporte=true;
        		}
        	}
			if (comienzoFacturas && contieneImporte) {
				for(Casuistica casuistica : listaCasuisticas) {
					String tipo = casuistica.getTipo();
					List<String> casos = casuistica.getValores();
	        		for(String caso : casos) {
	        			if(linea.contains(caso.toUpperCase()) && split.length >=2 && !caso.equalsIgnoreCase("-")) {
	        				identificador=split[0];
	        				descripcion=identificador;
	        				boolean facturaExiste=false;
        					if (tipo.equalsIgnoreCase(Constantes.FACTURA)){
        						Double resultado = null;
    							for (Factura factura:tuiSverige.getFacturas()) {
	    							if (identificador.equals(factura.getIdentificador())){
	    								aumentarSaldoFacturas(tipo,importe);
	    								resultado=Double.sum(stringToNumber(factura.getImporte()),stringToNumber(importe));
	    								factura.setImporte(String.format("%.2f",resultado));
	    								server.info("Actualizada la factura del tipo " + tipo + " con codigo " + identificador + " con importe " + factura.getImporte());
	    								facturaExiste=true;
	    								break;
	    							}
	    						}
        					}
        					boolean existe = checkIfExists(identificador,tuiSverige);
        					if(!facturaExiste && !existe){	        						        						
        						server.info("Añadida la factura del tipo " + tipo + " con codigo " + identificador + " con importe " + importe);
        						aumentarSaldoFacturas(tipo,importe);
        						Factura factura = new Factura(tipo,identificador,importe,descripcion);
        						tuiSverige.addFactura(factura);
        					}
	        			}
	        		}
	        	}
			}
			if (linea.contains("PAYMENT") && linea.contains("AMOUNT")) {
				String importeTotal = split[split.length-1];
				server.info("Importe total: "+importeTotal);
				tuiSverige.setImporte(importeTotal);
			}
			if (linea.contains("PAYMENT") && linea.contains("DATE") && split[split.length-1].matches("\\d{2}-\\w{3}-\\d{2}")) {		
				fecha=split[split.length-1];
				try {					
					fecha=formatDate(fecha.toUpperCase(),"dd-MMM-yy","dd.MM.yyyy",new Locale("es"));
				}catch (Exception e) {
					try {
						fecha=formatDate(fecha.toUpperCase(),"dd-MMM-yy","dd.MM.yyyy",Locale.ENGLISH);
					}catch (Exception e1) {
						server.error("No es posible detectar el idioma de la fecha ["+e1.getMessage()+"]: "+fecha);
						fecha="";
					}
				}
				
			}
		}
		sumatorios.forEach((k,v) -> server.info("Key: " + k + ": Value: " + v));
        tuiSverige.setSumatorios(sumatorios);
        tuiSverige.setSociedad(getSociedad());
        tuiSverige.setTtooDeudor(super.getTtooCuentaDeudor());
        tuiSverige.setTtooAcreedor(super.getTtooCuentaAcreedor());
        tuiSverige.setNombreTuroperador(getTouroperadorName());
        tuiSverige.setNombreDocumento(getNombreFichero());
        
        if(!fecha.equalsIgnoreCase("")) {
			tuiSverige.setFecha(fecha);
        }
        else {
        	tuiSverige.setFecha(super.getFecha());
        }
        server.info("Fecha: "+fecha);
        tuiSverige.setOtros(calcularOtros(Constantes.TUISVERIGE,tuiSverige.getImporte(), listaCasuisticas,tuiSverige.getSaldosDeposito()));
		return tuiSverige;	
	}
	
	private Double stringToNumber(String valor) {
		String regexMilComa = "\\d{1,3}(,\\d{3})*(\\.\\d+)(-|)?";
		String regexMilPunto = "\\d{1,3}(.\\d{3})*(\\,\\d+)(-|)?";
		String regexComa = "\\d+(\\,\\d+)(-|)?";
		if(valor.matches(regexMilComa)) {
			valor = valor.replace(",","");
		}else if(valor.matches(regexMilPunto)) {
			valor = valor.replace(".", "");
			valor = valor.replace(",", ".");
		}else if(valor.matches(regexComa)) {
			valor = valor.replace(",", ".");
		}
		if(valor.contains("-")) {
			valor = valor.replace("-", "");
			return Double.valueOf(valor)*(-1);
		}else {
			return Double.valueOf(valor);
		}
	}

	@Override
	public CartaPago procesarCartaPagoWord(String text, List<Casuistica> listaCasuisticas) {
		return null;
	}

	@Override
	public CartaPago procesarCartaPagoExcel(String text, List<Casuistica> listaCasuisticas) {
		return null;
	}

	@Override
	public CartaPago procesarCartaPagoGenerica(String rutaFichero, List<Casuistica> listaCasuisticas) {
		return null;
	}
	
	private boolean checkIfExists(String identificador, CartaPago tuiSverige) {
		
		boolean salida = false;
		for(Factura fact : tuiSverige.getFacturas()) {
			if(fact.getIdentificador().equalsIgnoreCase(identificador)) {
				salida = true;
			}
		}
		
		return salida;
	}

}
