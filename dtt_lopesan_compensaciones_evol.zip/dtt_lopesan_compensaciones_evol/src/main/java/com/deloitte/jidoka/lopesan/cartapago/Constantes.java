package com.deloitte.jidoka.lopesan.cartapago;

public class Constantes {

	private Constantes() {

	}

	public static final String FACTURA = "Factura Pagado";
	public static final String ABONODESCONTADO = "Abono Descontado";
	public static final String PAGODEMENOS = "Pagado de Menos";
	public static final String PAGODEMAS = "Pagado de Mas";
	public static final String RECLAMACION = "Reclamacion";
	public static final String DEDUCCION = "Deduccion Contrato";
	public static final String PREPAGO = "Pre pagos";
	public static final String PAGODIFERENCIAFACTURA = "pago de diferencia en factura";
	public static final String OTROS = "Otros";

	public static final String TUI_UK = "TUI UK LTD";
	public static final String THOMAS_COOK = "THOMAS COOK GmbH";
	public static final String THOMAS_COOK_NORTHERN = "THOMAS COOK NORTHEN EUROPEN AB";
	public static final String DERTOURISTIKNORDICAB = "DER Touristik Nordic AB";
	public static final String JET2HOLIDAYS = "JET2HOLIDAYS";
	public static final String MEETINGPOINT = "MEETING POINT SPAIN, S.L.";
	public static final String TUINETHERLAND = "TUI NETHERLAND N.V.";
	public static final String GLOBALIABUSSINESS = "GLOBALIA BUSSINESS TRAVEL, S.A.U";
	public static final String VIAJESCANARIASEUROPA = "VIAJES CANARIAS EUROPA SL";
	public static final String TUISVERIGE = "TUI SVERIGE AB";
	public static final String VIAJESELCORTEINGLES = "VIAJES EL CORTE INGLES";
	public static final String GENERICO = "GENERICO";
	public static final String DEPOSITO = "DEPOSITO";

	public static final String PANTALLA_CORREGIR_POSICION = "Compensar deudor Corregir Posición de deudor";
	public static final String PANTALLA_DATOS_CABECERA = "Compensar deudor: Datos cabecera";
	public static final String PANTALLA_VISUALIZAR_RESUMEN = "Compensar deudor Visualizar Resumen";
	public static final String PANTALLA_SAP_EASY_ACCESS = "SAP Easy Access";

	public static final String SAP_LOGON_WINDOW_TITLE = "SAP Logon.*";

	// rangos
	public static final String RANGESOCIEDADES = "Sociedades!A4:E17";
	public static final String RANGETTOO = "TTOO!A4:E16";

	public static final String RANGECLVCT = "Casuisticas!B20:B26";
	public static final String RANGECUENTA = "Casuisticas!C20:C26";
	public static final String RANGECME = "Casuisticas!D20:D26";

	public static final String RANGECASUISTICAS = "Casuisticas!A4:G17";
	public static final String RANGECODIGOCASUISTICASOCIEDAD = "Sociedades!F4:G17";
	public static final String RANGEENCABEZADOCASUISTICA = "Casuisticas!B3:G3";

	public static final String RANGENOMBRETTOO = "TTOO!A4:A16";

	public static final String RANGERECLAMACIONES = "Robotics Base!A5:W";

	/**
	 * SAP logon executable
	 */
	private static final String SAP_EXEC = "saplogon.exe";

	/**
	 * SAP logon executable full path
	 */
	public static final String SAP_EXEC_FULL_PATH = "C:\\Program Files (x86)\\" + "SAP\\FrontEnd\\SAPgui\\" + SAP_EXEC;

	public static final String LOPESAN_SAP_CREDENTIALS = "lopesan_sap";

	public static final String LOPESAN_MAIL_CREDENTIALS = "lopesan_email_compensaciones";

	public static final String MANDANTEDESAROLLO = "310";
	public static final String MANDANTEPRODUCCION = "410";

	public static final String ID_EXCEL_MAESTRO_COMPENSACIONES = "1o-n1i9k6UENYxDXhT52NPMRyy9dAayz9rcZl-nJOE-E";
	public static final String ID_EXCEL_MAESTRO_RECLAMACIONES = "1rrH55FJ8JG23iWHOt7wFz00Y-wVsKaichqomM30qN7U";
	public static final String ID_EXCEL_REGISTRO = "1c0_9ytCBrHbKFFl7AqWm4MH9eczOljBAGxyxUxhcoII";

	public static final String MENSAJE_WARNING_MARCAR_FACTURAS = "Fallo al marcar las facturas";
	public static final String MENSAJE_WARNING_BUSCAR_PAGO_CUENTA_CLIENTE = "Fallo al buscar el Pago en Cuenta Cliente";
	public static final String MENSAJE_WARNING_ESTA_PAGO_CLIENTE = "Fallo al comprobar si existe el Pago en Cuenta Cliente";
	public static final String MENSAJE_WARNING_BUSCAR_PAGO_CUENTA_XRISK = "Fallo al buscar el Pago en la Cuenta XRisk";
	public static final String MENSAJE_WARNING_ESTA_PAGO_XRISK = "Fallo al comprobar si existe el Pago en la Cuenta XRisk";
	public static final String MENSAJE_WARNING_COMPENSAR_CASUISTICAS = "Fallo al compensar las Casuisticas";
	public static final String MENSAJE_WARNING_ASIENTO_POR_EL_PAGO = "Fallo al realizar el asiento por el pago";
	public static final String MENSAJE_WARNING_CONTABILIZAR = "Fallo al realizar la contabilizacion";
	public static final String MENSAJE_WARNING_BUSCAR_PAGO = "Fallo al buscar el Pago";
	public static final String MENSAJE_WARNING_FALLO_GENERAL = "Fallo general";
	public static final String MENSAJE_WARNING_COMPENSAR_DEUDOR_DATOS_CABECERA = "Fallo al intentar acceder al deudor(cliente)";
	public static final String MENSAJE_WARNING_COMPENSAR_DEUDOR_DATOS_CABECERA2 = "Fallo al intentar acceder al deudor(cliente)";
	public static final String MENSAJE_WARNING_COMPENSAR_DEUDOR_PROC_PAR_ABIERTAS = "Fallo al intentar buscar pagos";
	public static final String MENSAJE_WARNING_INTRODUCIR_IMPORTE_FACTURAS = "Fallo por no encontrar identificador ni por referencia ni por asignacion";
	public static final String MENSAJE_WARNING_PENDIENTE_ASIGNAR = "Fallo al introducir importe o texto cuando sin asignar mayor que 0";
	public static final String MENSAJE_WARNING_COMISIONES_BANCARIAS = "Fallo al introducir importe o texto cuando sin asignar entre 0 y menos1";
	public static final String MENSAJE_WARNING_APUNTE_CONTABLE = "Fallo al introducir importe o texto cuando sin asignar menos que -1";
	public static final String MENSAJE_WARNING_POST_IMPUTAR = "Fallo al introducir importe o texto cuando sin asignar menos que -1";
	public static final String MENSAJE_WARNING_CONTAB_ANEXAR = "Fallo al anexar el documento";
	public static final String MENSAJE_WARNING_VIS_RES_COMPENSAR = "Fallo al anyadir cme, cuenta, clvct o importe y texto";
	public static final String MENSAJE_WARNING_NO_ANEXADO = "Fallo al anexar";

	// Tras Sonar
	public static final String INBOX = "INBOX";
	public static final String TTOOES = "El TTOO es ";
	public static final String LACARPETAERAINBOX = "La carpeta era INBOX y hay que buscar el TTOO ";
	public static final String ELNUEVOTTOOBUSCADO = "El nuevo TTOO buscado es ";
	public static final String LACARPETANOERAINBOX = "La carpeta no era INBOX por lo que tenemos un TTOO válido ";
	public static final String MINUSOTROS = "otros";
	public static final String REVISARLINEANOIDENTIFICADA = "Revisar linea no identificada";
	public static final String ESPERANDOVENTANADATOSCABECERA = "Esperando ventana de datos cabecera...";
	public static final String XRISK = "XRisk";
	public static final String NOENCUENTRAELPAGO = "No encuentra el pago";
	public static final String LASOCIEDADES = "La sociedad es ";
	public static final String ELCODIGOSAPDEUDORES = "El Codigo de SAP deudor es ";
	public static final String ELCODIGOSAPACREEDORESES = "El Codigo de sap de acreedor es ";
	public static final String ELVALORDELTTOONAME = "El valor del TTOO name es ";
	public static final String SELECCIONFOTOIMPORTE = "Se selecciona la foto del importe";
	public static final String ELNUEVOIMPORTEES = "El nuevo importe es: ";
	public static final String CONCODIGO = " con codigo ";
	public static final String CONIMPORTE = " con importe ";
	public static final String ANADIDAFACTURATIPO = "Añadida factura del tipo ";
	public static final String ERFECHACONBARRAS = "\\d{2}\\/\\d{2}\\/\\d{4}";

	public final static long RETRY_XS = 1000;
	public final static long RETRY_S = 5000;
	public final static int INT_RETRY_S = 5000;
	public final static long RETRY_M = 10000;
	public final static long RETRY_L = 20000;
	public final static long RETRY_XL = 50000;
	public final static long RETRY_XXL = 120000;

	public static final String CLAVE_06 = "06";
	public static final String CLAVE_16 = "16";
	public static final String CLAVE_29 = "29";
	public static final String CLAVE_40 = "40";

	public static final String PENDIENTE_ASIGNAR = "PENDIENTE DE ASIGNAR";

	public static final String CUENTA_COMISIONES_BANC = "62600001";

	public static final String CONST_CONT_CARTASP = "contadorCartasPago = ";
	public static final String CONTINUAR = "continuar";
	public static final String FINDBY = "findById";
	public static final String TBAR0_BTN0 = "ses[0]/wnd[2]/tbar[0]/btn[0]";
	public static final String PRESS = "press";
	public static final String CODIGOS_DEU = " codigos de deudor y son: ";
	public static final String IMPORTE_INTRO = "El importe a introducir es: ";
	public static final String MAYORMAYOR = "' >> ";

}
