package com.deloitte.jidoka.lopesan.cartapago;

import java.util.ArrayList;
import java.util.List;

public class Casuistica {

	private String tipo;
	
	private List<String> valores;
	
	private String codigoClvct;
	
	private String cuenta; //acreedor o deudor
	
	private String cme;
	
	public Casuistica() {
		this.valores = new ArrayList<String>();
		
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public List<String> getValores() {
		return valores;
	}

	public void setValores(List<String> valores) {
		this.valores = valores;
	}
	
	public void addValor(String valor) {
		if(this.valores != null) {
			this.valores.add(valor);
		}
	}
	
	public String getCodigoClvct() {
		return this.codigoClvct;
	}
	
	public void setCodigoClvct(String codigoClvct) {
		this.codigoClvct = codigoClvct;
	}

	public String getCuenta() {
		return cuenta;
	}

	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	public String getCme() {
		return cme;
	}

	public void setCme(String cme) {
		this.cme = cme;
	}

	
	
}
