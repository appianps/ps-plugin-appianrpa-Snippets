package com.deloitte.jidoka.lopesan.config;

import com.deloitte.jidoka.lopesan.cartapago.Constantes;
import com.novayre.jidoka.client.api.IJidokaServer;
import com.novayre.jidoka.client.api.execution.IUsernamePassword;

public class RobotParameters {
	/**
	 * Nombre del parametro que tiene la carpeta base de los ficheros de entrada
	 */
	private static final String PATH_BASE = "PATH_BASE";
	
	private static final String CREDENCIAL_EMAILS_LOPESAN = "CREDENCIAL_EMAILS_LOPESAN";

	/**
	 * Carpeta raíz para la lectura de ficheros de entrada
	 */

	private final String pathBase;

	/**
	 * Nombre usuario de sap
	 */
//	private final String sapUsername;
	
	/**
	 * contraseña de usuario de sap
	 */
//	private final String sapPassword;
	
	/**
	 * Nombre de la cuenta de correo de lopesan compensaciones
	 */
//	private final String lopesanEmailUsername;
	
	/**
	 * Contraseña de la cuenta de correo de lopesan compensaciones
	 */
//	private final String lopesanEmailPassword;
	
//	private final boolean entornoProduccion;
	
	private final String tesseract;
	
	/////////
	private static final String MANDANTE = "MANDANTE";
	private static final String SAP_CONNECTION = "SAP_CONNECTION";
	private static final String SAP_CREDENTIALS = "SAP_CREDENTIALS";
	private final String mandante;
	private final IUsernamePassword sapCredentials;
	private final String sapConnection;
	private final String emailCredentials;


	public RobotParameters(IJidokaServer<?> server) {
		
		pathBase = server.getParameters().get(PATH_BASE);
		
		tesseract = server.getParameters().get("Tesseract");
		
//		entornoProduccion = Boolean.valueOf(server.getParameters().get("Produccion"));
		
		/////////////////
		//TODO: INSTRUCCIONES EN CONSOLA. MODIFICAR COMO EN EMPARK
		sapConnection = server.getParameters().get(SAP_CONNECTION);
		String credentials = server.getParameters().get(SAP_CREDENTIALS);
		server.info("Credenciales seleccionadas de SAP >> " + credentials);
		sapCredentials = server.getCredentials(credentials).get(0);
		
		mandante = server.getParameters().get(MANDANTE);
		
		////////////////
		
//		IUsernamePassword sapCredentials = server.getCredentials(Constantes.LOPESAN_SAP_CREDENTIALS).get(0);
//		sapUsername = sapCredentials.getUsername();
//		sapPassword = sapCredentials.getPassword();
		
		emailCredentials = server.getParameters().get(CREDENCIAL_EMAILS_LOPESAN);
		
/*		IUsernamePassword emailCredentials = server.getCredentials(Constantes.LOPESAN_MAIL_CREDENTIALS).get(0);
		lopesanEmailUsername = emailCredentials.getUsername();
		lopesanEmailPassword = emailCredentials.getPassword();*/
	}

	public String getPathBase() {
		return pathBase;
	}
	
//	public String getSapUsername() {
//		return sapUsername;
//	}
	
//	public String getSapPassword() {
//		return sapPassword;
//	}
	/*
	public String getLopesanEmailUsername() {
		return lopesanEmailUsername;
	}
	
	public String getLopesanEmailPassword() {
		return lopesanEmailPassword;
	}
	*/
//	public boolean getEntornoProduccion() {
//		return entornoProduccion;
//	}
	
	public String getTesseract() {
		return tesseract;
	}

	/////////////////////////////////
	/**
	 * @return the mandante
	 */
	public String getMandante() {
		return mandante;
	}

	/**
	 * @return the sapCredentials
	 */
	public IUsernamePassword getSapCredentials() {
		return sapCredentials;
	}


	/**
	 * @return the emailCredentials
	 */
	public String getEmailCredentials() {
		return emailCredentials;
	}

	/**
	 * @return the sapConnection
	 */
	public String getSapConnection() {
		return sapConnection;
	}
	
	
	

}
