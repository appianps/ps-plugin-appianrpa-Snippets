package com.deloitte.jidoka.lopesan.config;

import java.io.IOException;
import java.nio.file.Path;

import com.novayre.jidoka.falcon.api.IFalcon;
import com.novayre.jidoka.falcon.api.IFalconImage;

public class FalconSources {
	
	private final IFalconImage pantallaCompensarDeudor;
	private final IFalconImage busquedaPagoFallida;
	private final IFalconImage partidasPorElResto;
	private final IFalconImage pagoParcial;
	private final IFalconImage botonMarcarTodo;
	private final IFalconImage marcarPartidas;
	private final IFalconImage desmarcarPartidas;
	private final IFalconImage unaBusqueda;
	private final IFalconImage unaBusquedaDos;
	private final IFalconImage importeSap;
	private final IFalconImage importeSinAsignar;
	private final IFalconImage contabilizadoCorrecto;
	private final IFalconImage ventanaDocumento;
	private final IFalconImage servicesForObject;
	private final IFalconImage filter;
	private final IFalconImage unaPartida;
	private final IFalconImage popupBusqueda;
	private final IFalconImage buscarImporte;
	private final IFalconImage ventanaCompensarDeudor;
	private final IFalconImage imagenPorFavor;
	private final IFalconImage buscarAsignacion;
	private final IFalconImage imagenAsignacion;
	private final IFalconImage botonClasificacionAscendente;
	private final IFalconImage imagenReferencia;
	private final IFalconImage imagenReferenciaDos;
	private final IFalconImage botonClasificacionDescendente;
	private final IFalconImage imagenImpuestos;
	
	private static final String EXTENSION_PNG 	= ".png";
	private static final String NOMBRE_IMAGEN_PANTALLA_COMPENSAR_DEUDOR 	= "pantallaCompensarDeudor";
	private static final String NOMBRE_IMAGEN_BUSQUEDA_PAGO_FALLIDO			= "busquedaPagoFallida";
	private static final String NOMBRE_IMAGEN_PARTIDAS_POR_EL_RESTO			= "partidasPorElResto";
	private static final String NOMBRE_IMAGEN_PAGO_PACIAL					= "pagoParcial";
	private static final String NOMBRE_IMAGEN_MARCAR_TODO					= "botonMarcarTodo";
	private static final String NOMBRE_IMAGEN_MARCAR_PARTIDAS				= "marcarPartidas";
	private static final String NOMBRE_IMAGEN_DESMARCAR_PARTIDAS			= "desmarcarPartidas";
	private static final String NOMBRE_IMAGEN_UNA_BUSQUEDA					= "unaBusqueda";
	private static final String NOMBRE_IMAGEN_IMPORTE_SAP					= "importeSap";
	private static final String NOMBRE_IMAGEN_IMPORTE_SIN_ASIGNAR			= "importeSinAsignar";
	private static final String NOMBRE_IMAGEN_UNA_BUSQUEDA_DOS				= "unaBusquedaDos";
	private static final String NOMBRE_IMAGEN_CONTABILIZADO_CORRECTO		= "contabilizadoCorrecto";
	private static final String NOMBRE_IMAGEN_VENTANA_DOCUMENTO				= "ventanaDocumento";
	private static final String NOMBRE_IMAGEN_SERVICES_FOR_OBJECT			= "servicesForObject";
	private static final String NOMBRE_IMAGEN_FILTER						= "filter";
	private static final String NOMBRE_IMAGEN_UNA_PARTIDA					= "unaPartida";
	private static final String NOMBRE_IMAGEN_POPUPBUSQUEDA					= "popupBusqueda";
	private static final String NOMBRE_IMAGEN_BUSCARIMPORTE					= "buscarImporte";
	private static final String NOMBRE_IMAGEN_VENTANA_COMPENSAR_DEUDOR		= "ventanaCompensarDeudor";
	private static final String NOMBRE_IMAGEN_POR_FAVOR						= "imagenPorFavor";
	private static final String NOMBRE_IMAGEN_BUSCAR_ASIGNACION				= "buscarAsignacion";
	private static final String NOMBRE_IMAGEN_ASIGNACION 					= "imagenAsignacion";
	private static final String NOMBRE_IMAGEN_BOTON_CLASIFICACION_ASCENDENTE= "botonClasificacionAscendente";
	private static final String NOMBRE_IMAGEN_REFERENCIA					= "imagenReferencia";
	private static final String NOMBRE_IMAGEN_REFERENCIA_DOS				= "imagenReferenciaDos";
	private static final String NOMBRE_IMAGEN_BOTON_CLASIFICACION_DESCENDENTE	= "botonClasificacionDescendente";
	private static final String NOMBRE_IMAGEN_IMPUESTOS						= "imagenImpuestos";
	
	public FalconSources(IFalcon falcon,Path imagenes) throws IOException {
		float tolerance = 0.05f;
		
		
		pantallaCompensarDeudor = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_PANTALLA_COMPENSAR_DEUDOR+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_PANTALLA_COMPENSAR_DEUDOR);
		busquedaPagoFallida = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_BUSQUEDA_PAGO_FALLIDO+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_BUSQUEDA_PAGO_FALLIDO);
		partidasPorElResto = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_PARTIDAS_POR_EL_RESTO+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_PARTIDAS_POR_EL_RESTO);
		pagoParcial = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_PAGO_PACIAL+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_PAGO_PACIAL);
		botonMarcarTodo = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_MARCAR_TODO+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_MARCAR_TODO);
		marcarPartidas = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_MARCAR_PARTIDAS+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_MARCAR_PARTIDAS);
		desmarcarPartidas = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_DESMARCAR_PARTIDAS+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_DESMARCAR_PARTIDAS);
		unaBusqueda = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_UNA_BUSQUEDA+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_UNA_BUSQUEDA);
		importeSap = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_IMPORTE_SAP+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_IMPORTE_SAP);
		importeSinAsignar = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_IMPORTE_SIN_ASIGNAR+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_IMPORTE_SIN_ASIGNAR);
		unaBusquedaDos = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_UNA_BUSQUEDA_DOS+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_UNA_BUSQUEDA_DOS);
		contabilizadoCorrecto = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_CONTABILIZADO_CORRECTO+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_CONTABILIZADO_CORRECTO);
		ventanaDocumento = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_VENTANA_DOCUMENTO+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_VENTANA_DOCUMENTO);
		servicesForObject = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_SERVICES_FOR_OBJECT+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_SERVICES_FOR_OBJECT);
		filter = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_FILTER+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_FILTER);
		unaPartida = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_UNA_PARTIDA+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_UNA_PARTIDA);
		popupBusqueda = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_POPUPBUSQUEDA+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_POPUPBUSQUEDA);
		buscarImporte = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_BUSCARIMPORTE+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_BUSCARIMPORTE);
		ventanaCompensarDeudor = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_VENTANA_COMPENSAR_DEUDOR+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_VENTANA_COMPENSAR_DEUDOR);
		imagenPorFavor = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_POR_FAVOR+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_POR_FAVOR);
		buscarAsignacion = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_BUSCAR_ASIGNACION+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_BUSCAR_ASIGNACION);
		imagenAsignacion = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_ASIGNACION+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_ASIGNACION);
		botonClasificacionAscendente = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_BOTON_CLASIFICACION_ASCENDENTE+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_BOTON_CLASIFICACION_ASCENDENTE);
		imagenReferencia = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_REFERENCIA+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_REFERENCIA);
		imagenReferenciaDos = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_REFERENCIA_DOS+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_REFERENCIA_DOS);
		botonClasificacionDescendente = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_BOTON_CLASIFICACION_DESCENDENTE+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_BOTON_CLASIFICACION_DESCENDENTE);
		imagenImpuestos = falcon.getImage(imagenes.resolve(NOMBRE_IMAGEN_IMPUESTOS+EXTENSION_PNG).toFile(),tolerance, NOMBRE_IMAGEN_IMPUESTOS);
	}
	
	public IFalconImage getCompensarDeudor() {
		return this.pantallaCompensarDeudor;
	}
	
	public IFalconImage getBusquedaPagoFallida() {
		return this.busquedaPagoFallida;
	}
	
	public IFalconImage getPartidasPorElResto() {
		return this.partidasPorElResto;
	}
	
	public IFalconImage getPagoParcial() {
		return this.pagoParcial;
	}
	
	public IFalconImage getMarcarTodo() {
		return this.botonMarcarTodo;
	}
	
	public IFalconImage getMarcarPartidas() {
		return this.marcarPartidas;
	}
	
	public IFalconImage getDesmarcarPartidas() {
		return this.desmarcarPartidas;
	}
	
	public IFalconImage getUnaBusqueda() {
		return this.unaBusqueda;
	}
	
	public IFalconImage getImporteSap() {
		return this.importeSap;
	}
	
	public IFalconImage getImporteSinAsignar() {
		return this.importeSinAsignar;
	}
	
	public IFalconImage getUnaBusquedaDos() {
		return this.unaBusquedaDos;
	}
	
	public IFalconImage getContabilizadoCorrecto() {
		return this.contabilizadoCorrecto;
	}
	
	public IFalconImage getVentanaDocumento() {
		return this.ventanaDocumento;
	}

	public IFalconImage getServicesForObject() {
		return this.servicesForObject;
	}
	
	public IFalconImage getFilter() {
		return this.filter;
	}
	
	public IFalconImage getUnaPartida() {
		return this.unaPartida;
	}
	
	public IFalconImage getPopupBusqueda() {
		return this.popupBusqueda;
	}
	
	public IFalconImage getBuscarImporte() {
		return this.buscarImporte;
	}
	
	public IFalconImage getVentanaCompensarDeudor() {
		return this.ventanaCompensarDeudor;
	}
	
	public IFalconImage getImagenPorFavor() {
		return this.imagenPorFavor;
	}
	
	public IFalconImage getBuscarAsignacion() {
		return this.buscarAsignacion;
	}
	
	public IFalconImage getImagenAsignacion() {
		return this.imagenAsignacion;
	}
	
	public IFalconImage getBotonClasificacionAscendente() {
		return this.botonClasificacionAscendente;
	}
	
	public IFalconImage getImagenReferencia() {
		return this.imagenReferencia;
	}
	
	public IFalconImage getImagenReferenciaDos() {
		return this.imagenReferenciaDos;
	}
	
	public IFalconImage getBotonClasificacionDescendente() {
		return this.botonClasificacionDescendente;
	}
	
	public IFalconImage getImagenImpuestos() {
		return this.imagenImpuestos;
	}
}
