package com.deloitte.jidoka.ttoo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.deloitte.jidoka.lopesan.cartapago.CartaPago;
import com.deloitte.jidoka.lopesan.cartapago.Casuistica;
import com.deloitte.jidoka.lopesan.cartapago.Constantes;
import com.deloitte.jidoka.lopesan.cartapago.Factura;
import com.deloitte.jidoka.lopesan.config.CeldasUtils;
import com.novayre.jidoka.client.api.IJidokaServer;

public class Generico extends Touroperador {

	
	public Generico(IJidokaServer<?> server,String sociedad, List<String> codigosDeudor, String ttooCuentaAcreedor, String ttooName, String nombreFichero,
			HashMap<String, Double> sumatorios)  {
		super(server, sociedad, codigosDeudor, ttooCuentaAcreedor, ttooName, nombreFichero, sumatorios);
	}

	@Override
	public CartaPago procesarCartaPagoPDF(String text, List<Casuistica> listaCasuisticas) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CartaPago procesarCartaPagoWord(String text, List<Casuistica> listaCasuisticas) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CartaPago procesarCartaPagoExcel(String text, List<Casuistica> listaCasuisticas) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CartaPago procesarCartaPagoGenerica(String rutaFichero, List<Casuistica> listaCasuisticas) {
		CartaPago cartaGenerica = new CartaPago();
		server.info("Entramos en Lectura Excel");
		try( FileInputStream excelXML = new FileInputStream(new File(rutaFichero)); Workbook wb = WorkbookFactory.create(excelXML);){
			
			if(wb != null) {
				Sheet hoja = wb.getSheetAt(0);
				String fecha="";
				String k = hoja.toString();
				String nombrehoja = hoja.getSheetName();
				server.info(k);
				server.info("El nombre de la hoja es: " + nombrehoja);
				
				//Primero obtenemos la fecha
				fecha=getValorUnitario(hoja.getRow(3).getCell(1));//.replaceAll("\\\\", ".");ç
				server.info("La fecha pre-mach " + fecha);
				if (fecha.matches("\\d{2}\\.\\d{2}\\.(\\d{4}|\\d{2})")) {
					cartaGenerica.setFecha(fecha); 
					server.info("La fecha es: "+cartaGenerica.getFecha());					
				}else {
					cartaGenerica.setFecha(super.getFecha());
				}
				//Segudo, obtenemos el codigo de la sociedad
				cartaGenerica.setSociedad(getValorUnitario(hoja.getRow(4).getCell(1)));
				server.info("La sociedad es: "+cartaGenerica.getSociedad());
				//Tercero, obtener la lista de codigos de deudor de sap
				cartaGenerica.setTtooDeudor(getValorLista(hoja.getRow(5).getCell(1),";"));
				server.info("El TTOO Deudor es: "+cartaGenerica.getTtooDeudor());
				//Cuarto, obenter el codigo del acreedor
				cartaGenerica.setTtooAcreedor(getValorUnitario(hoja.getRow(6).getCell(1)));
				server.info("El TTOO Acreedor es: "+cartaGenerica.getTtooAcreedor());
				
				if (cartaGenerica.getSociedad().equals("") || cartaGenerica.getTtooAcreedor()==null || cartaGenerica.getTtooDeudor().size()==0) {
					server.error("Faltan datos en los campos 'Sociedad SAP', 'Códigos deudor' y/o 'Códigos Acreedor' de la carta de pago generica.");
					return null;
				}
				
				String controlFinal = "";
				int iteracion =10;
				while(!controlFinal.equalsIgnoreCase("Total carta de pago")) {
					Row row = hoja.getRow(iteracion);
					CeldasUtils celdasUtils = new CeldasUtils();
					if(row != null) {
						controlFinal = celdasUtils.valorCelda(row.getCell(2));
						String referenciaControl = getValorUnitario(row.getCell(0)).trim();
						String descripcionControl = getValorUnitario(row.getCell(1)).trim();
						String tipoControl = getValorUnitario(row.getCell(2));
						String importeControl = getValorUnitario(row.getCell(3));
						server.info("Leida la linea " + row.getRowNum() + " con Referencia: " + referenciaControl +
								" con Descripcion: " + descripcionControl + " con tipo: " + tipoControl + " con importe: " + importeControl);
						
						if(controlFinal.equalsIgnoreCase("Total carta de pago")) {
							String total = celdasUtils.valorCelda(row.getCell(3)).replaceAll("SUM=", "");
							total = total.replaceAll("-", "");
							
							total = total.replaceAll("\\.", "");
							total = total.replaceAll(",", ".");
							cartaGenerica.setImporte(total);
							server.info("El total es: "+total);
						}else if(!importeControl.equalsIgnoreCase("") || !descripcionControl.equalsIgnoreCase("")) 
						{
							boolean facturaExiste=false;
							if (forzadoDeTipo(getValorUnitario(row.getCell(2))).equalsIgnoreCase(Constantes.FACTURA)) {
								importeControl = importeControl.replaceAll("SUM=", "");
								importeControl = importeControl.replace("-", "");
								server.info("El importe corregido de la factura es: " + importeControl);
								Double resultado = null;
								for (Factura factura:cartaGenerica.getFacturas()) {
	    							if (getValorUnitario(row.getCell(0)).equalsIgnoreCase((factura.getIdentificador()))){
	    								aumentarSaldoFacturas(forzadoDeTipo(tipoControl),importeControl);
	    								resultado=Double.sum(stringToNumber(factura.getImporte()),stringToNumber(importeControl));
	    								factura.setImporte(String.format("%.2f",resultado));
	    								server.info("Actualizada la factura del tipo " + factura.getTipo() + " con codigo " + factura.getIdentificador() + " con importe " + factura.getImporte());
	    								facturaExiste=true;
	    								break;
	    							}
	    						}
							}
							if(!facturaExiste){
								Factura factura = getFactura(row);
								cartaGenerica.addFactura(factura);
							}					
						}else {
							server.info("Linea " + iteracion + " con valor 0");
						}							
					}
					iteracion++;
					
				}
				
				cartaGenerica.setSumatorios(sumatorios);
				cartaGenerica.setNombreDocumento(getNombreFichero());
				cartaGenerica.setNombreTuroperador(getTouroperadorName());
				cartaGenerica.setOtros(calcularOtros(Constantes.GENERICO,cartaGenerica.getImporte().replaceAll("SUM=", ""), listaCasuisticas, cartaGenerica.getSaldosDeposito()));

				wb.close();
			}
		} catch (FileNotFoundException e) {
			server.error(e);
		} catch (IOException e) {
			server.error(e);
		} catch (EncryptedDocumentException e) {
			server.error(e);
		}
		return cartaGenerica;
	}
	
	private String getValorUnitario(Cell cell) {
		CeldasUtils celdasUtils = new CeldasUtils();
//		server.info("La celda con columna " + cell.getColumnIndex());
//		server.info("Con finla "+ cell.getRowIndex());
//		server.info("Con tipo " + cell.getCellType());
//		server.info("y con dataformat" + cell.getCellStyle().getDataFormat());
		return celdasUtils.valorCelda(cell);
	}
	
	private List<String> getValorLista(Cell cell, String splitter) {
		server.info("Inicia get Valor Lista");
		List<String> listaDeudores = new ArrayList<String>();
		CeldasUtils celdasUtils = new CeldasUtils();
//		server.info("La celda con columna " + cell.getColumnIndex());
//		server.info("Con finla "+ cell.getRowIndex());
//		server.info("Con tipo " + cell.getCellType());
//		server.info("y con dataformat" + cell.getCellStyle().getDataFormat());
		String lista = celdasUtils.valorCelda(cell);
		String[] split = lista.split(splitter);
		for(String k : split) {
			if (!k.equalsIgnoreCase(""))
				k = k.replace("SUM=", "");
				listaDeudores.add(k);
		}
		return listaDeudores;
	}
	
	private Factura getFactura(Row row) {
		CeldasUtils celdasUtils = new CeldasUtils();
		String tipo = celdasUtils.valorCelda(row.getCell(2));
		tipo = tipo.replaceAll("SUM=", "");
		
		String identificador = celdasUtils.valorCelda(row.getCell(0));
		identificador = identificador.replaceAll("SUM=", "");
		
		String importe = celdasUtils.valorCelda(row.getCell(3));
		importe = importe.replaceAll("SUM=", "");
		importe = importe.replace("-", "");
		
		String descripcion = celdasUtils.valorCelda(row.getCell(1));
		descripcion = descripcion.replaceAll("SUM=", "");
		
		//Vamos a hacer un control, el texto de este tipo, lo meten usuarios a mano, aunque venga en un layout puede ser un poco distinto
		// y no coincidir con el texto de tipo del excel maestro de compensaciones, por lo que vamos a forzar que el tipo se una de 
		//las constastes que tenemos prediseñadas
		tipo = forzadoDeTipo(tipo);
		server.info("Añadida la factura del tipo " + tipo + " con codigo " + identificador + " con importe " + importe);
		aumentarSaldoFacturas(tipo,importe);
		Factura factura = new Factura(tipo,identificador,importe,descripcion);
		
		return factura;
	}
	
	private Double stringToNumber(String valor) {
		String regexComa = "(-|)\\d+(\\,\\d+)?";
		if(valor.matches(regexComa)) {
			valor = valor.replace(",", ".");
		}
		if(valor.contains("-")) {
			valor = valor.replace("-", "");
			return Double.valueOf(valor)*(-1);
		}else {
			return Double.valueOf(valor);
		}
	}
	
	private String forzadoDeTipo(String tipo) {
		
		tipo = tipo.toLowerCase();
		
		if(tipo.contains("factura")) {
			return Constantes.FACTURA;
		}
		if(tipo.contains("abono")) {
			return Constantes.ABONODESCONTADO;
		}
		if(tipo.contains("pago de menos") || tipo.contains("de menos")) {
			return Constantes.PAGODEMENOS;
		}
		if(tipo.contains("pago de mas") || tipo.contains("de mas")) {
			return Constantes.PAGODEMAS;
		}
		if(tipo.contains("deduccion contrato") || tipo.contains("deduccion") || tipo.contains("catalogo")) {
			return Constantes.DEDUCCION;
		}
		if(tipo.contains("pre pagos")) {
			return Constantes.PREPAGO;
		}
		return "";
		
		//TODO, añadir el la casuistica del pago de diferencias pq seguramente sea restar de una factura enterior
	}

}
