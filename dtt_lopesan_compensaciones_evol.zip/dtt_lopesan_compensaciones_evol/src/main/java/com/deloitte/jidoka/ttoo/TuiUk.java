package com.deloitte.jidoka.ttoo;

import java.util.HashMap;
import java.util.List;
import com.deloitte.jidoka.lopesan.cartapago.CartaPago;
import com.deloitte.jidoka.lopesan.cartapago.Casuistica;
import com.deloitte.jidoka.lopesan.cartapago.Constantes;
import com.deloitte.jidoka.lopesan.cartapago.Factura;
import com.novayre.jidoka.client.api.IJidokaServer;

public class TuiUk extends Touroperador {

	
	public TuiUk(IJidokaServer<?> server,String sociedad, List<String> codigosDeudor, String ttooCuentaAcreedor, String ttooName, String nombreFichero,
			HashMap<String, Double> sumatorios)  {
		super(server, sociedad, codigosDeudor, ttooCuentaAcreedor, ttooName, nombreFichero, sumatorios);
	}

	
	
	public CartaPago procesarCartaPagoPDF(String text, List<Casuistica> listaCasuisticas) {
		
		CartaPago cartaTuiUk = new CartaPago();
		String [] ings= text.split("\r");
		String fecha="";
        server.info("Numero de lineas del pdf: " +ings.length);	
        for (String linea: ings) {
        	linea = linea.replaceAll("\n", "");
        	String[] split = linea.split(" ");
        	String importe="";
        	String identificador="";
        	for(Casuistica casuistica : listaCasuisticas) {
        		//Aqui tendriamos el tipo de casuistica y la lista de string que hay que buscar
        		String tipo = casuistica.getTipo();
        		List<String> casos = casuistica.getValores();
        		for(String caso : casos) {
        			if(linea.contains(caso) && split.length >20 && !caso.equalsIgnoreCase("-")) {
                		//Aqui desde antes hemos asegurado que el tipo sea una constante de las ya determinadas
        				//los pagos pueden estar en posiciones 21,25, 27 y 28 
        				importe=split[split.length-1];
        				identificador=split[0];
        				boolean facturaExiste=false;
    					if (tipo.equalsIgnoreCase(Constantes.FACTURA)){
    						identificador=getMatch("\\d+[\\/]\\w{3}\\d{2}",identificador);
    						Double resultado = null;
							for (Factura factura:cartaTuiUk.getFacturas()) {
    							if (identificador.equals(factura.getIdentificador())){
    								aumentarSaldoFacturas(tipo,importe);
    								resultado=Double.sum(stringToNumber(factura.getImporte()),stringToNumber(importe));
    								factura.setImporte(String.format("%.2f",resultado));
    								server.info("Actualizada la factura del tipo " + tipo + " con codigo " + identificador + " con importe " + factura.getImporte());
    								facturaExiste=true;
    								break;
    							}
    						}
    					}
    					if(!facturaExiste){	        						
    						aumentarSaldoFacturas(tipo,importe);
    						//Para TUI UK la descripcion es el mismo que el identificador
    						Factura factura = new Factura(tipo,identificador,importe, identificador);
    						cartaTuiUk.addFactura(factura);       
    						server.info("Añadida la factura del tipo " + tipo + " con codigo " + identificador + " con importe " + importe);
    					}              		
        			}
        		}
        	}
        	if(linea.trim().matches("\\d{1,2}\\.\\d{1,2}\\.\\d{4}")) {
        		fecha=linea;
        		System.out.println("La fecha es: "+fecha);
        	}
        	if(linea.contains("Total") ) {
        		String importeTotal = split[split.length-1];
				System.out.println("Importe total: "+importeTotal);
				cartaTuiUk.setImporte(importeTotal);
        	}
        } 
        sumatorios.forEach((k,v) -> server.info("Key: " + k + ": Value: " + v));
        cartaTuiUk.setSumatorios(sumatorios);
        cartaTuiUk.setSociedad(getSociedad());
        cartaTuiUk.setTtooDeudor(super.getTtooCuentaDeudor());
        cartaTuiUk.setTtooAcreedor(super.getTtooCuentaAcreedor());
        cartaTuiUk.setNombreTuroperador(getTouroperadorName());
        cartaTuiUk.setNombreDocumento(getNombreFichero());
        if(!fecha.equalsIgnoreCase("")) {
        	cartaTuiUk.setFecha(fecha);
        }
        else {
        	cartaTuiUk.setFecha(super.getFecha());
        }
        cartaTuiUk.setOtros(calcularOtros(Constantes.TUI_UK,cartaTuiUk.getImporte(), listaCasuisticas,cartaTuiUk.getSaldosDeposito()));
        return cartaTuiUk;
	}

	private Double stringToNumber(String valor) {
		String regexMilComa = "\\d{1,3}(,\\d{3})*(\\.\\d+)(-|)?";
		String regexMilPunto = "\\d{1,3}(.\\d{3})*(\\,\\d+)(-|)?";
		String regexComa = "\\d+(\\,\\d+)(-|)?";
		if(valor.matches(regexMilComa)) {
			valor = valor.replace(",","");
		}else if(valor.matches(regexMilPunto)) {
			valor = valor.replace(".", "");
			valor = valor.replace(",", ".");
		}else if(valor.matches(regexComa)) {
			valor = valor.replace(",", ".");
		}
		if(valor.contains("-")) {
			valor = valor.replace("-", "");
			return Double.valueOf(valor)*(-1);
		}else {
			return Double.valueOf(valor);
		}
	}

	@Override
	public CartaPago procesarCartaPagoWord(String text, List<Casuistica> listaCasuisticas) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public CartaPago procesarCartaPagoExcel(String text, List<Casuistica> listaCasuisticas) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public CartaPago procesarCartaPagoGenerica(String rutaFichero, List<Casuistica> listaCasuisticas) {
		// TODO Auto-generated method stub
		return null;
	}
}
