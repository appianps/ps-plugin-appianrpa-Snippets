package com.deloitte.jidoka.ttoo;

import java.util.HashMap;
import java.util.List;

import com.deloitte.jidoka.lopesan.cartapago.CartaPago;
import com.deloitte.jidoka.lopesan.cartapago.Casuistica;
import com.deloitte.jidoka.lopesan.cartapago.Constantes;
import com.deloitte.jidoka.lopesan.cartapago.Factura;
import com.novayre.jidoka.client.api.IJidokaServer;

public class TuiNetherland extends Touroperador {

	public TuiNetherland(IJidokaServer<?> server, String sociedad, List<String> codigosDeudor, String ttooCuentaAcreedor, String ttooName, String nombreFichero,
			HashMap<String, Double> sumatorios)  {
		super(server, sociedad, codigosDeudor, ttooCuentaAcreedor, ttooName, nombreFichero, sumatorios);
	}


	@Override
	public CartaPago procesarCartaPagoPDF(String text, List<Casuistica> listaCasuisticas) {

		server.info("Entra en Procesar Carta Pago");
		CartaPago tuiNetherland = new CartaPago();
		String [] ings = text.split("\r");
        server.info("Numero de lineas del pdf: " +ings.length);
        String fecha="";
        boolean contieneFecha;
		boolean contieneImporte;
		boolean casoEncontrado;
        for (String linea: ings) {
        	linea = linea.replaceAll("\n", "");
        	String[] split = linea.split(" ");
        	String identificador="";
        	String descripcion="";
        	String importe="";
        	contieneFecha=false;
    		contieneImporte=false;
        	for(String part:split) {
        		if (part.matches("\\d{1,2}-\\d{1,2}-\\d{4}")) {
        			contieneFecha=true;
        		}else if(part.matches("(-|)\\d{1,3}(\\.\\d{3})*(\\,\\d{2})+")) {
        			importe=part;
        			contieneImporte=true;
        		}
        	}
        	casoEncontrado = false;
        	if (contieneImporte && !linea.contains("TOTAL")) {
        		server.info("Contiene importe la linea: " + linea);
        		if(contieneFecha) {
        			for (int i=0; i<split.length; i++) {
            			if (!split[i].isEmpty() && i>0) {
            				identificador=split[i];
            				if (!split[i+1].trim().equals("-")) {        					
            					descripcion=split[i+1];
            				}else {
            					descripcion=identificador;
            				}
            				break;
            			}
            		}     
        		}else {
        			for (int i=0; i<split.length; i++) {
            			if (!split[i].isEmpty()) {
            				identificador=split[i];
            				if (!split[i+1].trim().equals("-")) {        					
            					descripcion=split[i+1];
            				}else {
            					descripcion=identificador;
            				}
            				break;
            			}
            		}     
        		}
        		  	
        		for(Casuistica casuistica : listaCasuisticas) {
	            	//Casuistica casuistica = new Casuistica();
	        		//Aqui tendriamos el tipo de casuistica y la lista de string que hay que buscar
	        		String tipo = casuistica.getTipo();
	        		
	        		List<String> casos = casuistica.getValores();
	        		for(String caso : casos) {
	        			if(linea.contains(caso) && split.length  >= 3 && linea.contains(",") && !caso.equalsIgnoreCase("-")) {
	        				if ((tipo.equalsIgnoreCase(Constantes.FACTURA) || tipo.equalsIgnoreCase(Constantes.ABONODESCONTADO)) && !identificador.trim().matches("\\d+\\/\\w{3}\\d{2}")) {
	        					casoEncontrado = false;
	        				}else {	        					
	        					boolean facturaExiste=false;
	        					if (tipo.equalsIgnoreCase(Constantes.FACTURA)){
	        						Double resultado = null;
        							for (Factura factura:tuiNetherland.getFacturas()) {
    	    							if (identificador.equals(factura.getIdentificador())){
    	    								aumentarSaldoFacturas(tipo,importe);
    	    								resultado=Double.sum(stringToNumber(factura.getImporte()),stringToNumber(importe));
    	    								factura.setImporte(String.format("%.2f",resultado));
    	    								server.info("Actualizada la factura del tipo " + tipo + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + factura.getImporte());
    	    								facturaExiste=true;
    	    								break;
    	    							}
    	    						}
	        					}
	        					if(!facturaExiste){	        						
	        						aumentarSaldoFacturas(tipo,importe);
	        						//En Tui Nederland esta la descripcion al lado del identificador
	        						Factura factura = new Factura(tipo,identificador,importe,descripcion);
	        						tuiNetherland.addFactura(factura);       
	        						server.info(Constantes.ANADIDAFACTURATIPO + tipo + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + importe);
	        					}
	        					casoEncontrado = true;
	        				}
	        			}
	
	        		}
	        	}
	        	if(!casoEncontrado && split.length>=2) {
	        		if (importe.contains("-")) {	        			
	        			aumentarSaldoFacturas(Constantes.PAGODEMENOS, importe);
	        			Factura factura = new Factura(Constantes.PAGODEMENOS,identificador,importe.replace("-", ""),descripcion);
	        			server.info(Constantes.ANADIDAFACTURATIPO + Constantes.PAGODEMENOS + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + importe );
	        			tuiNetherland.addFactura(factura);
	        		}else {
	        			aumentarSaldoFacturas(Constantes.PAGODEMAS, importe);
	        			Factura factura = new Factura(Constantes.PAGODEMAS,identificador,importe.replace("-", ""),descripcion);
	        			server.info(Constantes.ANADIDAFACTURATIPO + Constantes.PAGODEMAS + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + importe );
	        			tuiNetherland.addFactura(factura);
	        		}
				}
        	}
        	if(linea.contains("TOTAL") ) {
        		String importeTotal = split[split.length-1].replace(".", "");
        		importeTotal = importeTotal.replace(",", ".");
        		server.info("Importe Total: "+importeTotal);
        		tuiNetherland.setImporte(importeTotal);
        	}
        	if(linea.contains("DATE") && linea.contains("SUPPLIER") && split[split.length-1].matches("\\d{1,2}-\\d{1,2}-\\d{4}")) {
        		fecha=split[split.length-1].replaceAll("-", ".");
        		server.info("La fecha es: "+fecha);
        	}
        }
        
		
        
        sumatorios.forEach((k,v) -> server.info("Key: " + k + ": Value: " + v));
        tuiNetherland.setSumatorios(sumatorios);
        tuiNetherland.setSociedad(getSociedad());
        tuiNetherland.setTtooDeudor(super.getTtooCuentaDeudor());
        tuiNetherland.setTtooAcreedor(super.getTtooCuentaAcreedor());
        tuiNetherland.setNombreTuroperador(getTouroperadorName());
        tuiNetherland.setNombreDocumento(getNombreFichero());
        if(!fecha.equalsIgnoreCase("")) {
        	tuiNetherland.setFecha(fecha);
        }
        else {
        	tuiNetherland.setFecha(super.getFecha());
        } 
        tuiNetherland.setOtros(calcularOtros(Constantes.TUINETHERLAND,tuiNetherland.getImporte(), listaCasuisticas, tuiNetherland.getSaldosDeposito()));
        return tuiNetherland;
		
	}

	private Double stringToNumber(String valor) {
		String regexMilComa = "(-|)\\d{1,3}(,\\d{3})*(\\.\\d+)?";
		String regexMilPunto = "(-|)\\d{1,3}(.\\d{3})*(\\,\\d+)?";
		String regexComa = "(-|)\\d+(\\,\\d+)?";
		if(valor.matches(regexMilComa)) {
			valor = valor.replace(",","");
		}else if(valor.matches(regexMilPunto)) {
			valor = valor.replace(".", "");
			valor = valor.replace(",", ".");
		}else if(valor.matches(regexComa)) {
			valor = valor.replace(",", ".");
		}
		if(valor.contains("-")) {
			valor = valor.replace("-", "");
			return Double.valueOf(valor)*(-1);
		}else {
			return Double.valueOf(valor);
		}
	}
	
	@Override
	public CartaPago procesarCartaPagoWord(String text, List<Casuistica> listaCasuisticas) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CartaPago procesarCartaPagoExcel(String text, List<Casuistica> listaCasuisticas) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public CartaPago procesarCartaPagoGenerica(String rutaFichero, List<Casuistica> listaCasuisticas) {
		// TODO Auto-generated method stub
		return null;
	}

}
