package com.deloitte.jidoka.lopesan.cartapago;

public class Factura {
	
	//Los tipos solo pueden ser "Factura", "Descuentos", "Catalogo" "Garantias" "Comisiones", "PagoMas"
	private String tipo;
	
	private String identificador;
	
	private String importe;
	
	private String descripcion;
	
	public Factura(String tipo, String identificador, String importe, String descripcion) {
		this.tipo = tipo;
		this.identificador = identificador;
		this.importe = importe;
		this.descripcion= descripcion;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getIdentificador() {
		return identificador;
	}

	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}

	public String getImporte() {
		return importe;
	}

	public void setImporte(String importe) {
		this.importe = importe;
	}
	
	public String getDescripciom() {
		return this.descripcion;
	}
	
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	
	

}
