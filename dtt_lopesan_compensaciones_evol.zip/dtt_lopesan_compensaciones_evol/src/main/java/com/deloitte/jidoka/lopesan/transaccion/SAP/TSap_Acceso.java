package com.deloitte.jidoka.lopesan.transaccion.SAP;


//TODO: Mover transaccion a robot maestro cuando se arreglen las ramas de EMPARK

/**
 * The Enum ESapTransaction.
 */
public class TSap_Acceso {
	
	/** <b>Type: </b> GuiTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
	public static final String MANDANTE = "txtRSYST-MANDT";

}
