package com.deloitte.jidoka.lopesan.exceldrive;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.deloitte.jidoka.lopesan.cartapago.CartaPago;
import com.deloitte.jidoka.lopesan.cartapago.Casuistica;
import com.deloitte.jidoka.lopesan.cartapago.Constantes;
import com.deloitte.jidoka.lopesan.exceptions.SystemException;
import com.deloitte.jidoka.lopesan.gmail.LopesanMail;
import com.deloitte.lopesan.googledrive.SheetsServiceUtil;
import com.deloitte.lopesan.googledrive.SheetsUtils;
import com.google.api.client.googleapis.json.GoogleJsonError;
import com.google.api.client.googleapis.json.GoogleJsonError.ErrorInfo;
import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.services.sheets.v4.Sheets;
import com.novayre.jidoka.client.api.IJidokaServer;

public class ExcelDrive {
	
	
	protected IJidokaServer<?> server;
	Sheets sheetsService;
	private Rangos rangos;
	
	public ExcelDrive(IJidokaServer<?> server) throws SystemException {
		this.server = server;
		this.sheetsService = SheetsServiceUtil.getSheetsService();
		rangos = new Rangos(server, this.sheetsService);
		server.info("Servicio de google Sheets instanciado correctamente");
	}
	
	/*********************************
	 * 
	 * 
	 * 				PRUEBAS DE RANGOS
	 * @throws SystemException 
	 * 
	 * 
	 ********************************/
	public void getRangos() throws SystemException {
		server.debug("rangoTTOO");
		String rangoTTOO = rangos.getRangoTTOO();
		server.info("rangosTTOO Pestanya TTOO: " + rangoTTOO);
		
		server.debug("rangoNombreTTOO");
		String rangoNombreTTOO = rangos.getRangoNombreTTOO();
		server.info("rangosNombreTTOO Pestanya TTOO: " + rangoNombreTTOO);
		
		server.debug("rangoRangoSociedadesCodFRAyAbono");
		String rangoSociedadesCodFRAyAbono = rangos.getRangoSociedadesCodFRAyAbono();
		server.info("rangosSociedadesCodFRAyAbono Pestanya Sociedades: " + rangoSociedadesCodFRAyAbono);
		
		server.debug("rangoRangoSociedades");
		String rangoSociedades = rangos.getRangoSociedades();
		server.info("rangoSociedades Pestanya Sociedades: " + rangoSociedades);
		
		
		server.debug("rangoTTOOCasuisticas");
		String rangoTTOOCasuisticas = rangos.getRangoTTOOCasuisticas();
		server.debug("rangoClvCT");
		String rangoClvCT = rangos.getRangoClvCT();
		server.debug("rangoCuenta");
		String rangoCuenta = rangos.getRangoCuenta();
		server.debug("rangoCME");
		String rangoCME = rangos.getRangoCME();
//		
		
		
		
		
		
		server.info("rangoTTOO Pestanya Casuisticas: " + rangoTTOOCasuisticas);
		server.info("rangoClvCT Pestanya Casuisticas: " + rangoClvCT);
		server.info("rangoCuenta Pestanya Casuisticas: " + rangoCuenta);
		server.info("rangosCME Pestanya Casuisticas: " + rangoCME);
		
		
	}
	
	
	
	
	
	public String buscarCodigoSociedad(String text) throws SystemException {
		
		server.info("Entra en Buscar Sociedad");
		try {
			String spreadsheetId = Constantes.ID_EXCEL_MAESTRO_COMPENSACIONES;
			String range = rangos.getRangoSociedades();//Constantes.RANGESOCIEDADES; A4:E17
			server.info("El rango es " + range);

			List<List<Object>> values = SheetsUtils.getSheetValues(sheetsService, spreadsheetId, range); 
			String sociedad ="";
			server.info("Hay " +values.size() + " values");
			for(List<Object> fila : values) {
				
				String bussinessName = fila.get(1).toString();
				String taxName = fila.get(2).toString();
				String otherName = fila.get(3).toString();
				String[] otrosNombres = otherName.split(";");
				boolean conEncontrarloUnaVezVale = false;
				for(String nombre : otrosNombres) {
					if((!conEncontrarloUnaVezVale) && (text.contains(bussinessName) && !bussinessName.equalsIgnoreCase("-"))
							|| (text.contains(taxName) && !taxName.equalsIgnoreCase("-") )  
							|| (text.contains(nombre) && !nombre.equalsIgnoreCase("-") )) {
						
						sociedad = fila.get(4).toString();
						server.info("Ha habido match de sociedad, el valor es " + bussinessName + " con codigo de sociedad " + sociedad);
						conEncontrarloUnaVezVale=true;
					}
				}			
			}
			server.info("La sociedad es " + sociedad);
			return sociedad;
		} catch (IOException | GeneralSecurityException e) {
			server.error(e);
			return "";
		}
	}
	
	public List<String> buscarCodigoDeudorTTOO(String tourOperadorOCR) throws SystemException {
		//Instanciar el servicio de Drive
		//OJO las mayusculas y minusculas a la hora de buscar
		
		server.info("Entra en Buscar TTOO");
		
		List<String> salida = new ArrayList<String>();
		try {
			String spreadsheetId = Constantes.ID_EXCEL_MAESTRO_COMPENSACIONES;
			String range = rangos.getRangoTTOO();//Constantes.RANGETTOO;

			List<List<Object>> values = SheetsUtils.getSheetValues(sheetsService, spreadsheetId, range); 
			String ttooName = "";
			for(List<Object> fila : values) {
				
				String otherName = fila.get(1).toString();
				String cif = fila.get(2).toString();
				if( (tourOperadorOCR.contains(fila.get(0).toString()) && !ttooName.equalsIgnoreCase("-"))
						|| (tourOperadorOCR.contains(otherName) && !otherName.equalsIgnoreCase("-") )
						|| (tourOperadorOCR.contains(cif) && !otherName.equalsIgnoreCase("-") )) {
					String[] split = fila.get(3).toString().split(";");
					for(String codigo:split) {
						server.info("Codigo deudor encontrado: " + codigo);
						salida.add(codigo);
					}
				}
			}
			return salida;
		} catch (IOException | GeneralSecurityException e) {
			server.error(e);
			return salida;
		}
	}
	
	public HashMap<String, List<Casuistica>> getCasuisticas() throws SystemException{
		server.debug("Entramos en getCasuisticas");
		
		//Se crea el hashmap de salida, el String será el touroperador y la lista de casuisticas pues eso, la lista de objetos casuistica
		HashMap<String, List<Casuistica>> salida = new HashMap<String,List<Casuistica>>();
		try {
			//Primero hay que cargar los nombres de las casuisticas, lo mas facil es hacerlo en un método propio
			List<String> encabezados = getEncabezadoCasuisticas();
			//Despues cargamos los codigos clvct asociados a esas casuisticas, tambien con metodo propio
			List<String> codigoClvct = getInfo(rangos.getRangoClvCT()); //Constantes.RANGECLVCT);
			List<String> cuentas = getInfo(rangos.getRangoCuenta()); //Constantes.RANGECUENTA);
			List<String> cme = getInfo(rangos.getRangoCME()); //Constantes.RANGECME);
			
			String spreadsheetId = Constantes.ID_EXCEL_MAESTRO_COMPENSACIONES;
			String range = rangos.getRangoTTOOCasuisticas(); //Constantes.RANGECASUISTICAS;
			List<List<Object>> values = SheetsUtils.getSheetValues(sheetsService, spreadsheetId, range);
		
			for(List<Object> fila : values) {
				List<Casuistica> listaCasuisticas = new ArrayList<Casuistica>();
				String nombreTTOO = fila.get(0).toString();
				int contadorParaSociedades = 0;
				for(int i=1;i<7;i++) {
					Casuistica casuistica = new Casuistica();
					List<String> factura = new ArrayList<String>();
					String opciones = fila.get(i).toString();				
					
						String[] casos = opciones.split(",");
						for(int j=0;j<casos.length;j++) {
							if(casos[j].contains("sociedad")) {
								//si el valor de la casilla del excel es "sociedad" hay que sacar todas las sociedades de la tabla de sociedades, 
								//Es un suicidio pero ya no se que hacer
								
								//Primero hay que cargar los valores de la columna
								String rangeSociedad = rangos.getRangoSociedadesCodFRAyAbono();//Constantes.RANGECODIGOCASUISTICASOCIEDAD;
								List<List<Object>> valoresSociedad = SheetsUtils.getSheetValues(sheetsService, spreadsheetId, rangeSociedad);
								for(List<Object> sociedades : valoresSociedad) {
									String[] codigo = sociedades.get(contadorParaSociedades).toString().split(",");
									for(int w=0;w<codigo.length;w++) {
										factura.add(codigo[w]);
									}
									//factura.add(sociedades.get(contadorParaSociedades).toString());
								}
								contadorParaSociedades++;
							}
							else {
								factura.add(casos[j]);	
							}
							
					}
				
					casuistica.setTipo(encabezados.get(i-1));
					casuistica.setValores(factura);
					casuistica.setCodigoClvct(codigoClvct.get(i-1));
					casuistica.setCuenta(cuentas.get(i-1));
					casuistica.setCme(cme.get(i-1));

					
					listaCasuisticas.add(casuistica);
				}
				salida.put(nombreTTOO, listaCasuisticas);
			}
			
			
			return salida;
		} catch (IOException | GeneralSecurityException e) {
			server.error(e);
			return null;
		}
	}
	
	private List<String> getEncabezadoCasuisticas(){
		
		server.info("Entramos en Get Encabezado de Casuisticas");
		
		List<String> salida = new ArrayList<String>();
		try {
			String spreadsheetId = Constantes.ID_EXCEL_MAESTRO_COMPENSACIONES;
			String range = Constantes.RANGEENCABEZADOCASUISTICA; // fijo
			List<List<Object>> values = SheetsUtils.getSheetValues(sheetsService, spreadsheetId, range);
			for(List<Object> fila : values) {
				salida.add(fila.get(0).toString());
				salida.add(fila.get(1).toString());
				salida.add(fila.get(2).toString());
				salida.add(fila.get(3).toString());
				salida.add(fila.get(4).toString());
				salida.add(fila.get(5).toString());
			}
			return salida;
		} catch (IOException | GeneralSecurityException e) {
			server.error(e);
			return null;
		}
	}
	
	private List<String> getInfo(String range) throws SystemException {
		
		List<String> salida = new ArrayList<String>();
		try {
			String spreadsheetId = Constantes.ID_EXCEL_MAESTRO_COMPENSACIONES;
			List<List<Object>> values = SheetsUtils.getSheetValues(sheetsService, spreadsheetId, range);
			for(List<Object> fila : values) {				
				salida.add(fila.get(0).toString());
			}
			return salida;
		} catch (IOException | GeneralSecurityException e) {
			server.error(e);
//			return null;
			throw new SystemException("Error en getInfo, no se devuelve array", e, "", false);
		}
	}
	
	
	public List<String> listaTTOO() throws SystemException {
		
		server.info("Entra en Listar TTOO");
		
		
		List<String> salida = getInfo(rangos.getRangoNombreTTOO());// Constantes.RANGENOMBRETTOO);
		
		return salida;
	}
	
	public HashMap<String,List<String>> getTTOO() throws SystemException {
		server.debug("Entrando en getTTOO");
		
		HashMap<String,List<String>> salida = new HashMap<String,List<String>>();
		try {
			String spreadsheetId = Constantes.ID_EXCEL_MAESTRO_COMPENSACIONES;
			String range = rangos.getRangoTTOO();//Constantes.RANGETTOO;

			List<List<Object>> values = SheetsUtils.getSheetValues(sheetsService, spreadsheetId, range); 
			server.debug("obtenidos valores");
			for(List<Object> fila : values) {
				String clave = fila.get(0).toString();
				List<String> nombres = new ArrayList<String>();
				nombres.add(clave);
				nombres.add(fila.get(1).toString());
				String variosNombres = fila.get(2).toString();
				String[] split = variosNombres.split(";");
				for(String nombreVario: split) {
					nombres.add(nombreVario);
				}
				salida.put(clave, nombres);
				
			}
		}
		catch(GoogleJsonResponseException ex) {
			GoogleJsonError error = ex.getDetails();
			server.info(error.getMessage());
			for(ErrorInfo k : error.getErrors()) {
				server.info(k.getMessage());
			}
			
		} catch (Exception e) {
			throw new SystemException("No se ha obtenido valor de ttoo gen secur", e, "", false);
//			server.error("Error getTTOO " + e);
//			return salida;
		}
		return salida;
	}
	
	public String buscarTTOOEnReclamaciones(String codigoTTOOCartaPago) {
		String range = Constantes.RANGERECLAMACIONES;
		String salida = "";
		try {
			List<List<Object>> values = SheetsUtils.getSheetValues(sheetsService, Constantes.ID_EXCEL_MAESTRO_RECLAMACIONES, range);
			
	        if (values == null || values.isEmpty()) {
	            server.warn("No se han encontrado datos");
	        }else {
	        	for(int i = 4; i < values.size(); i++) {
	        		List<Object> row = values.get(i);     		
	        		if((row.size() >= 3)){
	        			String codigoTTOO = row.get(0).toString();
	        			if(codigoTTOO.equalsIgnoreCase(codigoTTOOCartaPago)) {
	        				salida = row.get(2).toString();
	        				break;
	        			}
	        		}
	        	}
	        }
		} catch (IOException | GeneralSecurityException e) {
			server.error(e);
			return salida;
		}
        return salida;
	}
	
	public void escribirExcel (CartaPago currentCartaPago,  HashMap<String, List<Casuistica>> casuisticas,String descargado, String ejecucion, String error, Double otros, String fichero, LopesanMail mail) {
		server.info("Empieza Escribir Excel");
		if(currentCartaPago.getNombreTuroperador().isEmpty()) {
			String ttoo = mail.getCartasDePago().get(fichero);
			server.info("El TTOO en el que escribiria el resultado sería: " + ttoo);
			server.info("La carta de pago es: " + fichero);
			
			String spreadsheetId = Constantes.ID_EXCEL_REGISTRO;
			String rangeW = ttoo + "!A3";
//			errorAEscribir = ejecucion + ": " +error;
			List<List<Object>> valuesW = Arrays.asList(
					Arrays.asList(ttoo, fichero, "", "", getFechaEjecucion(), "", "", "", "", "", "", "", descargado,
							"", ejecucion + ": " + error));
			
			try {
				SheetsUtils.setSheetValues(sheetsService, spreadsheetId, valuesW, rangeW);
			} catch (IOException e) {
				server.error("Fallo al escribir excel cuando la carta de pago es erronea" , e);
			}
		}
		else {
			String errorAEscribir ="";
			if(descargado.equalsIgnoreCase("SI") ) {
				errorAEscribir = ejecucion + ": Sin error";
			}
			else {
				errorAEscribir = ejecucion + ": " +error;
			}
			try {
				String spreadsheetId = Constantes.ID_EXCEL_REGISTRO;
				//TODO: definir el inicio del rango para escribir los datos
				// TODO: jgrau-> si la carta de pago es null/acabo de inicializarla con new cartapago, nombrettoo es "", no puede 
				server.info("El TTOO en el que escribiria el resultado sería: " + currentCartaPago.getNombreTuroperador());
				String rangeW = currentCartaPago.getNombreTuroperador() + "!A3";
				
				server.info("El rango a buscar es " +rangeW);
				
				server.info(currentCartaPago.getTtooDeudor().get(0));
				server.info(currentCartaPago.getNombreTuroperador());
				
				//Sabemos que hay solo 6 casuisticas, por lo que vamos a meter a pelo los campos
				//En el excel los campos son
				//ID SAP, nombre TTOO, Fecha carta de pago, fecha procesamiento, importe total, importe de las 5 casuisticas, importe desconocido
				//descarga (SI/NO), codigo del fichero y tipo de error
				
				List<Double> valores = new ArrayList<Double>();			
				//double otros = Math.round(Double.valueOf(currentCartaPago.getImporte()) * 100) / 100d;
				for (Casuistica casu : casuisticas.get(currentCartaPago.getNombreTuroperador())) {
					valores.add(currentCartaPago.getSumatorios().get(casu.getTipo()));
					Double casuDinero = 0.0d;
					if (casu.getTipo().equalsIgnoreCase(Constantes.ABONODESCONTADO)) {
						casuDinero = currentCartaPago.getSumatorios().get(casu.getTipo()) * -1;
					} else {
						casuDinero = currentCartaPago.getSumatorios().get(casu.getTipo());
					}
	//				otros -= casuDinero;
	//				otros = Math.round(Double.valueOf(otros) * 100) / 100d;
	//				server.info("Queda " + otros);				
				}
	
				String[] x = currentCartaPago.getNombreDocumento().split("\\\\");
				String nombreFichero = x[x.length - 1];
				List<List<Object>> valuesW = Arrays.asList(
				Arrays.asList(currentCartaPago.getTtooDeudor().get(0),nombreFichero,currentCartaPago.getSociedad(), currentCartaPago.getFecha(),getFechaEjecucion(),
						currentCartaPago.getImporte(),String.valueOf(valores.get(0)),String.valueOf(valores.get(1)),String.valueOf(valores.get(2))
						,String.valueOf(valores.get(3)),String.valueOf(valores.get(4)),
						String.valueOf(otros),descargado, currentCartaPago.getNumeroDocumento(),errorAEscribir)
				);
				
				List<Casuistica> casos = casuisticas.get(currentCartaPago.getNombreTuroperador());
				
				if(casos == null) {
					server.info("La lista de casuisticas es null");
				}
				else if (casos.size() == 0) {
					server.info("La lista de casuisticas no es null pero es vacia");
				}
				else {
					server.info("La lista de casos no es null y tiene valores");
				}
				
				server.info(currentCartaPago.getTtooDeudor().get(0));
				server.info(currentCartaPago.getNombreTuroperador());
				server.info(currentCartaPago.getNumeroDocumento());
				server.info(currentCartaPago.getFecha());
				server.info(getFechaEjecucion());
				server.info(currentCartaPago.getImporte());
				server.info(valores.get(0));
				server.info(valores.get(1));
				server.info(valores.get(2));
				server.info(valores.get(3));
				server.info(valores.get(4));
				server.info(otros);
				server.info(descargado);
				server.info(error);			
				SheetsUtils.setSheetValues(sheetsService, spreadsheetId, valuesW, rangeW); 
			} catch (Exception e) {
				server.error("Fallo al escribir excel " , e);
			}
		}
		
	}
	
	
	public String destinatarioCorreo(String codigoTTOOCartaPago) {
//		String range = "Robotics Base Test!A5:W200";
		String range = Constantes.RANGERECLAMACIONES;
		//Rango para leer hasta la utlima fila:"Robotics Base!A5:W"
		String salida = "";
		try {
			List<List<Object>> values = SheetsUtils.getSheetValues(sheetsService, Constantes.ID_EXCEL_MAESTRO_RECLAMACIONES, range);		
	        if (values == null || values.isEmpty()) {
	            server.warn("No se han encontrado datos");
	        }else {
	        	for(int i = 0; i < values.size(); i++) {
	        		List<Object> row = values.get(i);     		
	        		if((row.size() >= 3)){
	        			String codigoTTOO = row.get(0).toString();
	        			if(codigoTTOO.equalsIgnoreCase(codigoTTOOCartaPago)) {
	        				//Este seria el campo del maild el gestor
	        				salida = row.get(16).toString();
	        				break;
	        			}
	        		}
	        	}
	        }
		} catch (IOException | GeneralSecurityException e) {
			server.error(e);
			return salida;
		}
        return salida;
	}
	
	public String getFechaEjecucion() {
		 Date ahora = new Date();
			final SimpleDateFormat dateFormatDd = new SimpleDateFormat("dd");
			final SimpleDateFormat dateFormatMm = new SimpleDateFormat("MM");
			final SimpleDateFormat dateFormatYy = new SimpleDateFormat("yyyy");
	        String dia = dateFormatDd.format(ahora);
			String mes = dateFormatMm.format(ahora);
			String anno = dateFormatYy.format(ahora);
	        return dia +"." + mes +"."+anno;
	}
	
	public String buscarCodigoAcreedorTTOO(String tourOperadorOCR) throws SystemException {
		server.info("Entra en Buscar Acreedor TTOO");	
		String salida = "";
		try {
			String spreadsheetId = Constantes.ID_EXCEL_MAESTRO_COMPENSACIONES;
			String range = rangos.getRangoTTOO();//Constantes.RANGETTOO;
			server.info("El rango es " + range);

			List<List<Object>> values = SheetsUtils.getSheetValues(sheetsService, spreadsheetId, range); 
			String ttooName = "";
			server.info("Hay " +values.size() + " values");
			for(List<Object> fila : values) {
				
				String otherName = fila.get(1).toString();
				String cif = fila.get(2).toString();
				if( (tourOperadorOCR.contains(fila.get(0).toString()) && !ttooName.equalsIgnoreCase("-"))
						|| (tourOperadorOCR.contains(otherName) && !otherName.equalsIgnoreCase("-") )
						|| (tourOperadorOCR.contains(cif) && !otherName.equalsIgnoreCase("-") )) {
					salida = fila.get(4).toString();
					server.info("Ha habido match de TT, el valor del acreedor es es " + salida);
				}
			}
			return salida;
		} catch (IOException | GeneralSecurityException e) {
			server.error(e);
			return salida;
		}
	}
}
