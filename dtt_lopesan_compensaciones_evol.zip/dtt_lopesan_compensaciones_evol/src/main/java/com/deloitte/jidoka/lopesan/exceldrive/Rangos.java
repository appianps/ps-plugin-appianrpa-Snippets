package com.deloitte.jidoka.lopesan.exceldrive;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;

import com.deloitte.jidoka.lopesan.cartapago.Constantes;
import com.deloitte.jidoka.lopesan.exceptions.SystemException;
import com.deloitte.lopesan.googledrive.SheetsServiceUtil;
import com.deloitte.lopesan.googledrive.SheetsUtils;
import com.google.api.services.sheets.v4.Sheets;
import com.novayre.jidoka.client.api.IJidokaServer;

public class Rangos {
	
	protected IJidokaServer<?> server;
	
	private String rangoTTOO; //"TTOO!A4:E16";
	private String rangoNombreTTOO; //"TTOO!A4:A16";
	private String rangoSociedades; // "Sociedades!A4:E17";
	
	// rangos casuisticas, hay 2 tablas
	private int fila1TTOOcasuisticas;
	private int filaFinTTOOcasuisticas;
	private int fila1CasuCasuisticas;
	private int filaFinCasuCasuisticas;
	
	private String rangoTTOOcasuisticas;
	//private String rangoCasuisticaCasuisticas;
	
	private String rangoSociedadesCodFRAyAbono;
	
	private String rangoClvCT; //"Casuisticas!B20:B26";
	private String rangoCuenta; //"Casuisticas!C20:C26";
	private String rangoCME; //"Casuisticas!D20:D26";
	
	Sheets sheetsService;
//	String spreadsheetId = Constantes.ID_EXCEL_MAESTRO_COMPENSACIONES;

	
	
	Rangos(IJidokaServer<?> server, Sheets sheetsService) throws SystemException{
		this.server = server;
		this.rangoTTOO = "";
		this.rangoSociedades = "";
		
		this.fila1TTOOcasuisticas = 4;
		this.filaFinTTOOcasuisticas = 0;
		this.fila1CasuCasuisticas = 0;
		this.filaFinCasuCasuisticas = 0;
		
		this.rangoTTOOcasuisticas = "";
		//this.rangoCasuisticaCasuisticas = "";
		this.rangoSociedadesCodFRAyAbono = "";
		this.sheetsService = sheetsService;
	}
	
	
//	private void obtenerSpreadSheetId() {
//		String spreadsheetId = Constantes.ID_EXCEL_MAESTRO_COMPENSACIONES;
//		setSpreadSheetId(spreadsheetId);
//	}
	
//	public void setSpreadSheetId(String spreadsheetId) {
//		this.spreadsheetId = spreadsheetId;
//	}
//	
//	public String getSpreadSheetId() {
//		return spreadsheetId;
//	}
	
	public String getRangoTTOO() throws SystemException {
		rangoTTOO = calcularRangoTTOO();
		return rangoTTOO;
	}
	
	public String getRangoNombreTTOO() throws SystemException {
		rangoNombreTTOO = calcularRangoNombreTTOO();
		return rangoNombreTTOO;
	}
	
	private String calcularRangoTTOO() throws SystemException {
		
//		obtenerSpreadSheetId();
		String nombreTTOOfinal = "TTOO!A4:E"; // E16
		nombreTTOOfinal = nombreTTOOfinal + calculaTTOO();
	
		return nombreTTOOfinal;
	}
	
	private String calcularRangoNombreTTOO() throws SystemException {
//		obtenerSpreadSheetId();
		String nombreTTOOfinal = "TTOO!A4:A"; //A16
		nombreTTOOfinal = nombreTTOOfinal + calculaTTOO();
		
		return nombreTTOOfinal;
	}
	
	private String calculaTTOO() throws SystemException {
		String valorNumerico = "";
		String range = "TTOO!A4:E";//(E16) 
		ArrayList<String> array = new ArrayList<>();
		try {
			
			List<List<Object>> values = SheetsUtils.getSheetValues(sheetsService, Constantes.ID_EXCEL_MAESTRO_COMPENSACIONES, range); 
			
	        if (values == null || values.isEmpty()) {
	            server.warn("No se han encontrado datos para turoperadores");
	        }else {
	        	server.debug("se han encontrado datos para ttoo, se busca el valor");
	        	for(int i = 0; i < values.size(); i++) {
	        		List<Object> row = values.get(i);     		
	        		// si es mayor o igual a 5, la ultima que lo sea sera la ultima fila. haremos eso +4 por la fila real
	        		if(row.size() >= 5 && row.get(0) != null && !row.get(0).toString().equals("")){
//	        			server.debug("Fila vacia/con datos irrelevantes, no hay mas turoperadores. I: " + i);
	        			valorNumerico = valorNumerico + (i+4); // estaremos en fila con datos.
	        			array.add("" + (i + 4));
	        			// por lo tanto sumaremos 4(la cabecera) para obtener el valor A16
	        		}
	        		else {
	        			server.debug("Fila con valor ");
	        			
	        			// si no hay datos irrelevantes 
//	        			valorNumerico = valorNumerico + (values.size()+3); // sumamos 3 por la cabecera.
	        		}
	        	}
	        }
		} catch (IOException | GeneralSecurityException e) {
			throw new SystemException("No se ha obtenido valor de TTOO", null, "fin", false);
//			server.error("No se ha obtenido valor de TTOO");
		}
		String valorAdevolver = "";
//		valorAdevolver = array.get(array.size()-1);
//		String valorAdevolver = "";
		if(array.size()>0) {
			valorAdevolver = array.get(array.size()-1);
		}
		else {
//			valorAdevolver = "mal";
			throw new SystemException("No se ha podido obtener valores de TTOO", null, "fin", false);
		}
		System.out.println("Valor a devolver = " + valorAdevolver);
		
		return valorAdevolver;
//		return valorNumerico;
	}
	
	private String calculaSociedades() throws SystemException {
		String valorNumerico = "";
		String range = "Sociedades!A4:G";//(G17) 
		ArrayList<String> array = new ArrayList<>();
		try {
			
			List<List<Object>> values = SheetsUtils.getSheetValues(sheetsService, Constantes.ID_EXCEL_MAESTRO_COMPENSACIONES, range); 
			
	        if (values == null || values.isEmpty()) {
	            server.warn("No se han encontrado datos para sociedades");
	        }else {
	        	for(int i = 0; i < values.size(); i++) {
	        		List<Object> row = values.get(i);     		
	        		if(row.size() >= 7 && row.get(0) != null && !row.get(0).toString().equals("")){
//	        			server.debug("Fila vacia/con datos irrelevantes, no hay mas sociedades");
	        			valorNumerico = valorNumerico + (i+4); // estaremos en fila con datos irrelevantes.
	        			array.add("" + (i + 4));
	        			// por lo tanto sumaremos 4(la cabecera) para obtener el valor G17
	        		}
//	        		else {
//	        			server.debug("No entra en el if");
//	        		}
	        	}
	        }
		} catch (IOException | GeneralSecurityException e) {
			throw new SystemException("No se ha obtenido valor de TTOO", null, "fin", false);
//			server.error("No se han podido obtener valores Sociedades");
		}
	
		String valorAdevolver = "";
//		if(array.size() > 0 ) {
			valorAdevolver = array.get(array.size()-1);
//		}
		
		return valorAdevolver;
//		return valorNumerico;
	}
	
	private String calcularRangoSociedadeCodFRAyAbono() throws SystemException {
//		obtenerSpreadSheetId();
		String nombreTTOOfinal = "Sociedades!F4:G"; //G17
		nombreTTOOfinal = nombreTTOOfinal + calculaSociedades();
		
		return nombreTTOOfinal;
	}
	
	private String calcularRangoSociedades() throws SystemException {
//		obtenerSpreadSheetId();
		String nombreTTOOfinal = "Sociedades!A4:E"; //E17
		nombreTTOOfinal = nombreTTOOfinal + calculaSociedades();
		
		return nombreTTOOfinal;
	}
	
	public String getRangoSociedadesCodFRAyAbono() throws SystemException {
		rangoSociedadesCodFRAyAbono = calcularRangoSociedadeCodFRAyAbono();
		return rangoSociedadesCodFRAyAbono;
	}
	
	public String getRangoSociedades() throws SystemException {
		rangoSociedades = calcularRangoSociedades();
		return rangoSociedades;
	}
	
	
	
	
	//********************************************** hacer un for desde 0 hasta casuistica.
	private void calcularRangoCasuisticas() throws SystemException{
//		obtenerSpreadSheetId();
		String totalFilas = "Casuisticas!A4:G"; // para obtener las 2 tablas
		String valor = calculaCasuisticas();
		if(valor.equals("")) {
			throw new SystemException("No se han obtenido valores de hoja casuisticas", null, "fin", false);
		}
		else {
//			server.debug("Valor: " + valor);
			filaFinCasuCasuisticas = Integer.parseInt(valor);
		}
		totalFilas = totalFilas + valor;
		String cabeceraCasu = calcularCabeceraTablaCasuisticas(valor);
//		String finalTTOOcasuistivas = calcularTTOOCasuisticas(fila1CasuCasuisticas);
		
		
	}
	
	private void calcularTTOOCasuisticas() throws SystemException { // hacer for desde 0 hasta casuistica(fila1casucasuisticas) (Casuistica)
		// primero habrá que llamar a calcularRangoCasuisticas para obtner ese valor.
		calcularRangoCasuisticas();
		String valorNumerico = "";
		String range = "Casuisticas!A4:G" + filaFinCasuCasuisticas;//G+fila cabecera casuisticas
		try {
			
			List<List<Object>> values = SheetsUtils.getSheetValues(sheetsService, Constantes.ID_EXCEL_MAESTRO_COMPENSACIONES, range); 
			
	        if (values == null || values.isEmpty()) {
	            server.warn("No se han encontrado datos para casuisticas");
	        }
	        else {
	        	for(int i = 0; i < values.size(); i++) {
	        		List<Object> row = values.get(i);     		// si hay nulo cojo la fila anterior
	        		// si no hay nulos, comprobar cabecera casuistica y coger la fila anterior
	        		if(row.size() < 4 || row.get(0) == null || row.get(0).toString().equals("")) {
	        			filaFinTTOOcasuisticas = i-1+4; // +4 porque empezamos en la fila 4
	        			break;
	        		}
	        		else {
	        			if (row.size() >= 4 && row.get(0).toString().equalsIgnoreCase("Casuistica")) {
		        			server.debug("Fila cabecera casuisticas");
		        			filaFinTTOOcasuisticas = i+3; //porque i empieza en 0 y las filas en 4
	        			}
	        		}
	        	}
	        }
		} catch (IOException | GeneralSecurityException e) {
			throw new SystemException("No se han podido obtener valores TTOOCasuisticas", null, "", false);
//			server.error("No se han podido obtener valores TTOOCasuisticas");
		}
	}
	
	
	private String calcularCabeceraTablaCasuisticas(String ultimafila) throws SystemException {
		String valorNumerico = "";
		String range = "Casuisticas!A4:G" + ultimafila;//G+ultimafila
		try {
			
			List<List<Object>> values = SheetsUtils.getSheetValues(sheetsService, Constantes.ID_EXCEL_MAESTRO_COMPENSACIONES, range); 
			
	        if (values == null || values.isEmpty()) {
	            server.warn("No se han encontrado datos para casuisticas");
	        }else {
	        	for(int i = values.size()-1; i >= 0; i--) {
	        		List<Object> row = values.get(i);     		
					if (row.size() >= 4 && row.get(0).toString().equalsIgnoreCase("Casuistica")) {
	        			server.debug("Fila cabecera casuisticas");
	        			valorNumerico = valorNumerico + (i+4); //fila casuisticas
	        			fila1CasuCasuisticas = i+4; // 15+4
	        			
	        		}
	        	}
	        }
		} catch (IOException | GeneralSecurityException e) {
			throw new SystemException("No se ha podido obtener valores", null, "fin", false);
//			server.error("No se ha podido obtener valores");
		}
	
		return valorNumerico;
		
		
	}
	
	private String calculaCasuisticas() throws SystemException {
		String valorNumerico = "";
		ArrayList<String> array = new ArrayList<>();
		String range = "Casuisticas!A4:G";//(G17) 
		try {
			
			List<List<Object>> values = SheetsUtils.getSheetValues(sheetsService, Constantes.ID_EXCEL_MAESTRO_COMPENSACIONES, range);
//			server.info("Values: " + values);
//			for(List<Object> value: values) {
//				server.debug("Fila: " + value);
//			}
			server.debug("No ha fallado la lectura de googlesheets");
			
	        if (values == null || values.isEmpty()) {
	            server.warn("No se han encontrado datos para casuisticas");
	        }else {
	        	for(int i = 0; i < values.size(); i++) {
	        		List<Object> row = values.get(i);    
//	        		server.debug(row.size());
					if (row.size() > 0 && row.size() >= 4 && (row.get(2) != null && !row.get(2).toString().isEmpty()
							&& !row.get(2).toString().equals(""))) {
//						server.debug("Fila antes de compensacion anticipos, row: " + i);
						array.add("" + (i + 4));
						valorNumerico = valorNumerico + (i + 4); // estaremos en fila con 4 posiciones
						// por lo tanto sumaremos 4(la cabecera) para obtener el valor G26
					}
//	        		else { 
//	        			if(i == values.size()-1 ) {// si no hay datos irrelevantes 
//		        			valorNumerico = valorNumerico + (values.size()+3); // sumamos 3 por la cabecera.
//		        			server.debug("Ultima Fila sin datos irrelevantes");
//	        			}
//	        		}
	        	}
	        }
		} catch (IOException | GeneralSecurityException | NumberFormatException e) {
			server.debug("Estamos en metodo calcula Casuisticas");
			throw new SystemException("No se ha podido obtener valor", null, "fin", false);
//			server.error("No se ha podido obtener valor");//, valor numerico -> 0");
			//valorNumerico = "0";
		}
//		String valorAdevolver = "";
//		valorAdevolver = array.get(array.size()-1);
		String valorAdevolver = "";
		if(array.size()>0) {
			valorAdevolver = array.get(array.size()-1);
		}
		else {
//			valorAdevolver = "mal";
			throw new SystemException("No se ha podido obtener valores de Casuisticas", null, "", false);
		}
		System.out.println("Valor a devolver = " + valorAdevolver);
		
		return valorAdevolver;
	}
	
	
	
	public String getRangoTTOOCasuisticas() throws SystemException {
		calcularTTOOCasuisticas();
		rangoTTOOcasuisticas = "Casuisticas!A4:G" + filaFinTTOOcasuisticas; //TTOOCasuisticas
		
		return rangoTTOOcasuisticas;
	}
	
//	public String getRangoCasuisticaCasuisticas() {
//		calcularRangoCasuisticas();
//		return rangoCasuisticaCasuisticas;
//	}
	
	
	public String getRangoClvCT() throws SystemException {
		calcularRangoCasuisticas();
		rangoClvCT = "Casuisticas!B" + (fila1CasuCasuisticas+1) + ":B" + (filaFinCasuCasuisticas);
		return rangoClvCT;
	}
	
	public String getRangoCuenta() throws SystemException {
		calcularRangoCasuisticas();
		rangoCuenta = "Casuisticas!C" + (fila1CasuCasuisticas+1) + ":C" + (filaFinCasuCasuisticas);
		return rangoCuenta;
	}
	
	public String getRangoCME() throws SystemException {
		calcularRangoCasuisticas();
		rangoCME = "Casuisticas!D" + (fila1CasuCasuisticas+1) + ":D" + (filaFinCasuCasuisticas);
		return rangoCME;
	}
	

}
