package com.deloitte.jidoka.lopesan.transaccion.SAP;

/**
 * SAP Constants.
 * <p>
 * Constants used by the robot
 *
 * @author Jidoka
 */
public class SapConstants {
	
	/**
	 * Timeouts.
	 */
	public class Timeouts {
		
		public static final int SHORT_WAIT = 3;
		public static final int DEFAULT_WAIT = 10;
		public static final int MEDIUM_WAIT = 30;
		public static final int LONG_WAIT = 60;
		public static final int WAIT_SHORT_TIMEOUT = 5;
		public static final int WAIT_DEFAULT_TIMEOUT = 30;
		public static final int WAIT_LONG_TIMEOUT = 120;
	}
	
	/**
	 * App Paths.
	 */
	public class App {
		
		public static final String SAP_EXECUTABLE_PATH = "C:\\Program Files (x86)\\SAP\\FrontEnd\\SAPgui";
		public static final String SAP_EXECUTABLE = "saplogon.exe";
		
	}

	/**
	 * Windows Titles.
	 */
	public static class Titles {
		
		public static final String SAP_LOGON_WINDOW_TITLE = "SAP.*";
		public static final String SAP_LOGON_WINDOW_TITLE_FIRST = "SAP";
		public static final String SAP_MAIN_WINDOW_TITLE = "SAP Easy Access.*";
		public static final String SAP_GUI_WINDOW = "Seguridad SAP GUI";	
		
	}
	
	/**
	 * Login texts.
	 */
	public static class Login {
		
		public static final String SAP_LOGIN_FAIL = ".*(clave de acceso incorrectos|password is incorrect).*";
		
	}
	
	/**
	 * SAP Controls.
	 */
	public static class Controls {
		
		public static final String STATUS_BAR =  "Afx:67CF0000:8:00010003:00000010:00000000";
		public static final String LOGIN_USER_TEXTFIELD = "txtRSYST-BNAME";
		public static final String LOGIN_PASSWORD_TEXTFIELD = "pwdRSYST-BCODE";
		public static final String LOGIN_LANGUAGE_TEXTFIELD = "txtRSYST-LANGU";
		public static final String MANDANTE = "txtRSYST-MANDT";		
	}
	
	/**
	 * Date Formats.
	 */
	public static class Formats {
		
		public static final String SAP_DATE_FORMAT = "dd.MM.yyyy"; 
		public static final String SAP_REDUCED_DATE_FORMAT = "dd.MM.yy"; 
		
	}
	
}
