package com.deloitte.jidoka.lopesan.exceptions;

import com.novayre.jidoka.client.api.exceptions.JidokaException;

/**
 * 
 * Class for exception control <code> BusinessException </code>
 * 
 * @author DTUser
 *
 */
public class BusinessException extends JidokaException{
	
	/**
	 * Serial version
	 */
	private static final long serialVersionUID = -8070623090775481252L;

	/**
	 * Indicate the next workflow action after the exception occurs
	 */
	private final String nextAction;
	
	/**
	 * <code>true</code> if send a screenshot to the server when the exception occurs
	 */
	private final Boolean sendScreen;
	
	/**
	 * Exception builder of type <code> BusinessException </code>
	 * 
	 * @param message
	 * @param nextAction
	 * @param sendScreen
	 */
	public BusinessException(String message, String nextAction, Boolean sendScreen) {
		super(message);
		
		this.nextAction = nextAction;
		this.sendScreen = sendScreen;
	}

	/**
	 * @return the nextAction
	 */
	public String getNextAction() {
		return nextAction;
	}

	/**
	 * @return the sendScreen
	 */
	public Boolean getSendScreen() {
		return sendScreen;
	}
	
}
