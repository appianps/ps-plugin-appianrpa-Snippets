package com.deloitte.jidoka.ttoo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.mortbay.jetty.Server;

import com.deloitte.jidoka.lopesan.cartapago.CartaPago;
import com.deloitte.jidoka.lopesan.cartapago.Casuistica;
import com.deloitte.jidoka.lopesan.cartapago.Constantes;
import com.deloitte.jidoka.lopesan.cartapago.Factura;
import com.deloitte.jidoka.lopesan.config.CeldasUtils;
import com.novayre.jidoka.client.api.IJidokaServer;

public class ViajesCanariasEuropa extends Touroperador {

	private String saldoDeposito="";
	
	public ViajesCanariasEuropa(IJidokaServer<?> server, String sociedad,  List<String> codigosDeudor, String ttooCuentaAcreedor, String ttooName, String nombreFichero,
			HashMap<String, Double> sumatorios)  {
		super(server, sociedad, codigosDeudor, ttooCuentaAcreedor, ttooName, nombreFichero, sumatorios);
	}

	
	private String readFile(String ruta) {
		server.info("ruta " + ruta);
		String textFile="";
		try( FileInputStream excelXML = new FileInputStream(new File(ruta)); Workbook wb = WorkbookFactory.create(excelXML);	){			
			Sheet hoja = wb.getSheetAt(0);			
			Iterator<Row> rowIterator = hoja.iterator();			
	        while (rowIterator.hasNext()) {
		        Row row = rowIterator.next();     
		        Iterator<Cell> cellIterator = row.cellIterator();
	            while(cellIterator.hasNext()) {
	                Cell cell = cellIterator.next();
	                CeldasUtils celdasUtils = new CeldasUtils();
	                textFile=textFile+"¬"+celdasUtils.valorCelda(cell);
		        }
	            textFile=textFile+"\n";
	        }
			wb.close();
		}  catch (IOException | EncryptedDocumentException e) {
			server.error(e);
		} 
		return textFile;
	}


	@Override
	public CartaPago procesarCartaPagoExcel(String ruta, List<Casuistica> listaCasuisticas) {
		server.info("Entra en Procesar Carta Pago Excel en: " + Constantes.VIAJESCANARIASEUROPA);
		String text=readFile(ruta);
		String identificador="";
		String descripcion="";
		String importe="";
		server.info("Entra en Procesar Carta Pago");
		CartaPago viajesCanariasEuropa = new CartaPago();
		String [] ings = text.split("\n");
		boolean contieneFecha=false;
		boolean contieneImporte=false;
		boolean casoEncontrado=false;
		boolean encuentraTotal = false;
		for (String linea: ings) {
			String[] splits = linea.replaceAll(" ", "").trim().split("¬");
			if(splits.length > 2)
				server.info("Linea: " +linea + "Split 0: " +splits[0]+ " Split 1: " + splits[1] + " Split 2: " + splits[2] );
			identificador="";
        	importe="";
        	contieneFecha=false;
    		contieneImporte=false;
    		casoEncontrado=false;
        	int firstCollumn=0;
    		for(int i=0;i<splits.length;i++) {
    			if ((splits[i].matches("\\d{2}\\.\\d{2}\\.\\d{4}") || splits[i].matches("\\d{2}\\/\\d{2}\\/\\d{4}") ) && !contieneFecha) {
    				firstCollumn=i;
    				contieneFecha=true;
    			}else if(splits[i].matches("(-|)\\d+((\\,\\d{2})|)")) {
    				importe=splits[i];
    				contieneImporte=true;
    			}
    		}
    		if (contieneImporte && !linea.toUpperCase().contains("SALDO") && !linea.toUpperCase().contains("DEPOSITO")) {
    			if(contieneFecha) {
					for (int i=0; i<splits.length; i++) {
	        			if (!splits[i].isEmpty() && i>firstCollumn) {
	        				identificador=splits[i];
	        				identificador=getMatch("\\d+[\\/]\\w{3}\\d{2}",identificador);
	        				descripcion=identificador;
	        				server.info("Identificador: " + identificador);
	        				break;
	        			}
	        		}
    			}
    			else {
    				for (int i=0; i<splits.length; i++) {
	        			if (!splits[i].isEmpty()) {
	        				identificador=splits[i];
	        				descripcion=identificador;
	        				break;
	        			}
	        		}
    				server.info("La linea " + linea + " contiene importe pero no contiene fecha");
    				server.info("Identificador: " + identificador);
    			}
				for(int i=0;i<listaCasuisticas.size();i++) {
					Casuistica casuistica = listaCasuisticas.get(i); 
					String tipo = casuistica.getTipo();
					List<String> casos = casuistica.getValores();
	        		for(String caso : casos) {
	        			if(identificador.contains(caso)) {
	        				server.info("El identificador: " + identificador + " contiene el caso: " + caso + " para el tipo: " + tipo );
	        			}
	        			if(linea.contains(caso) && splits.length >=3 && !caso.equalsIgnoreCase("-") && !casoEncontrado) {	
    						//if (tipo.equalsIgnoreCase(Constantes.FACTURA) || tipo.equalsIgnoreCase(Constantes.ABONODESCONTADO)) {
//	        				if (tipo.equalsIgnoreCase(Constantes.FACTURA) || identificador.startsWith("A")) {
//    							String newIdentificador =getMatch("\\d+[\\/]\\w{3}\\d{2}", identificador); 
//    							if(!newIdentificador.equalsIgnoreCase("")) {
//    								identificador = newIdentificador;
//    							}
//    						}
    						if (identificador.contains(caso)) {
    							boolean facturaExiste=false;
    	    					if (tipo.equalsIgnoreCase(Constantes.FACTURA)){
    	    						Double resultado = null;
    								for (Factura factura:viajesCanariasEuropa.getFacturas()) {
    	    							if (identificador.equals(factura.getIdentificador())){
    	    								aumentarSaldoFacturas(tipo,importe);
    	    								resultado=Double.sum(stringToNumber(factura.getImporte()),stringToNumber(importe));
    	    								factura.setImporte(String.format("%.2f",resultado));
    	    								server.info("Actualizada la factura del tipo " + tipo + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + factura.getImporte());
    	    								facturaExiste=true;
    	    								casoEncontrado=true;
    	    								break;
    	    							}
    	    						}
    	    					}
    	    					//if(!facturaExiste && !getMatch("\\d+[\\/]\\w{3}\\d{2}", identificador).equalsIgnoreCase("")){	        						
    	    					if(!facturaExiste ){
    	    						//para viajes canarias la descripcion esta en la misma posicion que el identificador pero sin pasar por la 
    	    						//regez
    	    						aumentarSaldoFacturas(tipo,importe);
    	    						Factura factura = new Factura(tipo,identificador,importe,descripcion);
    	    						viajesCanariasEuropa.addFactura(factura);       
    	    						server.info(Constantes.ANADIDAFACTURATIPO + tipo + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + importe);
    	    						casoEncontrado=true;
    	    					}  
    						}
	        			}
	        		}	
				}
				if(!casoEncontrado && splits.length>=3 && !linea.toUpperCase().contains("TOTAL")) {
					server.info("Casuistica no identificada en la linea: " + identificador);
					String identificadorAux=getMatch("\\d+(| )-", identificador).replaceAll("-", "").trim();
					if (identificadorAux.equals("")) {
		        		if (importe.contains("-")) {	        			
		        			aumentarSaldoFacturas(Constantes.PAGODEMENOS, importe);
		        			Factura factura = new Factura(Constantes.PAGODEMENOS,identificador,importe.replace("-", ""),descripcion);
		        			server.info(Constantes.ANADIDAFACTURATIPO + Constantes.PAGODEMENOS + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + importe );
		        			viajesCanariasEuropa.addFactura(factura);
		        		}else {
		        			aumentarSaldoFacturas(Constantes.PAGODEMAS, importe);
		        			Factura factura = new Factura(Constantes.PAGODEMAS,identificador,importe.replace("-", ""),descripcion);
		        			server.info(Constantes.ANADIDAFACTURATIPO + Constantes.PAGODEMAS + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + importe );
		        			viajesCanariasEuropa.addFactura(factura);
		        		}
					}else {
						boolean facturaExiste=false;
						identificador=identificadorAux;
						Double resultado = null;
						for (Factura factura:viajesCanariasEuropa.getFacturas()) {
							if (identificador.equals(factura.getIdentificador())){
								resultado=Double.sum(stringToNumber(factura.getImporte()),stringToNumber(importe));
								factura.setImporte(String.format("%.2f",resultado));
								server.info("Actualizada la factura del tipo " + Constantes.FACTURA + " con codigo " + identificador + " con importe " + factura.getImporte());
								casoEncontrado=true;
								facturaExiste=true;
								break;
							}
						}
						if(!facturaExiste){	        						
							aumentarSaldoFacturas(Constantes.FACTURA,importe);
							Factura factura = new Factura(Constantes.FACTURA,identificador,importe,identificador);
							viajesCanariasEuropa.addFactura(factura);       
							server.info("Añadida la factura del tipo " + Constantes.FACTURA + " con codigo " + identificador + " con importe " + importe);
							casoEncontrado=true;
						} 
					}
				}
			}
			if (linea.toUpperCase().contains("SALDO") || linea.toUpperCase().contains("DEPOSITO")) {
				saldoDeposito=splits[splits.length - 1];
				saldoDeposito = saldoDeposito.replace(",", ".");
				server.info("Saldo deposito: "+saldoDeposito);
				//aumentarSaldoFacturas("DEPOSITO",importe);
				viajesCanariasEuropa.addSaldoDeposito(saldoDeposito);
			}
			if (linea.toUpperCase().contains("SUM=") && !encuentraTotal) {
				String importeTotal = splits[splits.length-1].replaceAll("SUM=", "");
				server.info("Importe total: "+importeTotal);
				viajesCanariasEuropa.setImporte(importeTotal);
				encuentraTotal=true;
			}
		}
		//Para viajes canarias europa, al tomar la primera vez que sale SUM como total, se calcula antes de quitarle las
		//deducciones de contrato para casos en los que no hay saldo deposito
		if(viajesCanariasEuropa.getSaldosDeposito().size() < 1) {
			double suma = 0.0d;
			suma = suma + Math.round(Double.valueOf(viajesCanariasEuropa.getImporte()) * 100) / 100d;
			
			double deducciones = sumatorios.get(Constantes.DEDUCCION);
			
			suma += deducciones;
			server.info("Arreglo tras deducciones: " + String.valueOf(suma));
			viajesCanariasEuropa.setImporte(String.valueOf(suma));
		}
		
		sumatorios.forEach((k,v) -> server.info("Key: " + k + ": Value: " + v));
        viajesCanariasEuropa.setSumatorios(sumatorios);
        viajesCanariasEuropa.setSociedad(getSociedad());
        viajesCanariasEuropa.setTtooDeudor(getTtooCuentaDeudor());
        viajesCanariasEuropa.setTtooAcreedor(getTtooCuentaAcreedor());
        viajesCanariasEuropa.setNombreTuroperador(getTouroperadorName());
        viajesCanariasEuropa.setNombreDocumento(getNombreFichero());
        viajesCanariasEuropa.setFecha(super.getFecha());
        viajesCanariasEuropa.setOtros(calcularOtros(Constantes.VIAJESCANARIASEUROPA, viajesCanariasEuropa.getImporte(), listaCasuisticas, viajesCanariasEuropa.getSaldosDeposito()));
		return viajesCanariasEuropa;	
	}

	private Double stringToNumber(String valor) {
		String regexMilComa = "(-|)\\d{1,3}(,\\d{3})*(\\.\\d+)?";
		String regexMilPunto = "(-|)\\d{1,3}(.\\d{3})*(\\,\\d+)?";
		String regexComa = "(-|)\\d+(\\,\\d+)?";
		if(valor.matches(regexMilComa)) {
			valor = valor.replace(",","");
		}else if(valor.matches(regexMilPunto)) {
			valor = valor.replace(".", "");
			valor = valor.replace(",", ".");
		}else if(valor.matches(regexComa)) {
			valor = valor.replace(",", ".");
		}
		if(valor.contains("-")) {
			valor = valor.replace("-", "");
			return Double.valueOf(valor)*(-1);
		}else {
			return Double.valueOf(valor);
		}
	}
	
	@Override
	public CartaPago procesarCartaPagoPDF(String text, List<Casuistica> listaCasuisticas) {
		return null;
	}

	@Override
	public CartaPago procesarCartaPagoWord(String text, List<Casuistica> listaCasuisticas) {
		return null;
	}


	@Override
	public CartaPago procesarCartaPagoGenerica(String rutaFichero, List<Casuistica> listaCasuisticas) {
		return null;
	}
}
