package com.deloitte.jidoka.ttoo;

import java.util.HashMap;
import java.util.List;

import com.deloitte.jidoka.lopesan.cartapago.CartaPago;
import com.deloitte.jidoka.lopesan.cartapago.Casuistica;
import com.deloitte.jidoka.lopesan.cartapago.Constantes;
import com.deloitte.jidoka.lopesan.cartapago.Factura;
import com.novayre.jidoka.client.api.IJidokaServer;

public class MeetingPoint extends Touroperador {

	public MeetingPoint(IJidokaServer<?> server, String sociedad, List<String> codigosDeudor, String ttooCuentaAcreedor, String ttooName, String nombreFichero,
			HashMap<String, Double> sumatorios)  {
		super(server, sociedad, codigosDeudor, ttooCuentaAcreedor, ttooName, nombreFichero, sumatorios);
	}


	@Override
	public CartaPago procesarCartaPagoPDF(String text, List<Casuistica> listaCasuisticas) {

		server.info("Entra en Procesar Carta Pago PDF de " + Constantes.MEETINGPOINT);
		CartaPago meetingPoint = new CartaPago();
		String [] ings = text.split("\r");
		String fecha="";
		String importeTotal="";
		boolean casoEncontrado=false;
        server.info("Numero de lineas del pdf: " +ings.length);	
        for (String linea: ings) {
        	linea = linea.replaceAll("\n", "");
        	linea = linea.replaceAll("__", " ");
        	linea = linea.replaceAll("_", "");
        	String[] split = linea.split(" ");
        	String identificador="";
        	String definicion="";
        	String importe="";        	
        	boolean contieneFecha=false;
        	boolean contieneImporte=false;
    		for(String part:split) {
    			if (part.matches("\\d{2}\\.\\d{2}\\.\\d{4}")) {
    				contieneFecha=true;
    			}else if(part.matches("\\d{1,3}(\\.\\d{3})*(\\,\\d{2})(-|)?")) {
    				importe=part;
    				contieneImporte=true;
    			}
    		}
        	casoEncontrado = false;
        	if (contieneFecha && contieneImporte) {
        		for (int i=0; i<split.length; i++) {
        			if (!split[i].isEmpty() && i>0) {
        				identificador=split[i];
        				definicion=identificador;
        				break;
        			}
        		}
	        	for(Casuistica casuistica : listaCasuisticas) {
	        		//Aqui tendriamos el tipo de casuistica y la lista de string que hay que buscar
	        		String tipo = casuistica.getTipo();        		
	        		List<String> casos = casuistica.getValores();
	        		for(String caso : casos) {
	        			if(linea.contains(caso) && split.length >=3 && !caso.equalsIgnoreCase("-")) {
	        				boolean facturaExiste=false;
        					if (tipo.equalsIgnoreCase(Constantes.FACTURA)){
        						Double resultado = null;
    							for (Factura factura:meetingPoint.getFacturas()) {
	    							if (identificador.equals(factura.getIdentificador())){
	    								aumentarSaldoFacturas(tipo,importe);
	    								resultado=Double.sum(stringToNumber(factura.getImporte()),stringToNumber(importe));
	    								factura.setImporte(String.format("%.2f",resultado));
	    								server.info("Actualizada la factura del tipo " + tipo + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + factura.getImporte());
	    								facturaExiste=true;
	    								break;
	    							}
	    						}
        					}
        					if(!facturaExiste){	        						
        						aumentarSaldoFacturas(tipo,importe);
        						//Para Meeting point la descripcion es la misma que el identificador
        						Factura factura = new Factura(tipo,identificador,importe,definicion);
        						meetingPoint.addFactura(factura);       
        						server.info("Añadida la factura del tipo " + tipo + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + importe);
        					}
	    					casoEncontrado = true;
	        			}
	    			}
	    		}
	        	if(!casoEncontrado && split.length>=3) {
	        		if (importe.contains("-")) {	        			
	        			aumentarSaldoFacturas(Constantes.PAGODEMENOS, importe);
	        			//Para Meeting point la descripcion es la misma que el identificador
	        			Factura factura = new Factura(Constantes.PAGODEMENOS,identificador,importe.replace("-", ""),definicion);
	        			server.info("Añadida la factura del tipo " + Constantes.PAGODEMENOS + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + importe );
	        			meetingPoint.addFactura(factura);
	        		}else {
	        			aumentarSaldoFacturas(Constantes.PAGODEMAS, importe);
	        			//Para Meeting point la descripcion es la misma que el identificador
	        			Factura factura = new Factura(Constantes.PAGODEMAS,identificador,importe,definicion);
	        			server.info("Añadida la factura del tipo " + Constantes.PAGODEMAS + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + importe );
	        			meetingPoint.addFactura(factura);
	        		}
				}
        	}
        	if(linea.contains("total") && linea.contains("Sum")) {
        		importeTotal=split[split.length-1];
        		String importeTotalAux = importeTotal.replace(".", "");
        		importeTotalAux = importeTotalAux.replace(",", ".");
        		server.info("Importe Total: "+importeTotal);
        		meetingPoint.setImporte(importeTotalAux);
        	}
        	if(!importeTotal.equals("") && linea.contains(importeTotal)){
        		for(int i=0;i<split.length;i++) {
        			if(split[i].matches("\\d{2}\\.\\d{2}\\.\\d{4}")) {
        				fecha=split[i];
        				break;
        			}
        		}
        		server.info("La fecha es: "+fecha);
        	}
        }

        sumatorios.forEach((k,v) -> server.info("Key: " + k + ": Value: " + v));
        meetingPoint.setSumatorios(sumatorios);
        meetingPoint.setSociedad(getSociedad());
        meetingPoint.setTtooDeudor(super.getTtooCuentaDeudor());
        meetingPoint.setTtooAcreedor(super.getTtooCuentaAcreedor());
        meetingPoint.setNombreTuroperador(getTouroperadorName());
        meetingPoint.setNombreDocumento(getNombreFichero());
        if(!fecha.equalsIgnoreCase("")) {
        	meetingPoint.setFecha(fecha);
        }
        else {
        	meetingPoint.setFecha(super.getFecha());
        }
        meetingPoint.setOtros(calcularOtros(Constantes.MEETINGPOINT,meetingPoint.getImporte(), listaCasuisticas, meetingPoint.getSaldosDeposito()));
        return meetingPoint;		
	}

	private Double stringToNumber(String valor) {
		String regexMilComa = "\\d{1,3}(,\\d{3})*(\\.\\d+)(-|)?";
		String regexMilPunto = "\\d{1,3}(.\\d{3})*(\\,\\d+)(-|)?";
		String regexComa = "\\d+(\\,\\d+)(-|)?";
		if(valor.matches(regexMilComa)) {
			valor = valor.replace(",","");
		}else if(valor.matches(regexMilPunto)) {
			valor = valor.replace(".", "");
			valor = valor.replace(",", ".");
		}else if(valor.matches(regexComa)) {
			valor = valor.replace(",", ".");
		}
		if(valor.contains("-")) {
			valor = valor.replace("-", "");
			return Double.valueOf(valor)*(-1);
		}else {
			return Double.valueOf(valor);
		}
	}
	
	@Override
	public CartaPago procesarCartaPagoWord(String text, List<Casuistica> listaCasuisticas) {
		return null;
	}

	@Override
	public CartaPago procesarCartaPagoExcel(String text, List<Casuistica> listaCasuisticas) {
		return null;
	}


	@Override
	public CartaPago procesarCartaPagoGenerica(String rutaFichero, List<Casuistica> listaCasuisticas) {
		return null;
	}

}
