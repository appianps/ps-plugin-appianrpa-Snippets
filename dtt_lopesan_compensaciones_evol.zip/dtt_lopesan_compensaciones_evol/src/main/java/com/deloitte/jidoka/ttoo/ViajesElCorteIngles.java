package com.deloitte.jidoka.ttoo;

import java.util.HashMap;
import java.util.List;

import com.deloitte.jidoka.lopesan.cartapago.CartaPago;
import com.deloitte.jidoka.lopesan.cartapago.Casuistica;
import com.deloitte.jidoka.lopesan.cartapago.Constantes;
import com.deloitte.jidoka.lopesan.cartapago.Factura;
import com.novayre.jidoka.client.api.IJidokaServer;

public class ViajesElCorteIngles extends Touroperador {

	public ViajesElCorteIngles(IJidokaServer<?> server, String sociedad,  List<String> codigosDeudor, String ttooCuentaAcreedor, String ttooName, String nombreFichero,
			HashMap<String, Double> sumatorios)  {
		super(server, sociedad, codigosDeudor, ttooCuentaAcreedor, ttooName, nombreFichero, sumatorios);
	}


	@Override
	public CartaPago procesarCartaPagoPDF(String text, List<Casuistica> listaCasuisticas) {

		server.info("Entra en Procesar Carta Pago");
		CartaPago viajesElCorteIngles = new CartaPago();
		String [] ings = text.replaceAll("\n", "").replaceAll("\r", "").toUpperCase().split("<BR>");
		String fecha="";
		server.info("Numero de lineas del correo: " +ings.length);
		boolean totalCaptured=false;
		for (String linea: ings) {
			linea=linea.replaceAll("<[^>]+>", " ");
			linea=linea.replaceAll("\\*", "");
			linea=linea.trim();
			String[] splits = linea.split(" ");
			boolean importeEncontrado=false;
			String importe="";
			String identificador="";
			String descripcion="";
			for(String split:splits) {
				if (split.matches("(-|)(\\d{1,3}(\\.|\\,))*\\d{2}")) {
					importe=split;
					importeEncontrado=true;
				}
			}
			if(importeEncontrado) {
				for(Casuistica casuistica : listaCasuisticas) {
					String tipo = casuistica.getTipo();
					List<String> casos = casuistica.getValores();
					for(String caso : casos) {        			
	        			if(linea.contains(caso.toUpperCase()) && splits.length >=2 && !caso.equalsIgnoreCase("-") && importeEncontrado) {
	            			identificador=linea.replaceAll(importe, "").trim();
	            			for(String split:splits) {
	        					if (split.matches("\\d+[A-z]{3}\\d+")) {
	        						identificador=split.replaceAll(caso, "/"+caso);
	        						descripcion=identificador;
	            					break;
	    						}
	        				}
	            			if (facturaAllreadyExist(viajesElCorteIngles, identificador)) {
	    						Double resultado = null;
	    						for (Factura factura:viajesElCorteIngles.getFacturas()) {
	    							if (identificador.equals(factura.getIdentificador())){
	    								aumentarSaldoFacturas(tipo,importe);
	    								resultado=Double.sum(stringToNumber(factura.getImporte()),stringToNumber(importe));
	    								factura.setImporte(String.format("%.2f",resultado));
	    								server.info("Actualizada la factura del tipo " + tipo + " con codigo " + identificador + " con importe " + factura.getImporte());
	    								break;
	    							}
	    						}
	    					}else {
	    						server.info("Añadida la factura del tipo " + tipo + " con codigo " + identificador + " con importe " + importe);
		        				aumentarSaldoFacturas(tipo,importe);
		    					Factura factura = new Factura(tipo,identificador,importe,descripcion);
		    					viajesElCorteIngles.addFactura(factura);
		        			}
            			}
	        		}
	        	}
				if (linea.toUpperCase().contains("TOTAL:") && totalCaptured==false) {
					String importeTotal = splits[splits.length-1].replaceAll("\\*", "");
					importeTotal = importeTotal.replaceAll("\\.", "");
					server.info("Importe total tras cambio de puntos: " + importeTotal);
					importeTotal = importeTotal.replaceAll("\\,", "\\.");	
					server.info("El importe total tras cambio completo: " + importeTotal);
					viajesElCorteIngles.setImporte(importeTotal);
					totalCaptured=true;
				}
				
			}
			if(linea.toUpperCase().contains("FECHA TRANSFERENCIA")){
				if(linea.contains("/")) {
					fecha=getMatch("\\d{2}\\/\\d{2}\\/\\d{4}", linea);
				}
				else if(linea.contains("-")) {
					fecha=getMatch("\\d{2}\\-\\d{2}\\-\\d{4}", linea);
				}
        		fecha = fecha.replaceAll("/", ".");
        		fecha = fecha.replaceAll("-", ".");
        		server.info("La fecha es: "+fecha);
        		
        	}
		}
		sumatorios.forEach((k,v) -> server.info("Key: " + k + ": Value: " + v));
		viajesElCorteIngles.setSumatorios(sumatorios);
		viajesElCorteIngles.setSociedad(getSociedad());
		viajesElCorteIngles.setTtooDeudor(getTtooCuentaDeudor());
		viajesElCorteIngles.setTtooAcreedor(getTtooCuentaAcreedor());
		viajesElCorteIngles.setNombreTuroperador(getTouroperadorName());
		viajesElCorteIngles.setNombreDocumento(getNombreFichero());
		
		if(!fecha.equalsIgnoreCase("")) {
			viajesElCorteIngles.setFecha(fecha);
        }
        else {
        	viajesElCorteIngles.setFecha(super.getFecha());
        }
		viajesElCorteIngles.setOtros(calcularOtros(Constantes.VIAJESELCORTEINGLES, viajesElCorteIngles.getImporte(), listaCasuisticas,viajesElCorteIngles.getSaldosDeposito()));
		return viajesElCorteIngles;
	}


	@Override
	public CartaPago procesarCartaPagoWord(String text, List<Casuistica> listaCasuisticas) {
		return null;
	}

	@Override
	public CartaPago procesarCartaPagoExcel(String text, List<Casuistica> listaCasuisticas) {
		return null;
	}
	
	private boolean facturaAllreadyExist(CartaPago cartaPago, String identificador) {
		for (Factura factura:cartaPago.getFacturas()) {
			if (identificador.equals(factura.getIdentificador())){
				return true;
			}
		}
		return false;
	}
	
	private Double stringToNumber(String valor) {
		String regexMilComa = "(-|)\\d{1,3}(,\\d{3})*(\\.\\d+)?";
		String regexMilPunto = "(-|)\\d{1,3}(.\\d{3})*(\\,\\d+)?";
		String regexComa = "(-|)\\d+(\\,\\d+)?";
		if(valor.matches(regexMilComa)) {
			valor = valor.replace(",","");
		}else if(valor.matches(regexMilPunto)) {
			valor = valor.replace(".", "");
			valor = valor.replace(",", ".");
		}else if(valor.matches(regexComa)) {
			valor = valor.replace(",", ".");
		}
		if(valor.contains("-")) {
			valor = valor.replace("-", "");
			return Double.valueOf(valor)*(-1);
		}else {
			return Double.valueOf(valor);
		}
	}


	@Override
	public CartaPago procesarCartaPagoGenerica(String rutaFichero, List<Casuistica> listaCasuisticas) {
		// TODO Auto-generated method stub
		return null;
	}
}
