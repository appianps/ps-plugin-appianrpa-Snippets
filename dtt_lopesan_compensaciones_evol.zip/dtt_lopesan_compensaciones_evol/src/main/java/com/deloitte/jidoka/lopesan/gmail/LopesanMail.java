package com.deloitte.jidoka.lopesan.gmail;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;
import javax.mail.search.FlagTerm;

import org.apache.commons.lang3.StringUtils;

import com.deloitte.jidoka.lopesan.config.RobotParameters;
import com.deloitte.jidoka.lopesan.exceptions.BusinessException;
import com.deloitte.jidoka.lopesan.exceptions.SystemException;
import com.lowagie.text.pdf.ByteBuffer;
import com.novayre.jidoka.client.api.IJidokaServer;
import com.novayre.jidoka.client.api.execution.IUsernamePassword;

import ch.qos.logback.classic.net.SyslogAppender;


public class LopesanMail {

	protected IJidokaServer<?> server;
	
	
	//Nombre del fichero y TTOO
	private HashMap<String, String> cartasDePago;
	
	private HashMap<String, String> rutaYCuerpo;
	
	private HashMap<String, String> generico;
	
	private int numCorreos;
	
	Message msg;
	
	
	public LopesanMail(IJidokaServer<?> server) {
		this.server = server;
		this.cartasDePago = new HashMap<String,String>();
		this.rutaYCuerpo = new HashMap<String,String>();
		this.generico = new HashMap<String,String>();
		numCorreos=0;
	}
	
	public void leerCorreo(RobotParameters robotParameters, String carpeta) throws BusinessException, SystemException {
		server.info("Inicio Leer Correo");
		
//		String aplicacionCredencialEndesa = parametros.getCredencialWebEndesa();
//		IUsernamePassword credencialWebEndesa = server.getCredentials(aplicacionCredencialEndesa).get(0);
		String email = robotParameters.getEmailCredentials();
		IUsernamePassword credencialesEmail = server.getCredentials(email).get(0);
		
		
		
//		final String email_id = robotParameters.getLopesanEmailUsername();
//		final String password = robotParameters.getLopesanEmailPassword();
		final String email_id = credencialesEmail.getUsername();
		final String password = credencialesEmail.getPassword();
		
		

		//set properties 
		Properties properties=new Properties();
		//You can use imap or imaps , *s -Secured
		properties.put("mail.store.protocol", "imaps");
		//Host Address of Your Mail
		properties.put("mail.imaps.host", "imap.gmail.com");
		//Port number of your Mail Host
		properties.put("mail.imaps.port", "993");
		
		//create a session  
		Session session = Session.getDefaultInstance(properties, null);
		//SET the store for IMAPS
		Store store;
		try {
			store = session.getStore("imaps");
			server.info("Connection initiated......");
			//Trying to connect IMAP server
			store.connect(email_id,password);
			server.info("Connection is ready :)");
			
			//Get inbox folder 
			Folder inbox = store.getFolder(carpeta);
			//SET readonly format (*You can set read and write)
			inbox.open(Folder.READ_WRITE);
			
			
			//Inbox email count
			int messageCount = inbox.getMessageCount(); 
			server.info("Total Messages in "+carpeta +" :- " + messageCount);
			
			
			


            Message[] arrayMessages = inbox.search(new FlagTerm(new Flags(
                    Flags.Flag.SEEN), false));
            server.info("No. of Unread Messages : " + arrayMessages.length);
			
            if(arrayMessages.length>0 && numCorreos <=0) {
            	//Esto lo ponemos para que solo tome un correo aunque haya ,as
	            msg = arrayMessages[0];
	            numCorreos = numCorreos + arrayMessages.length;
	            server.info("Hay acumulados " + numCorreos + " correos");
            	
    			
                String subject = msg.getSubject();
                String receivedDate = msg.getReceivedDate().toString();


   			  String contentType = msg.getContentType();
                 String messageContent = "";
                 
                 String attachFiles = "";
                 String saveDirectory = "C:\\Lopesan\\temporal";
                
                 if(Paths.get(saveDirectory).toFile().exists()) {
                	 Paths.get(saveDirectory).toFile().delete();
                 }
                 Paths.get(saveDirectory).toFile().mkdirs();
                 
                 if (contentType.contains("multipart")) {
                     // content may contain attachments
                     Multipart multiPart = (Multipart) msg.getContent();
                     int numberOfParts = multiPart.getCount();
                     for (int partCount = 0; partCount < numberOfParts; partCount++) {
                         MimeBodyPart part = (MimeBodyPart) multiPart
                                 .getBodyPart(partCount);
                         if (Part.ATTACHMENT.equalsIgnoreCase(part
                                 .getDisposition())) {
                             // this part is attachment
                             String fileName = MimeUtility.decodeText(part.getFileName());
                             
                             server.info("File name: " + fileName);
                             
                             
                           
                             
                             if(!fileName.endsWith(".png") && !fileName.endsWith(".csv")) {
                            	 attachFiles += fileName + ", ";
                                 server.info("AttachFiles:" + attachFiles);
                                 part.saveFile(saveDirectory + File.separator + fileName);
                                 if(carpeta.equalsIgnoreCase("INBOX")) {
                                	 generico.put(saveDirectory + File.separator + fileName, carpeta);
                                 }else {
                                	 cartasDePago.put(saveDirectory + File.separator + fileName,carpeta);
                                     rutaYCuerpo.put(saveDirectory + File.separator + fileName, messageContent);
                                 } 
                             }
                             else if(fileName.endsWith(".png")) {
                            	 marcarComoLeido();
                            	 server.warn("Hay un fichero adjunto erroneo");
                            	 throw new BusinessException("Esta carta de pago contiene imagen, no se puede continuar", "fin", false);
                             }


                             
                             
                         } else {
                             // this part may be the message content
                             messageContent = part.getContent().toString();
                             
                         }
                     }
                     if (attachFiles.length() > 1) {
                         attachFiles = attachFiles.substring(0,
                                 attachFiles.length() - 2);
                     }
                 } else if (contentType.contains("text/plain")
                         || contentType.contains("text/html")) {
                     Object content = msg.getContent();
                     if (content != null) {
                         messageContent = content.toString();
                     }
                 }

                 if(attachFiles.equalsIgnoreCase("")) {
                	 String fileName = saveDirectory+ File.separator +receivedDate.replaceAll(":", "")+"-"+subject.replaceAll("\\W+","_")+".html";
                	 server.info("No hay adjuntos");
                	 server.info("Ruta del correo en: "+fileName);
                	 createNewFile(fileName,messageContent);
                	 cartasDePago.put(fileName,carpeta);
                	 rutaYCuerpo.put(fileName, messageContent);
                 }
                 else {
                	 server.info(attachFiles);
                 }
                 //msg.setFlag( Flags.Flag.SEEN, false);
            }
            else {
            	 server.info("Ya habia " + numCorreos + " correos sin procesar " + " y sumamos ahora " + arrayMessages.length);
            	 numCorreos = numCorreos + arrayMessages.length;
            }
			
			
		} catch (javax.mail.NoSuchProviderException e) {
			server.warn(e);
		} catch (MessagingException e) {
			server.warn(e);
			if(e.getMessage().contains("failed to connect")) {
				throw new SystemException("No se ha podido conectar", null, "", false);
				
			}
		} catch (IOException e) {
			server.warn(e);
		}
	}
	
	public HashMap<String, String> getCartasDePago() {
		return this.cartasDePago;
	}
	
	public HashMap<String, String> getRutaYCuerpo(){
		return this.rutaYCuerpo;
	}
	
	public HashMap<String, String> getGenerico(){
		return this.generico;
	}
	
	public void enviarCorreo(RobotParameters robotParam,String correoDestino, String asunto, String cuerpo, String adjunto) {
		server.info("Correo de destino: " + correoDestino);
		server.info("Asunto: " + asunto);
		server.info("Cuerpo: " + cuerpo);
		server.info("Ruta adjunto: " + adjunto);
		String email = robotParam.getEmailCredentials();
		IUsernamePassword credencialesEmail = server.getCredentials(email).get(0);
		
		final String username = credencialesEmail.getUsername();
		final String password = credencialesEmail.getPassword();
		
		
//		final String username = robotParam.getLopesanEmailUsername();
//		final String password = robotParam.getLopesanEmailPassword();

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props,
		  new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		  });

		try {

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(username));//robotParam.getLopesanEmailUsername()));
			message.setRecipients(Message.RecipientType.TO,
				InternetAddress.parse(correoDestino));
			message.setSubject(asunto);
			
			 Multipart multipart = new MimeMultipart();
				
			//parte cuerpo: mensaje con html
			 MimeBodyPart textBodyPart = new MimeBodyPart();
		     textBodyPart.setText(cuerpo, "utf-8", "html");
			 
			//parte adjunto
		     if(Paths.get(adjunto).toFile().exists()) {
			    MimeBodyPart attachmentBodyPart = new MimeBodyPart();
				DataSource source = new FileDataSource(adjunto); //Ruta del adjunto
				attachmentBodyPart.setDataHandler(new DataHandler(source));
				String[] nombre = adjunto.split("\\\\");
				String nombreFichero = nombre[nombre.length-1];
				server.info("Nombre del fichero a adjuntar " + nombreFichero);
				attachmentBodyPart.setFileName(nombreFichero);//Nombre del fichero adjunto
								
				multipart.addBodyPart(attachmentBodyPart); //anade adjunto
			    
		     }
		     multipart.addBodyPart(textBodyPart); //anade cuerpo texto 
		     message.setContent(multipart);
		     Transport.send(message);

			System.out.println("Done");

		} catch (MessagingException e) {
			throw new RuntimeException("ERROR "  +e);
		}
	}
	
	private static void createNewFile(String path, String text) throws IOException {
		File file=new File(path);
		if (!file.exists()) {
			file.createNewFile();
		}
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file.getAbsoluteFile()));) {
        	 writer.write(text);
             if(writer!=null) {
                 writer.close();
             }
        }
        catch(IOException e) {
        	throw e;
        }
       
	}
	
	public int getNumCorreos() {
		return this.numCorreos;
	}
	
	public void marcarComoLeido() throws MessagingException {
		msg.setFlag( Flags.Flag.SEEN, true);
	}
}
