package com.deloitte.jidoka.lopesan.transaccion.SAP;


//TODO: Mover transaccion a robot maestro cuando se arreglen las ramas de EMPARK

/**
 * The Enum ESapTransaction.
 */
public class TSap_EDGE_IDCTOOL {
	
	/**
	 * SAP transaction.
	 */
	public static final String TRANSACTION_NAME = "/N/EDGE/IDCTOOL";
	
	
	
	public static final class windowBHCMToolboxGFSSv5{
		
		// hay que poner el nombre de la pantalla de SAP
		public static final String NAME = "B\\+ HCM Toolbox GFSS v5";
		
		// boton ejecutar para cuando rellenemos el campo, darle a ejecutar
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
		public static final String BUTTON_EJECUTAR = "tbar[1]/btn[8]";
		
		// S:\\REDSILTRA\SVA\Msjrec\ archivo que queremos
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String CTEXT_RUTA_ARCHIVO = "ctxtS_FILE1";
		
	}
	
	public static final class shell{
		
		// cntlALV_CONTAINER_1/shellcont/shell  aqui tenemos 2 cuando tenga acceso comprobar si la posicion 1 o 2
		/** <b>Type: </b> GuiShell <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String SHELLCONT_SHELL_DISCREPANCIAS = "subSUBSCREEN:SAPLHRPADPAL00:0101/cntlSAPLSBAL_DISPLAY_CONTAINER/shellcont/shell/shellcont[0]/shell";
		
		/** <b>Type: </b> GuiShell <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String SHELLCONT_SHELL_EXPORTAR = "subSUBSCREEN:SAPLHRPADPAL00:0101/cntlSAPLSBAL_DISPLAY_CONTAINER/shellcont/shell/shellcont[1]/shell";
		//public static final String SHELL_2 = "subSUBSCREEN:SAPLHRPADPAL00:0101/cntlSAPLSBAL_DISPLAY_CONTAINER/shellcont/shell/shellcont[1]/shell";
		
		
		public static final String BUTTON_EXPORTAR= "&MB_EXPORT";
		
		public static final class action{
			/** <b>VBS Script: </b> session.findById("shellcont/shell").doubleClickItem = "01     5301", "001" */
			//public static final String doubleClickItem = "doubleClickItem";
			/** <b>VBS Script: </b> session.findById("shellcont/shell").pressToolBarContextButton = "&MB_EXPORT" */
			public static final String pressToolBarContextButton = "pressToolBarContextButton";
			public static final String selectContextMenuItem = "selectContextMenuItem";	
			
			
			
		}
	}
	
	public static final class popUpSelectType{
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[1]/usr */
		public static final String RBUTTON_XLSX = "radRB_OTHERS";
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[1]/usr */
		public static final String CONTEXT_XLSX_NAME = "cmbG_LISTBOX";
		
	}
	
	public static final class popUpImportarFichero{
		
		public static final String NAME = "Importar fichero";
		
		public static final String BUTTON_CONTINUAR= "tbar[0]/btn[0]";
		
		public static final String CTEXT_DIRECTORIO= "ctxtDY_PATH";
		public static final String CTEXT_NOMBRE_FICHERO= "ctxtDY_FILENAME";
		
	}
	
	
	
	

}
