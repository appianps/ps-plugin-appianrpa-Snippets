package com.deloitte.jidoka.ttoo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.deloitte.jidoka.lopesan.cartapago.CartaPago;
import com.deloitte.jidoka.lopesan.cartapago.Casuistica;
import com.deloitte.jidoka.lopesan.cartapago.Constantes;
import com.novayre.jidoka.client.api.IJidokaServer;

public abstract class Touroperador {

	protected IJidokaServer<?> server;

	private String sociedad;

	private List<String> codigosDeudor;

	private String ttooCuentaAcreedor;

	private String ttooName;

	private String nombreFichero;

	protected Map<String, Double> sumatorios;

	private String fecha;

	public Touroperador(IJidokaServer<?> server, String sociedad, List<String> codigosDeudor, String ttooCuentaAcreedor,
			String ttooName, String nombreFichero, Map<String, Double> sumatorios) {
		this.server = server;
		this.sociedad = sociedad;
		this.codigosDeudor = codigosDeudor;
		this.ttooCuentaAcreedor = ttooCuentaAcreedor;
		this.ttooName = ttooName;
		this.nombreFichero = nombreFichero;
		this.sumatorios = sumatorios;
		Date ahora = new Date();
		final SimpleDateFormat dateFormatDd = new SimpleDateFormat("dd");
		final SimpleDateFormat dateFormatMm = new SimpleDateFormat("MM");
		final SimpleDateFormat dateFormatYy = new SimpleDateFormat("yyyy");
		String dia = dateFormatDd.format(ahora);
		String mes = dateFormatMm.format(ahora);
		String anno = dateFormatYy.format(ahora);
		this.fecha = dia + "." + mes + "." + anno;
	}

	public abstract CartaPago procesarCartaPagoPDF(String text, List<Casuistica> listaCasuisticas);

	public abstract CartaPago procesarCartaPagoWord(String text, List<Casuistica> listaCasuisticas);

	public abstract CartaPago procesarCartaPagoExcel(String text, List<Casuistica> listaCasuisticas);

	public abstract CartaPago procesarCartaPagoGenerica(String rutaFichero, List<Casuistica> listaCasuisticas);

	protected Double calcularOtros(String nombreTTOO, String importe, List<Casuistica> casuisticas, List<String> depositos) {
		server.info("Inicio de calcular otros con importe: " + importe);
		boolean esNegativo= false;
		boolean hayDeposito = false;
		if(importe.contains("-")) {
			importe.replaceAll("-", "");
			esNegativo = true;
		}
//		importe = importe.replaceAll("-", "");
//		importe = importe.replaceAll(".", "");
//		importe = importe.replaceAll(",", ".");
//		server.info("Importe tras replace: " + importe);
		
		//Esto se hace, porque si hay deposito, todo tiene que restarse de los depositos
		//En cambio si no hay deposito, tiene que restarse del total del importe.
		double otros = 0.0d;
		
		for(String deposito: depositos) {
			hayDeposito=true;
			server.info("El deposito es: " + deposito);
			Double depoDinero = 0.0d;
			deposito = deposito.replaceAll("-", "");
			depoDinero = Math.round(Double.valueOf(deposito) * 100) / 100d;
			//Los depositos siempre tienen que ser vacios
			otros += depoDinero;
			otros = Math.round(Double.valueOf(otros) * 100) / 100d;
		}
		if(!hayDeposito) {
			otros = Math.round(Double.valueOf(importe) * 100) / 100d;
		}
		if(esNegativo) {
			otros = otros * -1;
		}
		for (Casuistica casu : casuisticas) {

			Double casuDinero = 0.0d;
			if ((casu.getTipo().equalsIgnoreCase(Constantes.ABONODESCONTADO)
					&& !nombreTTOO.equalsIgnoreCase(Constantes.JET2HOLIDAYS)
					&& !nombreTTOO.equalsIgnoreCase(Constantes.VIAJESCANARIASEUROPA)
					&& !nombreTTOO.equalsIgnoreCase(Constantes.MEETINGPOINT))
					|| (casu.getTipo().equalsIgnoreCase(Constantes.DEDUCCION)
							&& !nombreTTOO.equalsIgnoreCase(Constantes.TUINETHERLAND)
							&& !nombreTTOO.equalsIgnoreCase(Constantes.JET2HOLIDAYS)
							&& !nombreTTOO.equalsIgnoreCase(Constantes.VIAJESCANARIASEUROPA)
							&& !nombreTTOO.equalsIgnoreCase(Constantes.VIAJESELCORTEINGLES)
							&& !nombreTTOO.equalsIgnoreCase(Constantes.MEETINGPOINT)
							&& !nombreTTOO.equalsIgnoreCase(Constantes.TUI_UK)) // ??? new problemas tui uk 3 calidad
					|| (casu.getTipo().equalsIgnoreCase(Constantes.PAGODEMENOS)
							&& !nombreTTOO.equalsIgnoreCase(Constantes.TUINETHERLAND)
							&& !nombreTTOO.equalsIgnoreCase(Constantes.JET2HOLIDAYS)
							&& !nombreTTOO.equalsIgnoreCase(Constantes.MEETINGPOINT)
							&& !nombreTTOO.equalsIgnoreCase(Constantes.THOMAS_COOK)
							&& !nombreTTOO.equalsIgnoreCase(Constantes.TUI_UK))) {
				casuDinero = sumatorios.get(casu.getTipo()) * -1;
			} else {
				casuDinero = sumatorios.get(casu.getTipo());
			}
			server.info("La casuistica es " + casu.getTipo() + " el acumulado que queda es " + otros + " y se le resta "
					+ casuDinero);
			otros -= casuDinero;
			otros = Math.round(Double.valueOf(otros) * 100) / 100d;
			
		}
		if(sumatorios.get(Constantes.DEPOSITO) !=null) {
			server.info("Hay un sumatorio de tipo "  + Constantes.DEPOSITO + " por valor de " + sumatorios.get(Constantes.DEPOSITO));
			otros -=sumatorios.get(Constantes.DEPOSITO);
		}
		
		if(hayDeposito) {
			otros = otros * -1;
		}
		server.info("Queda " + otros);
		return otros;

	}

	protected void aumentarSaldoFacturas(String clave, String valor) {

		try {
			// Primer comprobamos si el valor es negativo
			// Esto suele suceder todas las veces que recibimos algo con el signo -,
			// ya sea delante o detras del numero, o los valores entre parentesis
			if (clave.equalsIgnoreCase(Constantes.PAGODIFERENCIAFACTURA)) {
				server.info("Ha habido una diferencia en factura con clave " + clave + " y con valor " + valor);
				clave = Constantes.FACTURA;
			}
			boolean negativo = false;
			if (valor.contains("-") || valor.contains("(") || valor.contains(")")) {
				server.info("Hay valor negativo y es " + valor);
				valor = valor.replace("-", "");
				valor = valor.replace("(", "");
				valor = valor.replace(")", "");
				negativo = true;
			}
			double numero = 0.0d;
			if(!clave.equalsIgnoreCase("DEPOSITO")) {
				numero = sumatorios.get(clave);
			}
			else {
				clave = "DEPOSITO";
			}
			

			// caso para la coma como miles, y el punto para decimales
			// /^\d{1,3}(,\d{3})*(\.\d+)?$/
			String regexMilComa = "^\\d{1,3}(,\\d{3})*(\\.\\d+)?";
			String regexMilPunto = "^\\d{1,3}(.\\d{3})*(\\,\\d+)?";
			String regexComa = "^\\d+(\\,\\d+)?";
			if (valor.matches(regexMilComa)) {
				valor = valor.replace(",", "");
			} else if (valor.matches(regexMilPunto)) {
				valor = valor.replace(".", "");
				valor = valor.replace(",", ".");
			} else if (valor.matches(regexComa)) {
				valor = valor.replace(",", ".");
			} else {
				server.info("No pasa por ningun filtro " + valor);
			}
			// caso para el punto como miles, y la coma para decimales
			// /^\d{1,3}(.\d{3})*(\,\d+)?$/

			double numero2 = Double.valueOf(valor);

			if (negativo) {
				server.info(
						"El sumatorio de la clave " + clave + " es " + numero + " y ahora vamos a restar " + numero2);
				numero -= numero2;

			} else {
				server.info(
						"El sumatorio de la clave " + clave + " es " + numero + " y ahora vamos a sumar " + numero2);
				numero += numero2;

			}
			numero = Math.round(numero * 100) / 100d;
			this.sumatorios.put(clave, numero);

		} catch (NumberFormatException e) {
			server.error(e);
			server.info("El valor es " + valor);
			server.info("El valor asociado a la clave " + clave + " es " + sumatorios.get(clave));
			throw new NumberFormatException();
		}
	}

	protected String getMatch(String regex, String inputText) {
		String match = "";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(inputText);
		if (matcher.find()) {
			match = matcher.group();
		}
		return match;
	}

	protected String formatDate(String inputDate, String inputFormat, String outputFormat,Locale locale) throws ParseException {	
		SimpleDateFormat initFormat = new SimpleDateFormat(inputFormat,locale);
		SimpleDateFormat outFormat = new SimpleDateFormat(outputFormat);
		Date date = initFormat.parse(inputDate);
		String outputDate=outFormat.format(date);
		return outputDate;	
	}
	
	public String getSociedad() {
		return this.sociedad;
	}

	public String getTouroperadorName() {
		return this.ttooName;
	}

	public String getNombreFichero() {
		return this.nombreFichero;
	}

	public Map<String, Double> getSumatorios() {
		return this.sumatorios;
	}

	public List<String> getTtooCuentaDeudor() {
		return codigosDeudor;
	}

	public String getTtooCuentaAcreedor() {
		return ttooCuentaAcreedor;
	}

	public String getTtooName() {
		return ttooName;
	}

	public String getFecha() {
		return fecha;
	}
	


}
