package com.deloitte.jidoka.lopesan.config;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;


public class CeldasUtils {

	/**
	 * Recupera el valor de la celda indicada en un String teniendo en cuenta si son números, textos o fechas
	 * 
	 * @param cell
	 * @return
	 */
	public String valorCelda(Cell cell) {
		String result = "";
		if (cell != null) {
			switch (cell.getCellType()) {
			case STRING:
				result = cell.getStringCellValue();
				if (result.contains("Ñ")) {
					String pos = obtainEne(result, 'Ñ');
					result = StringUtils.stripAccents(result);
					if (!pos.equals("")) {
						result = replaceEne(result, 'Ñ', pos);
					}
				} else if (result.contains("ñ")) {
					String pos = obtainEne(result, 'ñ');
					result = StringUtils.stripAccents(result);
					if (!pos.equals("")) {
						result = replaceEne(result, 'ñ', pos);
					}
				} else {
					if (result.contains("`")) {
						result = result.replace("`", " ");
					}
					if (result.contains("'")) {
						result = result.replace("'", " ");
					}
					if (result.contains("´")) {
						result = result.replace("´", " ");
					}
					result = StringUtils.stripAccents(result);
				}
				if (cell.getCellStyle().getDataFormat() == 4) {
					result = procesarNumero(cell, false, false);
				}
				break;
			case NUMERIC:
				if (DateUtil.isCellDateFormatted(cell)) {
					SimpleDateFormat dt1 = new SimpleDateFormat("dd.MM.yyyy");
					result = String.valueOf(dt1.format(cell.getDateCellValue()));
				} else if (cell.getCellStyle().getDataFormat() == 10 || cell.getCellStyle().getDataFormat() == 9) {
					result = procesarNumero(cell, true, true);
				} else if(cell.getCellStyle().getDataFormat() == 0) {
					result = procesarNumero(cell, true, false);
				}else {
					result = procesarNumero(cell, true, false);
				}
				break;
			case ERROR:
				result = "";
				break;
			case FORMULA:

					CellType k = cell.getCachedFormulaResultType();
					if(k.equals(CellType.STRING)) {
			                result = cell.getStringCellValue();
			                break;
					}
					else {
						short dataFormat = cell.getCellStyle().getDataFormat();
						switch (dataFormat) {
							case 0:
								result = "SUM="+procesarNumero(cell, true, false).trim();
								break;
							case 4:
								result = "SUM="+procesarNumero(cell, true, false); 
								
								
								break;
							case 9:
								result = "SUM="+procesarNumero(cell, true, false).trim();
								break;
							case 10:
								result = "SUM="+procesarNumero(cell, true, false).trim();
								break;
							case 14:
								//Supuestamente este caso es solo para la fecha del caso generico							
								result = procesarNumero(cell, true, false).trim();
								Date javaDate= DateUtil.getJavaDate(Double.parseDouble(result));
							    result = new SimpleDateFormat("dd.MM.yyyy").format(javaDate);
								break;
							case 164:
								result = "SUM="+procesarNumero(cell, true, false).trim();
								break;
							case 165:
								result = "SUM="+procesarNumero(cell, true, false).trim();
								break;
							default:
								result = cell.getStringCellValue();
								break;
						}
					break;
					}

			default:
				result = cell.getStringCellValue();
				break;
			}

		}
		if (result.contains("- Seleccionar") || result.contains("- Select")) {
			result = "";
		}
		return result.trim();
	}

	private static String obtainEne(String result, Character search) {
		String valor = "";

		for (int i = 0; i < result.length(); i++) {
			if (result.charAt(i) == search) {
				if (valor.equals("")) {
					valor = String.valueOf(i);
				} else {
					valor += "," + String.valueOf(i);
				}
			}
		}
		return valor;
	}

	private static String replaceEne(String result, Character search, String pos) {
		String[] aux = pos.split(",");
		for (int i = 0; i < aux.length; i++) {
			result = result.substring(0, Integer.parseInt(aux[i])) + search + result.substring(Integer.parseInt(aux[i]) + 1);
		}
		return result;
	}

	private static String procesarNumero(Cell cell, boolean formatNumeric, boolean porcentaje) {
		String valor = "";
		if (formatNumeric) {
			BigDecimal b = new BigDecimal(cell.getNumericCellValue());
			valor = b.toPlainString();
			if (porcentaje) {
				b = b.multiply(new BigDecimal(100));
			}

			if (porcentaje || valor.contains(".")) {
				b = b.setScale(2, java.math.BigDecimal.ROUND_HALF_UP);
			}
			valor = b.toPlainString();
		} else {
			valor = cell.getStringCellValue();
		}

		if (valor.contains(".") && valor.contains(",")) {
			if (valor.indexOf(".") < valor.indexOf(",")) {
				valor = valor.replaceAll("\\.", "");
			} else {
				valor = valor.replaceAll(",", "");
				valor = valor.replaceAll("\\.", ",");
			}
		} else if (valor.contains(".")) {
			valor = valor.replaceAll("\\.", ",");
		}
		return valor;
	}
}