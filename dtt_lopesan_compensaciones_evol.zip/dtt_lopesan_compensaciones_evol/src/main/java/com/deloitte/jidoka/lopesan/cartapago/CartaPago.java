package com.deloitte.jidoka.lopesan.cartapago;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CartaPago {
	
	
	private List<Factura> facturas;
	
	private String nombreDocumento;
	private List<String> codigosDeudor;
	private String ttooAcreedor;
	private String sociedad;
	private String carpetaContenedora;
	private String importe;
	private List<String> saldosDeposito;
	//private String saldoDeposito;
	private String fecha;
	private String nombreTuroperador;
	private Map<String, Double> sumatorios;
	private String numeroDocumento;
	private boolean correcto;
	private Double otros;
	

	public CartaPago() {
		facturas = new ArrayList<Factura>();
		sumatorios = new HashMap<String,Double>();
		codigosDeudor = new ArrayList<String>();
		saldosDeposito = new ArrayList<String>();
		correcto = true;
		otros = 0.0d;
		nombreDocumento="";
		ttooAcreedor="";
		sociedad="";
		carpetaContenedora="";
		importe="";
		fecha="";
		nombreTuroperador="";
		numeroDocumento="";
	}


	public List<Factura> getFacturas() {
		return facturas;
	}


	public void setFacturas(List<Factura> facturas) {
		this.facturas = facturas;
	}
	
	public void addFactura(Factura factura) {
		this.facturas.add(factura);
	}


	public String getNombreDocumento() {
		return nombreDocumento;
	}


	public void setNombreDocumento(String nombreDocumento) {
		this.nombreDocumento = nombreDocumento;
	}



	public List<String> getTtooDeudor() {
		return codigosDeudor;
	}


	public void setTtooDeudor(List<String> codigosDeudor) {
		this.codigosDeudor = codigosDeudor;
	}


	public String getTtooAcreedor() {
		return ttooAcreedor;
	}


	public void setTtooAcreedor(String ttooAcreedor) {
		this.ttooAcreedor = ttooAcreedor;
	}


	public String getSociedad() {
		return sociedad;
	}


	public void setSociedad(String sociedad) {
		this.sociedad = sociedad;
	}


	public String getCarpetaContenedora() {
		return carpetaContenedora;
	}


	public void setCarpetaContenedora(String carpetaContenedora) {
		this.carpetaContenedora = carpetaContenedora;
	}


	public String getImporte() {
		return importe;
	}


	public void setImporte(String valor) {
		String regexMilComa = "^\\d{1,3}(,\\d{3})*(\\.\\d+)?";
		String regexMilPunto = "^\\d{1,3}(.\\d{3})*(\\,\\d+)?";
		String regexComa = "^\\d+(\\,\\d+)?";
		if(valor.matches(regexMilComa)) {
			valor = valor.replace(",","");
		}else if(valor.matches(regexMilPunto)) {
			valor = valor.replace(".", "");
			valor = valor.replace(",", ".");
		}else if(valor.matches(regexComa)) {
			valor = valor.replace(",", ".");
		}
		this.importe = valor;
	}
	
	public String getFecha() {
		return this.fecha;
	}
	
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}


	public String getNombreTuroperador() {
		return nombreTuroperador;
	}


	public void setNombreTuroperador(String nombreTuroperador) {
		this.nombreTuroperador = nombreTuroperador;
	}
	
	public Map<String, Double> getSumatorios() {
		return sumatorios;
	}


	public void setSumatorios(Map<String, Double> sumatorios) {
		this.sumatorios = sumatorios;
	}


	public String getSumaCasuistica(String casuistica) {
		
		double k = 0.0;
		for(Factura fact:this.facturas) {
			if(fact.getTipo().equalsIgnoreCase(casuistica)) {
				double s = Double.valueOf(fact.getImporte());
				k=k+s;
			}
		}
		
		return String.valueOf(k);
	}


	public List<String> getSaldosDeposito() {
		return saldosDeposito;
	}


	public void setSaldosDeposito(List<String> saldoDeposito) {
		this.saldosDeposito = saldoDeposito;
	}
	
	public void addSaldoDeposito(String saldoDeposito) {
		this.saldosDeposito.add(saldoDeposito);
	}


	public String getNumeroDocumento() {
		return numeroDocumento;
	}


	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}


	public boolean isCorrecto() {
		return correcto;
	}


	public void setCorrecto(boolean correcto) {
		this.correcto = correcto;
	}
	
	public Double getOtros() {
		return this.otros;
	}
	
	public void setOtros(Double otros) {
		this.otros = otros;
	}
	
}
