package com.deloitte.jidoka.ttoo;

import java.util.HashMap;
import java.util.List;

import com.deloitte.jidoka.lopesan.cartapago.CartaPago;
import com.deloitte.jidoka.lopesan.cartapago.Casuistica;
import com.deloitte.jidoka.lopesan.cartapago.Constantes;
import com.deloitte.jidoka.lopesan.cartapago.Factura;
import com.novayre.jidoka.client.api.IJidokaServer;

public class ThomasCook extends Touroperador {

	public ThomasCook(IJidokaServer<?> server, String sociedad, List<String> codigosDeudor, String ttooCuentaAcreedor, String ttooName, String nombreFichero,
			HashMap<String, Double> sumatorios)  {
		super(server, sociedad, codigosDeudor, ttooCuentaAcreedor, ttooName, nombreFichero, sumatorios);
	}


	@Override
	public CartaPago procesarCartaPagoPDF(String text, List<Casuistica> listaCasuisticas) {

		try {
			server.info("Entra en Procesar Carta Pago");
			CartaPago thomasCook = new CartaPago();
			String [] ings = text.split("\r");
	        server.info("Numero de lineas del pdf: " +ings.length);	
	        boolean casoEncontrado;
			String fecha="";
	        for (String linea: ings) {
	        	linea = linea.replaceAll("\n", "");
	        	String[] split = linea.split(" ");
	        	String identificador="";
	        	String importe="";
	        	boolean contieneImporte=false;
	        	casoEncontrado = false;
	        	//server.info("Linea: " + linea + " de longitud " + linea.length() + " con " + split.length + " splits");
				if(split.length>1 && split[split.length-1].matches("\\d{1,3}(\\.\\d{3})*(\\,\\d{2})(-|)?")) {
					importe=split[split.length-1];
					contieneImporte=true;
				}
				//El mayor que 30 lo ponemos por si lee lineas en las que solo hay precio, todas las lineas que tengan un
				//identificador valido seran muchisimo mas largas, el 30 tra calcuar en una carta de pago cuanto mide 
				//y cuantos splits tiene una linea solo con un precio de 2.804,84- que son 20 de tamaño y 12 splits
				if(contieneImporte && !linea.contains("Total") && !linea.contains("Suma") && !linea.contains("anulaci") &&
						linea.length() > 30) {
					identificador=split[1];
			       	for(Casuistica casuistica : listaCasuisticas) {
		        		//Aqui tendriamos el tipo de casuistica y la lista de string que hay que buscar
		        		String tipo = casuistica.getTipo();
		        		List<String> casos = casuistica.getValores();
		        		for(String caso : casos) {
		        			if(linea.contains(caso) && split.length>3 && !caso.equalsIgnoreCase("-")) {
		        				if(!identificador.matches("\\d+\\/\\w{3}\\d{2}")) {
		        					if (identificador.matches("\\d+\\/\\w{3}\\d+")) {	        						
		        						for (String part:split) {
		        							if (part.trim().matches("\\d{2}\\.\\d{2}\\.\\d{2}")) {        							
		        								identificador=getMatch("\\d+\\/\\w{3}",identificador)+part.substring(6);
		        								break;
		        							}
		        						}
		        					}else {
		        						identificador=linea.replaceAll(importe, "").trim();
		        					}
		        				}
		        				boolean facturaExiste=false;
	        					if (tipo.equalsIgnoreCase(Constantes.FACTURA)){
	        						Double resultado = null;
	    							for (Factura factura:thomasCook.getFacturas()) {
		    							if (identificador.equals(factura.getIdentificador())){
		    								aumentarSaldoFacturas(tipo,importe);
		    								resultado=Double.sum(stringToNumber(factura.getImporte()),stringToNumber(importe));
		    								factura.setImporte(String.format("%.2f",resultado));
		    								server.info("Actualizada la factura del tipo " + tipo + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + factura.getImporte());
		    								facturaExiste=true;
		    								break;
		    							}
		    						}
	        					}
	        					if(!facturaExiste){	        						
	        						aumentarSaldoFacturas(tipo,importe);
	        						Factura factura = new Factura(tipo,identificador,importe,identificador);
	        						thomasCook.addFactura(factura);       
	        						server.info(Constantes.ANADIDAFACTURATIPO + tipo + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + importe);
	        					}
		    					casoEncontrado = true;
		        			}
		    			}
		        	}
			       	if(!casoEncontrado && split.length>4) {
			       		if (identificador.matches("^\\d+(\\/|)\\d{0,2}$")) {
			       			identificador = identificador.replaceAll("\\/\\d{0,2}", "");
			       			boolean facturaExiste=false;
							Double resultado = null;
							for (Factura factura:thomasCook.getFacturas()) {
								if (identificador.equals(factura.getIdentificador())){
									aumentarSaldoFacturas(Constantes.FACTURA,importe);
									resultado=Double.sum(stringToNumber(factura.getImporte()),stringToNumber(importe));
									factura.setImporte(String.format("%.2f",resultado));
									server.info("Actualizada la factura del tipo " + Constantes.FACTURA + " con codigo " + identificador + " con importe " + factura.getImporte());
									facturaExiste=true;
									break;
								}
							}
	    					if(!facturaExiste){	        						
	    						aumentarSaldoFacturas(Constantes.FACTURA,importe);
	    						Factura factura = new Factura(Constantes.FACTURA,identificador,importe,identificador);
	    						thomasCook.addFactura(factura);       
	    						server.info("Añadida la factura del tipo " + Constantes.FACTURA + " con codigo " + identificador + " con importe " + importe);
	    					}
			       		}else {
				       		identificador=linea.replaceAll(importe, "").trim();
			        		if (importe.contains("-")) {	        			
			        			aumentarSaldoFacturas(Constantes.PAGODEMENOS, importe);
			        			Factura factura = new Factura(Constantes.PAGODEMENOS,identificador,importe.replace("-", ""),identificador);
			        			server.info(Constantes.ANADIDAFACTURATIPO + Constantes.PAGODEMENOS + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + importe );
			        			thomasCook.addFactura(factura);
			        		}else {
			        			aumentarSaldoFacturas(Constantes.PAGODEMAS, importe);
			        			Factura factura = new Factura(Constantes.PAGODEMAS,identificador,importe.replace("-", ""),identificador);
			        			server.info(Constantes.ANADIDAFACTURATIPO + Constantes.PAGODEMAS + Constantes.CONCODIGO + identificador + Constantes.CONIMPORTE + importe );
			        			thomasCook.addFactura(factura);
			        		}
		        		}
					}
				}
	        	if(linea.contains("Total") && !linea.contains("facturas") &&  !linea.contains("invoices") && !linea.contains("descuentos/compensaciones") ) {
	        		String importeTotal = split[split.length-1].replace(".", "");
	        		importeTotal = importeTotal.replace(",", ".");
	        		server.info("Importe total: "+importeTotal);
	        		thomasCook.setImporte(importeTotal);
	        	}
	        	if (linea.contains("Carta") && linea.contains("pago") && linea.contains("KR001") && fecha.equals("")) {
	        		fecha=getMatch("\\d{2}\\.\\d{2}\\.\\d{4}", linea);
	        		server.info("La fecha es: "+fecha);
	        	}
	        }
	        
			server.info("Todo calculado, rellenamos el objeto");
	        
	        sumatorios.forEach((k,v) -> server.info("Key: " + k + ": Value: " + v));
	        thomasCook.setSumatorios(sumatorios);
	        thomasCook.setSociedad(getSociedad());
	        thomasCook.setTtooDeudor(super.getTtooCuentaDeudor());
	        thomasCook.setTtooAcreedor(super.getTtooCuentaAcreedor());
	        thomasCook.setNombreTuroperador(getTouroperadorName());
	        thomasCook.setNombreDocumento(getNombreFichero());
	        if(!fecha.equalsIgnoreCase("")) {
	        	thomasCook.setFecha(fecha);
	        }
	        else {
	        	thomasCook.setFecha(super.getFecha());
	        }
	        thomasCook.setOtros(calcularOtros(Constantes.THOMAS_COOK,thomasCook.getImporte(), listaCasuisticas,thomasCook.getSaldosDeposito()));
	        return thomasCook;	
		}
		catch(Exception e) {
			server.error("Falla en lectura PDF thomas cook ",e );
			return null;
		}
	}

	@Override
	public CartaPago procesarCartaPagoWord(String text, List<Casuistica> listaCasuisticas) {
		return null;
	}

	@Override
	public CartaPago procesarCartaPagoExcel(String text, List<Casuistica> listaCasuisticas) {
		return null;
	}


	@Override
	public CartaPago procesarCartaPagoGenerica(String rutaFichero, List<Casuistica> listaCasuisticas) {
		return null;
	}

	private Double stringToNumber(String valor) {
		String regexMilComa = "\\d{1,3}(,\\d{3})*(\\.\\d+)(-|)?";
		String regexMilPunto = "\\d{1,3}(.\\d{3})*(\\,\\d+)(-|)?";
		String regexComa = "\\d+(\\,\\d+)(-|)?";
		if(valor.matches(regexMilComa)) {
			valor = valor.replace(",","");
		}else if(valor.matches(regexMilPunto)) {
			valor = valor.replace(".", "");
			valor = valor.replace(",", ".");
		}else if(valor.matches(regexComa)) {
			valor = valor.replace(",", ".");
		}
		if(valor.contains("-")) {
			valor = valor.replace("-", "");
			return Double.valueOf(valor)*(-1);
		}else {
			return Double.valueOf(valor);
		}
	}
}
