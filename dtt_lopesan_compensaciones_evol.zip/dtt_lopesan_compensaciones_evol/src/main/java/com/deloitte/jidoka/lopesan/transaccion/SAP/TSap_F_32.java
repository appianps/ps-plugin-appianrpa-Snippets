package com.deloitte.jidoka.lopesan.transaccion.SAP;


//TODO: Mover transaccion a robot maestro cuando se arreglen las ramas de EMPARK

/**
 * The Enum ESapTransaction.
 */
public class TSap_F_32 {
	
	/**
	 * SAP transaction.
	 */
	public static final String TRANSACTION_NAME = "F-32";
	
	
	
	public static final class windowCompensarDeudorDatosCabecera{
		
		// hay que poner el nombre de la pantalla de SAP
		public static final String NAME = "Compensar deudor: Datos cabecera";
		
		// boton ejecutar para cuando rellenemos el campo, darle a ejecutar
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
		public static final String BUTTON_CONTINUAR = "tbar[0]/btn[0]";
		
		/** <b>Type: </b> GuiCTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String CTEXT_CUENTA = "ctxtRF05A-AGKON";
		
		/** <b>Type: </b> GuiCTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String CTEXT_FECHA = "ctxtBKPF-BUDAT";
		
		/** <b>Type: </b> GuiCTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String CTEXT_SOCIEDAD = "ctxtBKPF-BUKRS";
		
		/** <b>Type: </b> GuiCTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String CTEXT_INDICADOR_CME = "ctxtRF05A-AGUMS";
		
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
		public static final String BUTTON_DOCUMENTO = "mbar/menu[0]/menu[2]";
		
		public static final String BUTTON_FINALIZAR = "mbar/menu[0]/menu[11]";

		public static final String BUTTON_FINALIZAR2 = "mbar/menu[0]/menu[6]";
		
		// anexar documento 
		public static final class shell{
			
			public static final String BUTTON_SERVICIOS_OBJETO= "%GOS_TOOLBOX";
			
			public static final String TITL_SHELLCONT_SHELL= "titl/shellcont/shell";
			public static final String SHELLCONT_SHELL= "shellcont/shell";
			public static final String SHELLCONT= "shellcont";
			
			public static final String SHELL_BUTTON_CREAR= "CREATE_ATTA";
			public static final String SHELL_BUTTON_CREAR_ADJUNTO= "PCATTA_CREA";
			
			public static final class acction{
				public static final String pressButton = "pressButton";
				public static final String pressContextButton = "pressContextButton";
				public static final String selectContextMenuItem = "selectContextMenuItem";	
				public static final String close = "close";	
			}
			
		}
		
		public static final class popUpImportarFichero{
			
			public static final String NAME = "Importar fichero";
			// creo que de la window2
			public static final String BUTTON_CONTINUAR= "tbar[0]/btn[0]";
			
			public static final String CTEXT_DIRECTORIO= "ctxtDY_PATH";
			public static final String CTEXT_NOMBRE_FICHERO= "ctxtDY_FILENAME";
			
			public static final String BUTTON_FINALIZAR = "mbar/menu[0]/menu[11]";
			
		}
		
	}
	
	public static final class windowCompensarDeudorProcesarPartidasAbiertas{
		
		// hay que poner el nombre de la pantalla de SAP
		public static final String NAME = "Compensar deudor Procesar partidas abiertas";
		
		//obtener Tratar -> cancelar (ShiftF2) (Tratar-Cancelar)
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
		public static final String BUTTON_CANCELAR = "mbar/menu[1]/menu[12]";
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
		public static final String BUTTON_VISUALIZAR_DOC = "tbar[1]/btn[14]";
		
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		// otros botones por si hubiese que usarlos// ATENTOS A tabpMAIN o tabpREST!!!! y el 6102 de main, 6106 de rest
		public static final String BUTTON_DESACTIVAR_PARTIDAS = "tabsTS/tabpMAIN/ssubPAGE:SAPDF05X:6102/btnIC_Z-";
		public static final String BUTTON_DESACTIVAR_PARTIDAS2 = "tabsTS/tabpMAIN/ssubPAGE:SAPDF05X:6103/btnIC_Z-";
		public static final String BUTTON_ELIMINAR_DIFERENCIAS= "tbar[1]/btn[7]";
		public static final String BUTTON_SELECCIONAR_TODAS = "tabsTS/tabpMAIN/ssubPAGE:SAPDF05X:6102/btnICON_SELECT_ALL";
//		public static final String BUTTON_PARTIDA = "tabsTS/tabpREST/ssubPAGE:SAPDF05X:6106/btnIC_Z+";
		public static final String BUTTON_PARTIDA = "tabsTS/tabpREST/ssubPAGE:SAPDF05X:6106/btnIC_Z+";
		public static final String BUTTON_BUSCAR_SUBMENU = "tabsTS/tabpMAIN/ssubPAGE:SAPDF05X:6102/btnICON_SEARCH";
		public static final String CTEXT_DISION = "ctxtBSEG-GSBER";
		public static final String CTEXT_TEXTO_ACREEDOR = "ctxtBSEG-SGTXT";
		public static final String CTEXT_IMPUESTOS = "ctxtBSEG-MWSKZ";
		public static final String CTEXT_CENTRO_COSTE = "subBLOCK:SAPLKACB:1007/ctxtCOBL-KOSTL";
		public static final String CTEXT_CLCTB = "ctxtRF05A-NEWBS";
		public static final String CTEXT_CUENTA = "ctxtRF05A-NEWKO";
		public static final String TEXT_NUMERO_PARTIDAS_SELECT = "tabsTS/tabpMAIN/ssubPAGE:SAPDF05X:6102/txtRF05A-ANZPO";
		public static final String TEXT_SIN_ASIGNAR = "tabsTS/tabpREST/ssubPAGE:SAPDF05X:6106/txtRF05A-DIFFB";
		
		
		
		// pestanya part.rest.
		/** <b>Type: </b> GuiTab <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String TAB_PART_REST = "tabsTS/tabpREST";
		
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
		public static final String BUTTON_BUSCAR_BARRATAREAS = "tbar[0]/btn[71]";
		
		public static final class popUpSelectCriteriosBusqueda{
			/** <b>Type: </b> GuiRadioButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[1]/usr */
			public static final String RBUTTON_IMPORTE = "sub:SAPDF05X:2000/radRF05A-XPOS1[1,0]";
			/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[1] */
			public static final String BUTTON_OK = "tbar[0]/btn[0]";
			/** <b>Type: </b> Guibutton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[1] */
			public static final String BUTTON_CERRAR = "tbar[0]/btn[12]";
			
			/** <b>Type: </b> GuiRadioButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[1]/usr */
			public static final String RBUTTON_REFERENCIA = "sub:SAPDF05X:2000/radRF05A-XPOS1[4,0]";
			
			/** <b>Type: </b> GuiRadioButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[1]/usr */
			public static final String RBUTTON_ASIGNACION = "sub:SAPDF05X:2000/radRF05A-XPOS1[1,0]";
			
			
			public static final class popUpBuscarImporte{
				/** <b>Type: </b> GuiTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[2]/usr */
				public static final String TEXT_DESDE = "sub:SAPDF05X:0730/txtRF05A-VONWT[0,0]";
						
				/** <b>Type: </b> GuiTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[2]/usr */
				public static final String TEXT_HASTA = "sub:SAPDF05X:0730/txtRF05A-BISWT[0,20]";
					
				/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[2] */
				public static final String BUTTON_OK = "tbar[0]/btn[0]";		
				/** <b>Type: </b> Guibutton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[2] */
				public static final String BUTTON_CERRAR = "tbar[0]/btn[12]";		
				
			}
			
			public static final class popUpBuscarReferencia{
				/** <b>Type: </b> GuiTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[2]/usr */
				public static final String TEXT_DE = "sub:SAPDF05X:0731/txtRF05A-SEL01[0,0]";
						
				/** <b>Type: </b> GuiTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[2]/usr */
				public static final String TEXT_A = "sub:SAPDF05X:0731/txtRF05A-SEL02[0,31]";
				
				/** <b>Type: </b> GuiCheckBox <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[2]/usr */
				public static final String CHECK_BOX_STRING = "sub:SAPDF05X:0731/chkRF05A-XSTRN[0,62]";
				/** <b>Type: </b> GuiCheckBox <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[2]/usr */
				public static final String CHECK_BOX_VALINICIAL = "sub:SAPDF05X:0731/chkRF05A-XINIT[0,70]";
				
				/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[2] */
				public static final String BUTTON_OK = "tbar[0]/btn[0]";		
				/** <b>Type: </b> Guibutton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[2] */
				public static final String BUTTON_CERRAR = "tbar[0]/btn[12]";		
			}
			
			public static final class popUpBuscarAsignacion{
				/** <b>Type: </b> GuiTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[2]/usr */
				public static final String TEXT_DE = "sub:SAPDF05X:0731/txtRF05A-SEL01[0,0]";
						
				/** <b>Type: </b> GuiTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[2]/usr */
				public static final String TEXT_A = "sub:SAPDF05X:0731/txtRF05A-SEL02[0,31]";
				
				/** <b>Type: </b> GuiCheckBox <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[2]/usr */
				public static final String CHECK_BOX_STRING = "sub:SAPDF05X:0731/chkRF05A-XSTRN[0,62]";
				/** <b>Type: </b> GuiCheckBox <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[2]/usr */
				public static final String CHECK_BOX_VALINICIAL = "sub:SAPDF05X:0731/chkRF05A-XINIT[0,70]";
				
				/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[2] */
				public static final String BUTTON_OK = "tbar[0]/btn[0]";		
				/** <b>Type: </b> Guibutton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[2] */
				public static final String BUTTON_CERRAR = "tbar[0]/btn[12]";		
			}
			
			
			// no encuentra pago, no hay valores con el filtro por importe aplicado
			public static final class popUpNoEncuentraPago{
				/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[2] */
				public static final String BUTTON_CONTINUAR = "tbar[0]/btn[0]";
			}
			
		}
		// No se por que lo llame asi, es partida rest, se marca con doble click y se hace tab
		/** <b>Type: </b> GuiTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String TEXT_SALDO =  "tabsTS/tabpREST/ssubPAGE:SAPDF05X:6106/tblSAPDF05XTC_6106/txtDF05B-PSDIF[6,0]";
//		public static final String CTEXT_ORIGEN_DIFERENCIAS =  "tabsTS/tabpREST/ssubPAGE:SAPDF05X:6106/ctxtRF05A-RSTGR";
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/ */
		public static final String BUTTON_BACK = "tbar[0]/btn[3]";
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
		public static final String BUTTON_CONTINUAR = "tbar[0]/btn[0]";
		
		/** <b>Type: </b> GuiTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String TEXT_PARTIDAS = "tabsTS/tabpREST/ssubPAGE:SAPDF05X:6106/txtRF05A-ANZPO";
		
		// /app/con[0]/ses[0]/wnd[0]/usr/tabsTS/tabpREST/ssubPAGE:SAPDF05X:6106/tblSAPDF05XTC_6106/txtDF05B-PSBET[4,0]
//		public static final String TEXT_IMPORTE_NETO = "tabsTS/tabpREST/ssubPAGE:SAPDF05X:6106/txtDF05B-PSBET[2,0]";
		/** <b>Type: </b> GuiTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String TEXT_IMPORTE_NETO = "tabsTS/tabpREST/ssubPAGE:SAPDF05X:6106/tblSAPDF05XTC_6106/txtDF05B-PSBET[4,0]";
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String BUTTON_CLASIF_ASC = "tabsTS/tabpREST/ssubPAGE:SAPDF05X:6106/btnICON_SORT_UP";
		
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String BUTTON_CLASIF_DES = "tabsTS/tabpREST/ssubPAGE:SAPDF05X:6106/btnICON_SORT_DOWN";
		/** <b>Type: </b> GuiTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String TEXT_REFERENCIA = "tabsTS/tabpREST/ssubPAGE:SAPDF05X:6106/tblSAPDF05XTC_6106/txtRFOPS_DK-XBLNR[0,0]";
//		public static final String TEXT_REFERENCIA = "tabsTS/tabpREST/ssubPAGE:SAPDF05X:6106/txtRFOPS_DK-XBLNR[0,0]";
		
		/** <b>Type: </b> GuiTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String TEXT_PARTIDA_REST = "tabsTS/tabpREST/ssubPAGE:SAPDF05X:6106/tblSAPDF05XTC_6106/txtDF05B-PSDIF[6,0]";
//		public static final String TEXT_PARTIDA_REST = "tabsTS/tabpREST/ssubPAGE:SAPDF05X:6106/txtDF05B-PSDIF[4,0]";
		
	}
	
	public static final class windowCompensarDeudorVisualizarResumen{
		
		// hay que poner el nombre de la pantalla de SAP
		public static final String NAME = "Compensar deudor Visualizar Resumen";
		
		//obtener Tratar -> cancelar (ShiftF2) (Tratar-Cancelar)
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
		public static final String BUTTON_CANCELAR_TRATAR = "mbar/menu[1]/menu[0]";
		
		/** <b>Type: </b> GuiCTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String CTEXT_CLVCT = "ctxtRF05A-NEWBS";
		/** <b>Type: </b> GuiCTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String CTEXT_CUENTA = "ctxtRF05A-NEWKO";
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
		public static final String BUTTON_CONTINUAR = "tbar[0]/btn[0]";
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
		public static final String BUTTON_TRATAR_PASS = "tbar[1]/btn[16]";
		/** <b>Type: </b> GuiCTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String CTEXT_CME = "ctxtRF05A-NEWUM";
		
		public static final class windowCompensarDeudorCorregirPosicionDeDeudor {
			/** <b>Type: </b> TextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
			public static final String TEXT_IMPORTE = "txtBSEG-WRBTR";
			/** <b>Type: </b> TextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
			public static final String TEXT_ASIGNACION = "txtBSEG-ZUONR";
			/** <b>Type: </b> CTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
			public static final String CTEXT_TEXTO = "ctxtBSEG-SGTXT";
			/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
			public static final String BUTTON_CONTINUAR = "tbar[0]/btn[0]";
			/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
			public static final String BUTTON_TRATARPAS = "tbar[1]/btn[16]";
			/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
			public static final String BUTTON_VISUALIZAR_RES = "tbar[1]/btn[14]";
			
		
		}
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
		public static final String BUTTON_POSTIMPUTAR = "tbar[1]/btn[5]";
		
		
	}
	
	public static final class windowCompensarDeudorAnadirPosicionDeDeudor{
		/** <b>Type: </b> TextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String TEXT_IMPORTE = "txtBSEG-WRBTR";
//		public static final String TEXT_IMPORTE = "txtBSEG-WRBTR";
		/** <b>Type: </b> TextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String TEXT_ASIGNACION = "txtBSEG-ZUONR";
//		public static final String TEXT_ASIGNACION = "txtBSEG-ZUONR";
		/** <b>Type: </b> CTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String CTEXT_TEXTO = "ctxtBSEG-SGTXT";
//		public static final String TEXT_TEXTO = "txtBSEG-SGTXT";
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
		public static final String BUTTON_CONTINUAR = "tbar[0]/btn[0]";
		/** <b>Type: </b> CTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String CTEXT_FECHA = "ctxtBSEG-ZFBDT";
//		public static final String CTEXT_FECHA = "ctxtBSEG-ZFBDT";
		
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
		public static final String BUTTON_TRATAR_PAS = "tbar[1]/btn[16]";
		
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
		public static final String BUTTON_CONTABILIZAR = "tbar[0]/btn[11]";
		
		
		/** <b>Type: </b> GuiTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String TEXT_IMPUESTO = "txtBSEG-WMWST";
		/** <b>Type: </b> GuiCTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String CTEXT_IND_IMPUESTO = "ctxtBSEG-MWSKZ";
		/** <b>Type: </b> GuiCheckBox <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String CHECKBOX_CALCULAR_IMPUESTOS = "chkRF05A-XMWST";
		
		
	}
	
	
	public static final class windowCompensarDeudorSeleccionarPartidasAbiertas{
		// hay que poner el nombre de la pantalla de SAP
		public static final String NAME = "Compensar deudor Seleccionar part. abiertas";
		
		/** <b>Type: </b> GuiButton <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0] */
		public static final String BUTTON_CONTINUAR = "tbar[0]/btn[0]";
		
		/** <b>Type: </b> GuiCTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String CTEXT_SOCIEDAD = "ctxtRF05A-AGBUK";
		
		/** <b>Type: </b> GuiCTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String CTEXT_CUENTA = "ctxtRF05A-AGKON";
		
		/** <b>Type: </b> GuiCTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String CTEXT_CLASE_CUENTA = "ctxtRF05A-AGKOA";
		
		/** <b>Type: </b> GuiCTextField <p><b>SAP Path: </b> /app/con[0]/ses[0]/wnd[0]/usr */
		public static final String CTEXT_CME = "ctxtRF05A-AGUMS";
		
		
	}

	//puede salir o no
	public static final class popUpImpuestos{
		
		// deberia ser este
		public static final String BUTTON_CONTINUAR = "tbar[0]/btn[0]";
		
	}
	
	
	

}
