package com.deloitte.lopesan.googledrive;


import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.List;

import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.model.ValueRange;


public class SheetsUtils {
	
	/**
	 * Devuelve los valores de una pestana
     *
     * @param sheetsService Servicio de Drive.
     * @param spreadsheetId Id del fichero excel para extraer datos.
     * @param range rango de valores dentro de la pestana.
     * @return valores de pestana
     */
	public static List<List<Object>> getSheetValues(Sheets sheetsService, String spreadsheetId, String range) throws IOException, GeneralSecurityException {
		
		//Se ejecuta la respuesta del servicio
		ValueRange response = sheetsService.spreadsheets().values().get(spreadsheetId, range).execute();
		//Se obtienen los valores de la hoja de calculo
		return response.getValues();
    }
	
	/**
	 * Escribe valores en una pestana
    *
    * @param sheetsService Servicio de Drive.
    * @param spreadsheetId Id del fichero Excel.
    * @param body Informacion que se escribe en Excel.
    * @param range Rango de valores (incluir nombre pestana).
 	 *
    */
	public static void setSheetValues (Sheets sheetsService, String spreadsheetId, List<List<Object>> body, String range) throws IOException {
		
		//Valor "RAW" sirve para interpretar los elementos de la lista como filas
		sheetsService.spreadsheets().values()
			      .append(spreadsheetId, range, new ValueRange().setValues(body))
			      .setValueInputOption("RAW")
			      .execute();
	}

}
