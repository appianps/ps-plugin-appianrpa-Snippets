package com.deloitte.lopesan.googledrive;


import java.io.IOException;
import java.security.GeneralSecurityException;

import com.deloitte.jidoka.lopesan.exceptions.SystemException;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.sheets.v4.Sheets;

public class SheetsServiceUtil {

	
	private static final String APPLICATION_NAME = "Google Sheets Example";
	
	/**
	 * Crear el servicio de Drive para Excel
     *
     * @return hoja de calculo
	 * @throws SystemException 
     */
    public static Sheets getSheetsService() throws SystemException {// throws IOException, GeneralSecurityException {
        Credential credential;
		try {
			credential = GoogleAuthorizeUtil.getCredentials(GoogleNetHttpTransport.newTrustedTransport());
		} catch (IOException | GeneralSecurityException e) {
			throw new SystemException("No se ha podido acceder a google sheets", null, "fin", false);
		}
        try {
			return new Sheets.Builder(
			  GoogleNetHttpTransport.newTrustedTransport(), 
			  JacksonFactory.getDefaultInstance(), credential)
			  .setApplicationName(APPLICATION_NAME)
			  .build();
		} catch (GeneralSecurityException | IOException e) {
			throw new SystemException("No se ha podido acceder a google sheetsS", null, "fin", false);
		}
    }

}
